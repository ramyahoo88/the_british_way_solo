#!/usr/bin/env python3
"""Prove missing-field failures even when both PDF copies are damaged alike."""
from pathlib import Path
import json,shutil,tempfile
import fitz
from verify_printables import verify,DATA,norm,card_rect,ROOT

def redact_card(doc,page,slot,needle,replacement=None):
    p=doc[page];cell=card_rect(slot);hits=p.search_for(needle,clip=cell)
    assert len(hits)==1,(page,slot,needle,len(hits))
    hit=hits[0];p.add_redact_annot(hit,fill=(1,1,1));p.apply_redactions()
    if replacement:p.insert_text((hit.x0,hit.y1-2),replacement,fontsize=8)

def main():
    version=DATA['version'];cc=DATA['layout']['rule_pages']+DATA['layout']['event_pages']+2
    outcomes=[]
    cases=[('F5_card09_other_special',1,2,'GATHER > RAID',None,'09'),
           ('third_column_card18_title',2,5,'Strike beyond the camps',None,'18'),
           ('card05_wrong_B_flag',0,4,'B EVENTS: YES','B EVENTS: NO','05'),
           ('card10_wrong_region',1,3,'RAIL ORDER: N','RAIL ORDER: S','10'),
           ('card01_missing_reminder',0,0,DATA['card_reminder'],None,'01')]
    for name,sheet,slot,needle,replacement,expected_card in cases:
        with tempfile.TemporaryDirectory(prefix='force136_mutant_') as td:
            out=Path(td)
            for file in (ROOT/'output').glob('*.pdf'):shutil.copy2(file,out/file.name)
            for kind,page in [('Cards',sheet),('Solo',cc+sheet)]:
                file=out/f'Force_136_{kind}_v{version}.pdf';doc=fitz.open(file)
                redact_card(doc,page,slot,needle,replacement)
                temp=file.with_suffix('.tmp.pdf');doc.save(temp);doc.close();temp.replace(file)
            if name.startswith('F5'):
                with fitz.open(out/f'Force_136_Cards_v{version}.pdf') as doc:
                    assert norm('GATHER > RAID') in norm(doc[sheet].get_text()),'Other card must still contain the phrase'
            try:verify(out)
            except AssertionError as e:
                reason=str(e);assert 'Missing or stale card field' in reason and expected_card in reason,reason
                outcomes.append(dict(mutation=name,rejected=True,reason=reason))
            else:raise AssertionError(f'Mutant accepted: {name}')
    with tempfile.TemporaryDirectory(prefix='force136_rail_mutant_') as td:
        out=Path(td)
        for file in (ROOT/'output').glob('*.pdf'):shutil.copy2(file,out/file.name)
        for kind,page in [('Reference',1),('Solo',cc-1)]:
            file=out/f'Force_136_{kind}_v{version}.pdf';doc=fitz.open(file);p=doc[page]
            line=p.search_for('Perak-Pahang-Selangor')[0]
            box=fitz.Rect(506,line.y0-4,576,line.y1+4)
            p.add_redact_annot(box,fill=(1,1,1));p.apply_redactions();p.insert_text((530,line.y1-2),'1',fontsize=9)
            temp=file.with_suffix('.tmp.pdf');doc.save(temp);doc.close();temp.replace(file)
        try:verify(out)
        except AssertionError as e:
            assert 'Wrong rail rank' in str(e) and "'S'" in str(e),str(e)
            outcomes.append(dict(mutation='third_column_rail_rank',rejected=True,reason=str(e)))
        else:raise AssertionError('Wrong S rank accepted')
    receipt=dict(intact=verify(),mutations=outcomes,mutants_rejected=len(outcomes),mutants_accepted=0)
    (ROOT/'evidence'/'print_mutations.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
