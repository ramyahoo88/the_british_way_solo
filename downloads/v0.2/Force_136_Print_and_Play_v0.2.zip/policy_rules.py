#!/usr/bin/env python3
"""Executable references for v0.2's changed paper decisions, not a game AI.

No turn scheduler, Event deck executor or general rules engine is provided.
The final-plan selector accepts already legal, fully specified candidate boards.
Supply/Contact helpers exercise the ordinary no-capability audit positions;
unsupported capability actions raise rather than silently simulating them.
"""
from copy import deepcopy

ORDER=('Kedah','Perak','Kelantan','Trengganu','Pahang','Selangor','Kuala Lumpur',
       'Negri Sembilan','Johore','Northern EC','Southern EC')
ADJACENT={
 'Kedah':{'Perak'},
 'Perak':{'Kedah','Kelantan','Pahang','Selangor','Northern EC'},
 'Kelantan':{'Perak','Trengganu','Pahang','Northern EC'},
 'Trengganu':{'Kelantan','Pahang'},
 'Pahang':{'Perak','Kelantan','Trengganu','Selangor','Kuala Lumpur','Negri Sembilan','Johore','Northern EC','Southern EC'},
 'Selangor':{'Perak','Pahang','Kuala Lumpur','Negri Sembilan'},
 'Kuala Lumpur':{'Selangor','Pahang','Negri Sembilan'},
 'Negri Sembilan':{'Selangor','Kuala Lumpur','Pahang','Johore','Southern EC'},
 'Johore':{'Negri Sembilan','Pahang','Southern EC'},
 'Northern EC':{'Perak','Kelantan','Pahang'},
 'Southern EC':{'Pahang','Negri Sembilan','Johore'}}
assert all(a in ADJACENT[b] for a,ns in ADJACENT.items() for b in ns)

def gs(v):return sum(v[k] for k in ('red_u','red_a','blue_u','blue_a'))
def cubes(v):return v['troops']+v['police']
def count(b,f):return sum(int(v[f]) for v in b.values())
def clamp(r):return min(20,max(0,r))
def public_copy(board):
    # Concealed values are deliberately dropped, even if a fixture has them.
    return {s:{k:deepcopy(x) for k,x in v.items() if k!='intel_value' or v['intel_revealed']}
            for s,v in board.items()}

def winner(r,b):
    if r<18:return 'Japan'
    if r==20:return 'Force 136'
    return 'Force 136' if count(b,'camp')<count(b,'force136') else 'MPAJA'

def recruit_rank(b,s):
    v=b[s];g=gs(v);c=cubes(v)
    return (not(v['force136'] and not g),not(v['cache'] and not g),
            not(g<=c<g+1),not v['force136'],not v['cache'],c,-v['population'],ORDER.index(s))

def final_projection(board,resistance,resources,red_available,j15_shaded=False):
    """Certain, public Propaganda phases 6.1/6.2/7; stop before later phases.

    Caller applies the candidate action first. Unknown Intel remains concealed.
    Newly revealed unknown Intel and other uncertain actions are excluded by
    select_final_plan, not evaluated using secret fixture values.
    """
    b=public_copy(board);red_pool=red_available;clashes=0
    for s in ORDER:
        v=b[s]
        if v['red_u']+v['red_a'] and v['blue_u']+v['blue_a']:
            for color in ('red','blue'):
                f=color+('_a' if v[color+'_a'] else '_u');v[f]-=1
            red_pool+=1;clashes+=1
    eligible=[s for s in ORDER if b[s]['opposition'] and not(j15_shaded and b[s]['new_village'])]
    eligible.sort(key=lambda s:recruit_rank(b,s))
    recruited=[]
    for s in eligible:
        if red_pool:
            b[s]['red_u']+=1;red_pool-=1;recruited.append(s)
    intel=sum(v['intel_value'] for v in b.values() if v['intel_revealed'])
    majorities=sum(gs(v)>cubes(v) for v in b.values())
    neutral=sum(v['population'] for v in b.values() if not v['opposition'] or (j15_shaded and v['new_village']))
    police=sum(v['police']>0 for v in b.values())
    delta=intel+count(b,'cache')+majorities-resources//4-neutral//5-police//3
    r=clamp(resistance+delta)
    return dict(resistance_after=r,net_change=delta,intel=intel,caches=count(b,'cache'),
                guerrilla_majorities=majorities,neutral_population=neutral,police_spaces=police,
                camps=count(b,'camp'),force136=count(b,'force136'),winner_if_final=winner(r,b),
                clash_spaces=clashes,recruited=recruited,red_available=red_pool,board_after=b)

def final_check_due(state):
    return (state['campaign']==3 and state.get('japan_has_acted',False)
            and state.get('physical_cards_remaining')==1
            and not state.get('final_propaganda_resolved',False)
            and not state.get('mandatory_event_ends_game',False))

def select_final_plan(state,plans):
    """Input order is printed plans 1-5; no hidden search or tie optimization."""
    if not final_check_due(state):return None
    if len(plans)>5:raise ValueError('The paper check is limited to five plans')
    for plan in plans:
        if not plan.get('legal',True) or plan.get('uncertain_effects'):continue
        score=final_projection(plan['board'],plan.get('resistance',state['resistance']),
                               plan.get('resources',state['japanese_resources']),
                               plan.get('red_available',state['red_available']),
                               'J15S' in state.get('capabilities',[]))
        if score['winner_if_final']=='Force 136':return dict(plan=plan['name'],score=score)
    return None

def j4_rating(resistance,eligible):
    gain=clamp(resistance+eligible)-resistance
    return 'A' if gain>=2 else 'B' if gain==1 else None

def j26_rating(resistance,success_faces):
    return 'A' if clamp(resistance+2)>resistance and success_faces>=3 else None

def activate(board,space,allowed_colors=('red','blue'),incoming=None):
    """One actual activation; incoming counts restrict a Raid attack's actor."""
    for color in ('red','blue'):
        if color not in allowed_colors:continue
        if board[space][color+'_u'] and (incoming is None or incoming.get(color,0)):
            board[space][color+'_u']-=1;board[space][color+'_a']+=1
            if incoming is not None:incoming[color]-=1
            return color
    raise ValueError('No eligible underground actor')

def forecast_sabotage_activations(board,sites):
    b=public_copy(board)
    for s in sites:
        if not b[s]['force136']:raise ValueError('Ordinary audit attack lacks Force 136')
        activate(b,s)
    return b

def gather_opportunities(board):
    # Existence check: ordinary Gather can choose an eligible anchor first,
    # including with J19S. It does not execute/reveal or count secret values.
    return [(anchor,s) for anchor in ORDER if board[anchor]['force136']
            for s in ORDER if s==anchor or s in ADJACENT[anchor]
            if board[s]['population'] and not board[s]['intel_revealed']
            and board[s]['red_u']+board[s]['blue_u']>0]

def donor_allowed(v,send=1):
    remaining=gs(v)-send
    return send>0 and remaining>=0 and not(v['cache'] and remaining<1) and not(gs(v)>cubes(v) and remaining<=cubes(v))

def supply_plan(state,contact_hold=False):
    """Ordinary Contact + Supply reference, limited to no-capability cases.

    Implements the printed priorities needed for F1; deliberately refuses the
    capability cases rather than representing a partial engine as complete.
    """
    if state.get('capabilities'):raise NotImplementedError('Use the physical capability text')
    if 'Op & SA' not in state['free_initiative_boxes'] or not state['cache_available']:return None
    b=public_copy(state['board']);f_available=state['force136_available'];camps_avail=state['camp_available']
    contact=None;avail=state['cache_available']
    def d_rank(s):
        v=b[s]
        return (bool(v['kempeitai']),not(v['population'] and s!='Kuala Lumpur' and not v['cache'] and avail),
                -gs(v),-v['population'],ORDER.index(s))
    if not contact_hold:
        provinces=[s for s in ORDER if s!='Kuala Lumpur' and b[s]['population']]
        dests=[s for s in provinces if not b[s]['force136']]
        if f_available and dests:
            dst=min(dests,key=d_rank);b[dst]['force136']+=1;f_available-=1;contact=('Available',dst)
        elif not f_available:
            moves=[]
            for src in ORDER:
                v=b[src]
                if not v['force136']:continue
                exposed=bool(v['kempeitai'] and not v['camp'])
                source_can_supply=v['camp'] and not v['cache']
                for dst in ADJACENT[src]:
                    w=b[dst]
                    if w['force136']:continue
                    opens=w['population'] and dst!='Kuala Lumpur' and not w['cache'] and avail
                    if not(exposed or opens):continue
                    sr=(not exposed,bool(source_can_supply),bool(v['cache']),gs(v),-ORDER.index(src))
                    moves.append((sr,d_rank(dst),src,dst))
            if moves:
                _,_,src,dst=min(moves);b[src]['force136']-=1;b[dst]['force136']+=1;contact=(src,dst)
                # Escort cannot be red and must preserve donor safety.
                if not b[dst]['red_u']+b[dst]['red_a'] and donor_allowed(b[src]):
                    field='blue_u' if b[src]['blue_u'] else 'blue_a' if b[src]['blue_a'] else None
                    if field:b[src][field]-=1;b[dst][field]+=1
        if contact:
            dst=contact[1];v=b[dst]
            if v['population'] and dst!='Kuala Lumpur' and not v['camp']:
                if not camps_avail:
                    donors=[s for s in ORDER if b[s]['camp']]
                    src=min(donors,key=lambda s:(bool(b[s]['force136']),not b[s]['cache'],b[s]['population'],-ORDER.index(s)))
                    b[src]['camp']=False;camps_avail+=1
                v['camp']=True;camps_avail-=1
    sites=[s for s in ORDER if b[s]['force136'] and b[s]['camp'] and not b[s]['cache'] and b[s]['population'] and s!='Kuala Lumpur']
    sites.sort(key=lambda s:(bool(b[s]['kempeitai']),-gs(b[s]),-b[s]['population'],ORDER.index(s)))
    sites=sites[:min(3 if state['zipper']>=12 else 2,avail)]
    if not sites:return None
    for s in sites:b[s]['camp']=False;b[s]['cache']=True;avail-=1;camps_avail+=1
    return dict(name='SUPPLY',legal=True,board=b,contact=contact,supply_sites=sites,
                cache_available=avail,camp_available=camps_avail,force136_available=f_available)

def contact_for_intel(board,available_force):
    if gather_opportunities(board):return 'HOLD'
    return 'PLACE_OR_MOVE' if available_force or count(board,'force136') else None

def primary_complete(printed,performed,attempted,route='TASK'):
    return route!='EVENT' and performed==printed and attempted

def event_denial(rating,keen,threat,japan_has_acted,normal_route,event_free=True):
    if not event_free or not threat or japan_has_acted:return False
    if rating is None or rating=='D':return True
    return rating=='B' and not keen and normal_route=='PASS'

# Railway junctions inferred directly from the printed borders and rule 4.3.1.
# These are railway nodes, not unit adjacency and not playable map spaces.
RAIL_EDGES={
 'Thailand-Kedah *':('Exit Kedah','NW junction'),
 'Thailand-Perak':('NW junction','N junction'),
 'Thailand-Kelantan *':('N junction','Exit Kelantan'),
 'Perak-Kelantan':('N junction','Northern EC'),
 'Perak-Pahang-Selangor':('Northern EC','Kuala Lumpur'),
 'Negri Sembilan-Pahang':('Kuala Lumpur','Southern EC'),
 'Negri Sembilan-Johore *':('Southern EC','Exit Negri'),
 'Pahang-Johore *':('Southern EC','Exit Pahang')}

def live_rails(damaged):
    graph={}
    for rail,(a,b) in RAIL_EDGES.items():
        if rail not in damaged:
            graph.setdefault(a,[]).append((b,rail));graph.setdefault(b,[]).append((a,rail))
    live=set()
    def walk(node,seen,path):
        if node.startswith('Exit '):live.update(path);return
        for nxt,rail in graph.get(node,[]):
            if nxt not in seen:walk(nxt,seen|{nxt},path+[rail])
    for ec in ('Northern EC','Southern EC'):walk(ec,{ec},[])
    return live
