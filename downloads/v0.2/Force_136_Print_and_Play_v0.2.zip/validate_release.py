#!/usr/bin/env python3
"""Build and reproduce the scoped release checks; no balance simulation."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
EVIDENCE=ROOT/'evidence'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(script,log):
    result=subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (EVIDENCE/log).write_text(result.stdout)
    if result.returncode:raise RuntimeError(f'{script} failed; inspect evidence/{log}')
    return result.stdout

def main():
    EVIDENCE.mkdir(exist_ok=True)
    run('build_force136.py','build.txt')
    run('reference_checks.py','reference_checks.txt')
    run('regression_checks.py','regression_checks.txt')
    prints=json.loads(run('verify_printables.py','verify_printables.txt'))
    mutations=json.loads(run('test_print_mutations.py','print_mutations.txt'))
    data=json.loads((ROOT/'bot_data.json').read_text());version=data['version']
    matches=[]
    with tempfile.TemporaryDirectory(prefix='force136_clean_') as td:
        clean=Path(td);shutil.copy2(ROOT/'build_force136.py',clean/'build_force136.py')
        result=subprocess.run([sys.executable,str(clean/'build_force136.py')],cwd=clean,text=True,capture_output=True)
        assert result.returncode==0,result.stderr
        for name in [f'Force_136_{part}_v{version}.pdf' for part in ['Solo','Cards','Reference']]:
            original=digest(ROOT/'output'/name);rebuilt=digest(clean/'output'/name)
            assert original==rebuilt,('Non-reproducible PDF',name)
            matches.append(dict(file=name,sha256=original,rebuild_sha256=rebuilt,equal=True))
        for name in ['bot_data.json',f'Force_136_Rules_v{version}.md','provenance.json']:
            assert (ROOT/name).read_bytes()==(clean/name).read_bytes(),('Non-reproducible source export',name)
    (EVIDENCE/'clean_rebuild.json').write_text(json.dumps(matches,indent=2)+'\n')
    locations={}
    targets={
     'F1':[('build_force136.py','0. Check known final scoring'),('build_force136.py','When to use the final-scoring check'),('policy_rules.py','def select_final_plan')],
     'F2':[('build_force136.py',"('J4'"),('build_force136.py',"('J26'"),('policy_rules.py','def j26_rating')],
     'F3':[('build_force136.py','Initiative and the single action budget'),('policy_rules.py','def forecast_sabotage_activations')],
     'F4':[('build_force136.py','One global activation priority'),('policy_rules.py','def activate(')],
     'F5':[('verify_printables.py','def card_rect'),('verify_printables.py','for docpage in (p,full[cc+sheet])'),('test_print_mutations.py','F5_card09_other_special')],
     'Q1':[('build_force136.py','4. Keep or discard'),('policy_rules.py','def primary_complete')],
     'Q2':[('build_force136.py','CONTACT: choose a plan'),('policy_rules.py','def contact_for_intel')],
     'U1':[('build_force136.py',"rows=[[Paragraph('<b>Railway</b>'")],
     'U2':[('build_force136.py','CARD_REMINDER =')],
     'U3':[('build_force136.py','Denial is a limited option'),('policy_rules.py','def event_denial')],
     'U4':[('regression_checks.py','def test_U4_post_Propaganda_Train_can_recover_cache_guards'),('policy_rules.py','def live_rails')],
    }
    for finding,entries in targets.items():
        locations[finding]=[]
        for file,needle in entries:
            hits=[i for i,line in enumerate((ROOT/file).read_text().splitlines(),1) if needle in line]
            assert len(hits)==1,(file,needle,hits)
            locations[finding].append(dict(file=file,line=hits[0]))
    (EVIDENCE/'fix_locations.json').write_text(json.dumps(locations,indent=2)+'\n')
    regressions=json.loads((EVIDENCE/'regression_results.json').read_text())
    assert regressions['tests_run']==35 and not regressions['failures'] and not regressions['errors']
    original_log=(EVIDENCE/'reference_checks.txt').read_text()
    assert 'Ran 52 tests' in original_log and original_log.rstrip().endswith('OK')
    receipt=dict(version=version,date='20 November 2026',retained_reference_checks=52,new_focused_regressions=35,
                 total_decision_checks=87,prints=prints,mutation_rejections=mutations['mutants_rejected'],
                 pdf_clean_rebuilds=matches,all_scoped_checks_pass=True,complete_games=0,
                 full_game_simulation=False,physical_playtesting=False,competitive_strength_measured=False,
                 verdict='Pass for paper playtesting; competitive public-release claim remains on hold')
    (ROOT/'validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
