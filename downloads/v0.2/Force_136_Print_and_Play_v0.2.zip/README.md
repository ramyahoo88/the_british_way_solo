# Force 136 — paper opponent for Japan

Version 0.2, 20 November 2026. Original unofficial card-driven solo variant for
the standard standalone **Japanese Occupation** game in **The British Way:
Enemy of My Enemy**. You play Japan. The physical base game, expansion, Event
cards and player aids are required. No computer is needed at the table.

Print **output/Force_136_Solo_v0.2.pdf** for the complete 17-page package.
The separate Cards and Reference PDFs in output/ are convenient for reprinting.
Print at 100% / actual size, single sided. All 18 cards remain 2.5 × 3.5 inches.
Reprint the cards as well as the rules: the global reminder and card-life text
have changed. The card distribution and regional preferences are unchanged.

This release corrects all five confirmed v0.1 audit findings and settles its
two bot-design ambiguities. The railway reference is now an eight-row table.
The final-scoring safeguard is a bounded check of certain public outcomes on
the known last turn. It does not inspect future cards or concealed Intel.

**Status: ready for paper playtesting; competitive strength remains unmeasured.**
No complete three-campaign bot game or physical timing session is claimed.

## Contents

- output/: combined guide, three card sheets, two reference sheets and layout bounds.
- Force_136_Rules_v0.2.md: editable rule text, all Event policies and card data.
- build_force136.py: canonical editable constants and deterministic PDF builder.
- bot_data.json: generated export; edit the builder and rebuild to change it.
- policy_rules.py: executable references for changed decisions and focused boards;
  not a runtime opponent or complete game engine.
- reference_checks.py: 52 retained narrow development checks.
- regression_checks.py: 35 focused checks of the audit boards and nearby cases.
- verify_printables.py: prose, Event, per-card-cell, rail-column and sheet checks.
- test_print_mutations.py: six deliberately damaged copies must be rejected.
- validate_release.py: rebuild, run the checks and verify clean PDF reproduction.
- fixtures/: F1–F4 board positions, declined-B denial case and cache-recovery case.
- evidence/: actual test receipts, print results, clean rebuild and review receipts.
- AUDIT_RESPONSE_v0.1.md and CHANGELOG.md: fixes, design choices and limits.
- provenance.json and validation.json: source identity and exact validation results.

## Reproduce

Python 3 standard library:

```text
python3 reference_checks.py
python3 regression_checks.py
```

With ReportLab, PyMuPDF and system DejaVu Sans fonts:

```text
python3 build_force136.py
python3 verify_printables.py
python3 test_print_mutations.py
```

Run `python3 validate_release.py` with those dependencies for the complete
scoped validation, including a clean rebuild and an updated validation receipt.

The final-plan selector accepts already legal candidate boards. The action
helpers intentionally cover a subset, refuse unsupported capability execution,
and provide no complete deck, turn scheduler or Japanese policy engine.
Their passing assertions do not establish a win rate or validate all play.
Fixtures are runnable reference positions, not importable Vassal saves.

The rules and component artwork used for comparison are linked and hashed,
not redistributed. All official game rules, marks and artwork remain their
owners'. This is an independent fan variant, not a GMT publication.

## Scope

Standalone scenario only; no linked campaign, Pre-War Options, Personas,
difficulty levels, app, voluntary cache recycling, multi-marker Contact
relocation, or selected J17 Event policy. The MPAJA remains the published
independent actor; its victory means both Japan and the bot lose.
