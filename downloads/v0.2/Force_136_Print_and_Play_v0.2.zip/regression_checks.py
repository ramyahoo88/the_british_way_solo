#!/usr/bin/env python3
"""Focused board regressions for the v0.1 audit and v0.2 paper rulings.

These execute the changed decision references and prescribed local actions.
They are not complete games, strength simulations or physical playtests.
"""
import copy,json,unittest
from pathlib import Path
import policy_rules as p
from reference_checks import initiative,ambush_faces,train_color
ROOT=Path(__file__).resolve().parent
RECEIPT={}
def fixture(n):return json.loads((ROOT/'fixtures'/f'F{n}.json').read_text())
def mark_event_j4(f,side):
    b=p.public_copy(f['board']);r=f['resistance']
    if side=='U':r=p.clamp(r+sum(bool(v['force136'] and v['camp']) for v in b.values()))
    else:
        for v in b.values():
            if v['force136']:v['camp']=False
    return dict(name='J4 '+side,board=b,resistance=r)
def final_candidates(f):
    supply=p.supply_plan(f)
    return [dict(supply,name='Normal SUPPLY'),mark_event_j4(f,'U'),mark_event_j4(f,'S')]
def empty_board():
    b=fixture(1)['board']
    for v in b.values():
        for k in ['troops','police','red_u','red_a','blue_u','blue_a','force136','kempeitai']:v[k]=0
        for k in ['camp','cache','opposition','terror','new_village','intel_revealed']:v[k]=False
        v['intel_value']=None
    return b

class FinalScoring(unittest.TestCase):
    def test_F1_event_vs_supply_and_actual_selection(self):
        f=fixture(1);plans=final_candidates(f);rows=[]
        for plan in plans:
            score=p.final_projection(plan['board'],plan.get('resistance',f['resistance']),0,3)
            rows.append(dict(plan=plan['name'],resistance=score['resistance_after'],winner=score['winner_if_final'],camps=score['camps']))
        self.assertEqual([(r['resistance'],r['winner']) for r in rows],[(20,'Force 136'),(18,'MPAJA'),(17,'Japan')])
        chosen=p.select_final_plan(f,plans)
        self.assertEqual(chosen['plan'],'Normal SUPPLY')
        self.assertEqual(plans[0]['contact'],('Pahang','Kelantan'))
        self.assertEqual(plans[0]['supply_sites'],['Kelantan','Perak','Kedah'])
        RECEIPT['F1']=dict(plans=rows,chosen=chosen['plan'],contact=plans[0]['contact'],supplied=plans[0]['supply_sites'])
    def test_F1_hold_supply_also_wins(self):
        f=fixture(1);plan=p.supply_plan(f,contact_hold=True)
        self.assertIsNone(plan['contact'])
        self.assertEqual(p.select_final_plan(f,[plan])['score']['winner_if_final'],'Force 136')
    def test_F1_resistance_neighbors(self):
        rows=[]
        for r in range(16,21):
            f=fixture(1);f['resistance']=r
            chosen=p.select_final_plan(f,final_candidates(f))
            self.assertEqual(chosen is not None,r>=17)
            rows.append(dict(resistance=r,selected=chosen['plan'] if chosen else None))
        RECEIPT['F1_neighbors']=rows
    def test_cap_aware_J4_does_not_replace_final_guard_on_keen_card(self):
        f=fixture(1);f['active_bot_card']='01'
        self.assertEqual(p.j4_rating(19,3),'B')
        # Card 01 would accept B. The final scoring rule must still precede it.
        self.assertEqual(p.select_final_plan(f,final_candidates(f))['plan'],'Normal SUPPLY')
    def test_six_current_campaign_events_do_not_trigger_guard(self):
        f=fixture(1);f['physical_cards_remaining']=2
        self.assertEqual(f['regular_events_seen_in_campaign'],6)
        self.assertFalse(p.final_check_due(f));self.assertIsNone(p.select_final_plan(f,final_candidates(f)))
    def test_guard_requires_japan_finished_campaign3_and_prop_remaining(self):
        for field,value in [('japan_has_acted',False),('campaign',2),('physical_cards_remaining',0),('final_propaganda_resolved',True),('mandatory_event_ends_game',True)]:
            f=fixture(1);f[field]=value;self.assertFalse(p.final_check_due(f),(field,value))
    def test_uncertain_plans_never_certified(self):
        f=fixture(1);plan=p.supply_plan(f);plan['uncertain_effects']=['J8 die']
        self.assertIsNone(p.select_final_plan(f,[plan]))
        plan['uncertain_effects']=['New concealed Intel reveal']
        self.assertIsNone(p.select_final_plan(f,[plan]))
    def test_hidden_values_never_change_guard_or_gather_targets(self):
        outputs=[]
        for hidden in (0,1,2,{'unreadable':'secret'}):
            f=fixture(1)
            for v in f['board'].values():v['intel_value']=hidden
            chosen=p.select_final_plan(f,final_candidates(f))
            outputs.append((chosen['plan'],chosen['score']['resistance_after'],p.gather_opportunities(f['board'])))
        self.assertTrue(all(x==outputs[0] for x in outputs))
    def test_first_guaranteed_plan_wins_without_searching_targets(self):
        f=fixture(1);a=p.supply_plan(f);b=copy.deepcopy(a);a['name']='First';b['name']='Second'
        self.assertEqual(p.select_final_plan(f,[a,b])['plan'],'First')
        with self.assertRaises(ValueError):p.select_final_plan(f,[a]*6)
    def test_final_projection_uses_net_then_clamps(self):
        f=fixture(1);score=p.final_projection(f['board'],19,0,3)
        self.assertEqual(score['net_change'],-2);self.assertEqual(score['resistance_after'],17)
        # Independently established F1: no majority; Neutral10; only2 Police sites.
        self.assertEqual((score['guerrilla_majorities'],score['neutral_population'],score['police_spaces']),(0,10,2))
    def test_clashes_return_red_to_available_before_recruitment(self):
        b=empty_board();b['Kedah'].update(red_u=1,blue_u=1,opposition=True)
        score=p.final_projection(b,0,0,0)
        self.assertEqual(score['clash_spaces'],1)
        self.assertEqual(score['recruited'],['Kedah']);self.assertEqual(score['board_after']['Kedah']['red_u'],1)
    def test_J15_shaded_restricts_recruitment_and_neutral_population(self):
        b=empty_board();b['Perak'].update(opposition=True,new_village=True)
        normal=p.final_projection(b,10,0,1);restricted=p.final_projection(b,10,0,1,True)
        self.assertEqual(normal['recruited'],['Perak']);self.assertEqual(restricted['recruited'],[])
        self.assertEqual(restricted['neutral_population']-normal['neutral_population'],3)
    def test_exhausted_red_pool_uses_bot_placement_priority(self):
        b=empty_board();b['Kedah']['opposition']=True;b['Perak'].update(opposition=True,force136=1)
        score=p.final_projection(b,0,0,1)
        self.assertEqual(score['recruited'],['Perak'])
    def test_inventory_after_F1_contact_supply(self):
        f=fixture(1);a=p.supply_plan(f)
        self.assertEqual(p.count(a['board'],'cache')+a['cache_available'],5)
        self.assertEqual(p.count(a['board'],'camp')+a['camp_available'],4)
        self.assertEqual(p.count(a['board'],'force136')+a['force136_available'],3)
        self.assertEqual(sum(p.gs(v) for v in a['board'].values()),11)
    def test_unavailable_full_box_cannot_supply(self):
        f=fixture(1);f['free_initiative_boxes']=['Limited','Event']
        self.assertIsNone(p.supply_plan(f))

class EventCapsAndTempo(unittest.TestCase):
    def test_F2_J26_at_cap_skipped_normal_strike_displaces(self):
        f=fixture(2);b=p.public_copy(f['board']);s='Negri Sembilan'
        faces=ambush_faces(p.cubes(b[s]),1)
        self.assertEqual(faces,6);self.assertIsNone(p.j26_rating(f['resistance'],faces))
        self.assertEqual(p.activate(b,s),'red')
        self.assertGreater(1+1,p.cubes(b[s]));b[s]['troops']-=1;b['Kuala Lumpur']['troops']+=1
        self.assertEqual(b[s]['troops'],0);self.assertEqual(p.count(b,'troops'),15)
        RECEIPT['F2']=dict(event_rating=None,normal_ambush_die=1,success_faces=faces,troops_left=0)
    def test_J26_nearby_real_gain_and_chance_cutoff(self):
        self.assertEqual(p.j26_rating(18,6),'A');self.assertEqual(p.j26_rating(19,3),'A')
        self.assertIsNone(p.j26_rating(18,2))
    def test_J4_actual_gain_boundaries(self):
        self.assertEqual([p.j4_rating(r,3) for r in (17,18,19,20)],['A','A','B',None])
    def f3_board(self):
        b=fixture(3)['board_after_operation']
        for s in ['Kedah','Perak','Negri Sembilan']:b[s]['red_u']=1;b[s]['red_a']=0
        return b
    def test_F3_post_sabotage_no_gather_selects_limited(self):
        b=self.f3_board();self.assertTrue(p.gather_opportunities(b))
        after=p.forecast_sabotage_activations(b,['Kedah','Perak','Negri Sembilan'])
        self.assertFalse(p.gather_opportunities(after));self.assertEqual(p.count(after,'cache'),0)
        chosen=initiative('RAIL',{'Event','Limited','Op & SA'},planned_special=bool(p.gather_opportunities(after)))
        self.assertEqual(chosen,'Limited')
        self.assertEqual(sum(v['red_u'] for v in b.values()),3) # planning didn't mutate the board
        RECEIPT['F3']=dict(box=chosen,remaining_gather_targets=0,underground_before=3,underground_after=0)
    def test_F3_neighbor_surviving_adjacent_guerrilla_uses_full_box(self):
        b=self.f3_board();b['Kelantan']['red_u']=1
        after=p.forecast_sabotage_activations(b,['Kedah','Perak','Negri Sembilan'])
        self.assertIn(('Perak','Kelantan'),p.gather_opportunities(after))
        self.assertEqual(initiative('RAIL',{'Limited','Op & SA'},bool(p.gather_opportunities(after))),'Op & SA')

class ActivationAndCardLife(unittest.TestCase):
    def test_F4_red_activated_blue_survives_following_forced_loss(self):
        f=fixture(4);b=p.public_copy(f['board']);s='Negri Sembilan'
        self.assertEqual(p.activate(b,s),'red');b[s]['police']-=1
        # Prescribed following J6 loss, die1: active before underground.
        self.assertEqual((b[s]['red_a'],b[s]['blue_u']),(1,1))
        b[s]['red_a']-=1
        self.assertEqual((b[s]['red_u'],b[s]['blue_u']),(0,1))
        RECEIPT['F4']=dict(activated='red',following_loss='red active',survivor='blue underground')
    def test_gather_and_sabotage_use_same_color_tie(self):
        for task in ('GATHER','RAIL','STRIKE'):
            b=empty_board();b['Kedah'].update(red_u=1,blue_u=1)
            self.assertEqual(p.activate(b,'Kedah'),'red',task)
    def test_required_color_overrides_global_priority(self):
        b=empty_board();b['Kedah'].update(red_u=1,blue_u=1)
        self.assertEqual(p.activate(b,'Kedah',('blue',)),'blue')
    def test_Raid_must_use_incoming_actor(self):
        b=empty_board();b['Kedah'].update(red_u=1,blue_u=1)
        incoming={'red':0,'blue':1}
        self.assertEqual(p.activate(b,'Kedah',incoming=incoming),'blue')
        self.assertEqual(b['Kedah']['red_u'],1)
    def test_Q1_matching_Event_never_completes_primary(self):
        for task in ('SUPPLY','INTEL','RAID','TRAIN','RAIL','STRIKE'):
            self.assertFalse(p.primary_complete(task,task,True,route='EVENT'))
            self.assertTrue(p.primary_complete(task,task,True,route='TASK'))
    def test_Q2_INTEL_holds_even_with_available_marker(self):
        b=fixture(1)['board']
        self.assertTrue(p.gather_opportunities(b));self.assertEqual(p.contact_for_intel(b,1),'HOLD')
    def test_Q2_no_current_gather_allows_normal_contact(self):
        b=empty_board();self.assertEqual(p.contact_for_intel(b,1),'PLACE_OR_MOVE')

class RailAndDenial(unittest.TestCase):
    def test_map_EC_not_adjacent_Selangor(self):
        self.assertNotIn('Selangor',p.ADJACENT['Northern EC'])
        self.assertIn('Kelantan',p.ADJACENT['Perak'])
    def test_U4_live_rails_drop_dead_spur_after_central_cut(self):
        all_live=p.live_rails(set());cut=p.live_rails({'Perak-Pahang-Selangor'})
        self.assertEqual(all_live,set(p.RAIL_EDGES))
        self.assertNotIn('Negri Sembilan-Pahang',cut)
        self.assertIn('Negri Sembilan-Johore *',cut)
        ranks=json.loads((ROOT/'bot_data.json').read_text())['rail_orders']['S']
        eligible={'Negri Sembilan-Pahang','Negri Sembilan-Johore *'}
        selected=min(eligible,key=lambda r:(r not in cut,ranks.index(r)))
        self.assertEqual(selected,'Negri Sembilan-Johore *')
        RECEIPT['U4']=dict(cut='Perak-Pahang-Selangor',dead_spur='Negri Sembilan-Pahang',selected=selected)
    def denial_fixture(self):
        b=empty_board()
        for s in ('Kuala Lumpur','Northern EC','Southern EC'):b[s]['force136']=1
        for s,g in [('Kedah',2),('Perak',2),('Pahang',2),('Selangor',2),('Trengganu',1)]:b[s]['red_u']=g
        for s,g in [('Kelantan',2),('Negri Sembilan',1),('Johore',1)]:b[s]['blue_u']=g
        for s in ('Kedah','Perak','Pahang'):b[s].update(cache=True,camp=True,opposition=True)
        b['Trengganu']['opposition']=True  # J14 Mobilize, before normal turns
        for s in ('Kedah','Perak','Pahang','Selangor','Kelantan'):b[s]['troops']=1
        for s,n in [('Kuala Lumpur',5),('Northern EC',3),('Southern EC',2)]:b[s]['troops']=n
        b['Kuala Lumpur']['police']=6;b['Perak']['kempeitai']=3
        # All chits revealed, legal 3x each value; no Gather remains.
        for s,value in zip(p.ORDER[:9],[0,0,0,1,1,1,2,2,2]):b[s]['intel_revealed']=True;b[s]['intel_value']=value
        return dict(id='U3',board=b,cache_available=0,camp_available=1,force136_available=0,
                    red_available=1,blue_available=0,zipper=0,free_initiative_boxes=['Limited','Event','Op & SA'],
                    campaign=1,resistance=9,japanese_resources=0,capabilities=[],event='J14',active_bot_card='02')
    def test_U3_declined_B_with_no_productive_normal_route_can_deny(self):
        f=self.denial_fixture();b=f['board']
        self.assertIsNone(p.supply_plan(f))
        self.assertFalse(p.gather_opportunities(b))
        # No Force136 has a guerrilla, Camp or cache: only KL's blue Train
        # would be legal, but Available blue is empty and all donors protected.
        self.assertTrue(all(not p.gs(v) and not v['camp'] and not v['cache'] for v in b.values() if v['force136']))
        self.assertEqual(f['blue_available'],0)
        self.assertTrue(all(not p.donor_allowed(v) for v in b.values() if p.gs(v)))
        self.assertTrue(all(not(v['red_a'] or v['blue_a']) for v in b.values()))
        # Contact cannot advance SUPPLY without an Available cache; no F is
        # exposed to Kempeitai; Raid cannot draw from any protected cache donor.
        self.assertTrue(all(not v['kempeitai'] for v in b.values() if v['force136']))
        normal='PASS'
        self.assertTrue(p.event_denial('B',False,True,False,normal))
        (ROOT/'fixtures'/'U3.json').write_text(json.dumps(f,indent=2)+'\n')
        RECEIPT['U3']=dict(normal_route='PASS',declined_rating='B',choice='Event Pass/Contact',gather_available=False)
    def test_U3_productive_supply_does_not_get_replaced(self):
        f=fixture(1);self.assertIsNotNone(p.supply_plan(f))
        self.assertFalse(p.event_denial('B',False,True,False,'SUPPLY'))
    def test_U3_no_denial_after_japan_acted_or_event_taken(self):
        self.assertFalse(p.event_denial('B',False,True,True,'PASS'))
        self.assertFalse(p.event_denial('B',False,True,False,'PASS',False))
    def test_U3_no_threat_or_accepted_B_not_denial(self):
        self.assertFalse(p.event_denial('B',False,False,False,'PASS'))
        self.assertFalse(p.event_denial('B',True,True,False,'PASS'))
    def test_U4_post_Propaganda_Train_can_recover_cache_guards(self):
        f=json.loads((ROOT/'fixtures/U4.json').read_text());b=p.public_copy(f['board']);pool=f['red_available'];guarded=[]
        for space in p.ORDER:
            v=b[space]
            if not(v['cache'] and v['force136']):continue
            self.assertEqual(p.gs(v),0)
            for _ in range(2):
                self.assertEqual(train_color(v['red_u'],v['blue_u'],v['camp'],v['cache'],pool,0),'red')
                v['red_u']+=1;pool-=1
            guarded.append(space)
        self.assertEqual(guarded,['Kedah','Negri Sembilan']);self.assertEqual(pool,2)
        self.assertEqual(sum(v['red_u']+v['red_a'] for v in b.values())+pool,10)
        self.assertTrue(all(p.gs(b[s])==2 for s in guarded))
        RECEIPT['U4_recovery']=dict(seed=136021,prescribed_bot_card='16',after_Train_guards={s:p.gs(b[s]) for s in guarded},
                                    red_available=pool,full_game=False,subsequent_Japanese_response_tested=False)
    def test_U4_cache_last_guard_still_protected(self):
        b=empty_board();b['Kedah'].update(cache=True,red_u=1)
        self.assertFalse(p.donor_allowed(b['Kedah']))
        b['Kedah']['red_u']=2;self.assertTrue(p.donor_allowed(b['Kedah']))

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    RECEIPT.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),
                   full_game_simulation=False,physical_playtest=False)
    (ROOT/'evidence').mkdir(exist_ok=True)
    (ROOT/'evidence'/'regression_results.json').write_text(json.dumps(RECEIPT,indent=2)+'\n')
    raise SystemExit(not result.wasSuccessful())
