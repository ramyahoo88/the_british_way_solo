#!/usr/bin/env python3
"""Verify each printed card in its own cell, all prose, table ranks and sheets.

Requires PyMuPDF. Checks artifacts, not complete game rules or playing strength.
Pass --output DIR to inspect copies, including intentionally damaged fixtures.
"""
from pathlib import Path
import argparse,json
import fitz
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'bot_data.json').read_text())
def norm(t):return ' '.join(t.split())
def card_rect(i):return fitz.Rect(36+(i%3)*180,167+(i//3)*252,216+(i%3)*180,419+(i//3)*252)

def verify(output=None):
    out=Path(output) if output else ROOT/'output'
    version=DATA['version'];layout=DATA['layout'];nr=layout['rule_pages'];ne=layout['event_pages'];rr=nr+ne;cc=rr+layout['reference_pages']
    full=fitz.open(out/f'Force_136_Solo_v{version}.pdf')
    cards=fitz.open(out/f'Force_136_Cards_v{version}.pdf')
    ref=fitz.open(out/f'Force_136_Reference_v{version}.pdf')
    assert len(full)==cc+layout['card_pages'] and len(cards)==3 and len(ref)==2,'Wrong page counts'
    pages=[norm(p.get_text()) for p in full];prose=0
    for i,(title,sections) in enumerate(DATA['rule_pages']):
        assert norm(title) in pages[i],('Missing rule title',title)
        for heading,text in sections:
            assert norm(heading) in pages[i],('Missing section',heading)
            assert norm(text) in pages[i],('Missing or stale rule prose',heading)
            prose+=1
    event_text=' '.join(pages[nr:rr])
    for jid,title,side,gate,target in DATA['events']:
        for item in (f'{jid} {title} [{side}]',gate,target):
            assert norm(item) in event_text,('Missing or stale Event entry',jid,item)
    for label,text in DATA['quick_reference']:
        assert norm(label+'. '+text) in pages[rr],('Stale quick reference',label)
    railpage=ref[1];ranks=0
    for name in DATA['rail_orders']['C']:
        matches=railpage.search_for(name)
        assert len(matches)==1,('Rail row not unique',name)
        line=matches[0]
        for j,region in enumerate(('N','C','S')):
            cell=fitz.Rect(366+70*j,line.y0-4,436+70*j,line.y1+4)
            expected=str(DATA['rail_orders'][region].index(name)+1)
            assert norm(railpage.get_text(clip=cell))==expected,('Wrong rail rank',name,region,expected)
            ranks+=1
    rects=0;fields=0
    for sheet,p in enumerate(cards):
        for slot,card in enumerate(DATA['cards'][sheet*6:sheet*6+6]):
            cell=card_rect(slot)
            expected=[card['id']+' '+card['primary'],f'FORCE 136 / v{version}',card['title'],card['preparation'],
                      card['other_special'],f"RAIL ORDER: {card['rail_order']} | B EVENTS: {card['b_events']}",
                      DATA['task_summaries'][card['primary']],DATA['card_reminder'],DATA['card_footer']]
            # Check both copies independently. A duplicated phrase elsewhere on
            # the page can never satisfy a missing field in this card's cell.
            for docpage in (p,full[cc+sheet]):
                text=norm(docpage.get_text(clip=cell))
                for item in expected:
                    assert norm(item) in text,('Missing or stale card field',card['id'],item)
                    fields+=1
                # No text in the card may escape its border or overlap the
                # separate reminder footer. Extents include all three columns.
                for block in docpage.get_text('dict',clip=cell)['blocks']:
                    for line in block.get('lines',[]):
                        for span in line['spans']:
                            box=fitz.Rect(span['bbox'])
                            assert cell.contains(box),('Card text outside cell',card['id'],span['text'])
            these=[d['rect'] for d in p.get_drawings() if abs(d['rect'].width-180)<.05 and abs(d['rect'].height-252)<.05 and abs(d['rect'].x0-cell.x0)<.05 and abs(d['rect'].y0-cell.y0)<.05]
            assert len(these)==1,('Missing poker-size card border',card['id'])
            rects+=1
        clip=fitz.Rect(25,85,590,720)
        assert p.get_pixmap(clip=clip).samples==full[cc+sheet].get_pixmap(clip=clip).samples,('Separate card sheet differs',sheet)
    for i,p in enumerate(ref):
        clip=fitz.Rect(25,85,590,720)
        assert p.get_pixmap(clip=clip).samples==full[rr+i].get_pixmap(clip=clip).samples,('Separate reference differs',i)
    spans=0
    for doc in (full,cards,ref):
        for p in doc:
            assert f'v{version}' in p.get_text(),('Stale page version',p.number)
            for block in p.get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        box=fitz.Rect(span['bbox']);spans+=1
                        assert box.x0>=20 and box.x1<=590 and box.y0>=12 and box.y1<=778,('Text outside page',p.number,span['text'])
                        assert '\ufffd' not in span['text'],('Broken glyph',span['text'])
    return dict(combined_pages=len(full),card_pages=len(cards),reference_pages=len(ref),
                rule_sections_matched=prose,event_entries_matched=32,cards_matched=18,
                card_field_matches_in_own_cells=fields,rail_rank_cells= ranks,
                poker_size_card_rectangles=rects,card_size_inches=[2.5,3.5],
                text_spans_in_page=spans,separate_sheets_match_combined_body_pixels=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output');args=ap.parse_args()
    print(json.dumps(verify(args.output),indent=2))
