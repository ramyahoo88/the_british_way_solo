from pathlib import Path
import re,html
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Preformatted,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
R=Path(__file__).resolve().parent
for name,file in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
ink=colors.HexColor('#18352F');pale=colors.HexColor('#EDF2EF');muted=colors.HexColor('#52645B')
styles={
 'body':ParagraphStyle('body',fontName='Body',fontSize=9.1,leading=12.1,textColor=ink,spaceAfter=6),
 'h1':ParagraphStyle('h1',fontName='Bold',fontSize=20,leading=24,textColor=ink,spaceAfter=10),
 'h2':ParagraphStyle('h2',fontName='Bold',fontSize=12,leading=16,textColor=ink,spaceBefore=10,spaceAfter=6,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='Body',fontSize=8,leading=10.8,textColor=ink),
 'code':ParagraphStyle('code',fontName='Mono',fontSize=7.2,leading=10,textColor=ink,backColor=pale,borderPadding=7,spaceAfter=8)}
def mark(t):
    t=html.escape(t)
    t=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',t)
    return re.sub(r'`([^`]+)`',r'<font name="Mono">\1</font>',t)
def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#A8B8AE'));c.line(36,34,576,34)
    c.setFont('Body',7);c.setFillColor(muted);c.drawString(36,21,'FORCE 136  |  v0.2 simulation study  |  20 November 2026')
    c.drawRightString(576,21,str(doc.page))
lines=(R/'Force_136_v0.2_Simulation_Report.md').read_text().splitlines();story=[];i=0
while i<len(lines):
    l=lines[i]
    if not l.strip():i+=1;continue
    if l.startswith('```'):
        chunk=[];i+=1
        while i<len(lines) and not lines[i].startswith('```'):chunk.append(lines[i]);i+=1
        story.append(Preformatted('\n'.join(chunk),styles['code']));i+=1;continue
    if l.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].startswith('|'):
            parts=[x.strip() for x in lines[i].strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?',x) for x in parts):rows.append([Paragraph(mark(x),styles['cell']) for x in parts])
            i+=1
        n=len(rows[0]);widths={3:[285,120,135],4:[115,140,140,145],5:[190,65,65,65,155]}[n]
        if n==4 and 'Batch' in rows[0][0].getPlainText():widths=[110,100,280,50]
        table=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),pale),('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LINEBELOW',(0,0),(-1,0),.7,muted),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#CAD4CE')),
            ('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
        story.extend([table,Spacer(1,9)]);continue
    if l.startswith('# '):story.append(Paragraph(mark(l[2:]),styles['h1']));i+=1;continue
    if l.startswith('## '):story.append(Paragraph(mark(l[3:]),styles['h2']));i+=1;continue
    chunk=[l];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```')):chunk.append(lines[i]);i+=1
    story.append(Paragraph(mark(' '.join(chunk)),styles['body']))
path=R.parent/'Force_136_v0.2_Simulation_Report.pdf'
doc=SimpleDocTemplate(str(path),pagesize=(612,792),leftMargin=36,rightMargin=36,topMargin=36,bottomMargin=47,
 title='Force 136 v0.2 - simulation findings',author='Force 136 development study')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(path)
