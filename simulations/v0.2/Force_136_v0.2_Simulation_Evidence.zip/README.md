# Force 136 v0.2 - behavior simulation study

20 November 2026. Research executor research-0.2. The frozen paper release is
in baseline/. It was not changed by this study. The human controls Japan in
standard standalone Japanese Occupation; the independent MPAJA can defeat both.

This is development evidence, not a published digital game, a physical
playtest, an optimal Japanese player, or a certified estimate of real win rates.
The executor follows games to third Propaganda or J9, with all normal actions,
32 Event effects, six capabilities, icons, scoring, stock accounting and deck
carryover. MODEL_SCOPE.md explains the remaining policy and interpretation limits.

The report distinguishes two concrete public-board weaknesses from conditional
simulation comparisons. The experimental priorities are code candidates, not
new official rules or a silently revised v0.2 release.

## Contents

- Force_136_v0.2_Simulation_Report.md: full findings and results.
- model/: executor, policies, validation, reproducible studies and analysis.
- fixtures/: official-example score snapshot and S1/S2 complete public positions.
- results/: final study data, all_runs.csv, statistics, check receipts and two full traces.
- baseline/: exact v0.2 source and printables from the supplied package.
- MODEL_SCOPE.md: modeled systems, explicit assumptions and exclusions.

## Run locally

Python 3 standard library is sufficient for simulations:

```text
python3 model/validate_engine.py
python3 model/run_study.py --n 32 --name discovery --variants baseline,recovery_first,cache_guard,late_intel,primary_first,combined
python3 model/run_study.py --start 136900 --n 64 --name confirmation --variants baseline,primary_first,primary_guard
python3 model/run_study.py --start 137300 --n 32 --name corner_sensitivity --variants baseline,primary_guard --corner
python3 model/run_study.py --start 137300 --n 32 --name interior_sensitivity --variants baseline,primary_guard
python3 model/run_controls.py
python3 model/check_scores.py
python3 model/behavior_witnesses.py
python3 model/analyze.py
```

The main study has 2,176 model runs. Another 128 runs independently check 384
post-recruitment score calculations and final winners. Initial exploratory
runs, an aborted technical run, unit-test games and witness replays are excluded
from that total. Matching seeds share Event deals, Intel shuffles, bot deck
shuffle streams and keyed dice; policies see only current public information.

Public fixtures are not Vassal saves. behavior_witnesses.py regenerates them and
asserts the stated alternatives. No game artwork or publisher rulebook is included.
Generating the report PDF also requires ReportLab and DejaVu Sans fonts.
