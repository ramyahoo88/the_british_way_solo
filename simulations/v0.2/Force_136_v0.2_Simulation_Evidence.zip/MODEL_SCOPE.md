# Scope and limits of research-0.2

The official reference is the 28-page GMT Japanese Occupation rulebook,
copyright 2026, checked during the prior audit against the public component
faces. The human Japan / Force 136 paper-bot version is v0.2, 20 November 2026.
No linked campaign, Personas, Pre-War Options or difficulty bonuses are used.

Rules URL:
https://gmtwebsiteassets.s3.us-west-2.amazonaws.com/TheBritishWay_EnemyofMyEnemy/EomE_JapOcc_Rules.pdf

Rules SHA-256:
ee65b70ce42cfe170d001c186fa16edcc5c1cb1fccfd7b1e4703184005fec370

Input ZIP SHA-256:
639e7eb7418a5784889fa8cc1b1b17acd8797138d18fe285e9b41d5c1c2a7ce1

## Executed systems

- Standard setup, 11 spaces, ordinary unit adjacency and eight railway links.
- Three six-Event piles, each Propaganda shuffled into its bottom three cards;
  unplayed Events carry between campaigns. Only the current card is visible.
- All four British operations, three Special Activities and printed pairings.
- All four Japanese operations and three Special Activities. Japanese candidates
  include Reprisal before and after the operation, simultaneous Sweep origins,
  and different troop concentrations. British timing stays operation first.
- All four MPAJA icons, Mandatory J6 and J9, both effects of all other Events,
  all six permanent capabilities, temporary away Troops/Force 136 and returns.
- Clashes, Available-only recruitment, net Resistance with rounding/clamping,
  Zipper cache releases/returns, final stop, nonfinal free actions and resets.
- Pool limits, mixed-color clashes, underground cache protection, automatic
  New Village removal, bot deck retention, reshuffles and information limits.

## What validation actually establishes

35 focused checks cover setup, deck construction, all Event-effect stock checks,
key capability interactions, the audit positions, simultaneous timing boundaries,
Raid donor reservation, color choice, hidden-information isolation and termination.
The official example's published pre-Propaganda board scores Resistance 6.
It is a scoring-snapshot check, not an independent replay of every example action.
Another 128 complete model traversals independently recalculate 384 score points
from the post-recruitment board. These verify arithmetic and winners; they do not
independently reimplement every operation or every target decision.

## Explicit assumptions and practical limits

- The paper rules are the target, but this new transcription is not independently
  certified line by line. End-to-end logs and focused public-board reproductions
  support the findings; the numeric rates remain conditional model results.
- Ordinary railway adjacency uses border-sharing Provinces plus the EC/Kuala
  Lumpur endpoints. A matched sensitivity adds northern corner contacts. This
  uncertainty is not treated as a new publisher ruling. J2 shaded eligibility
  uses Neutral Provinces/Kuala Lumpur, the spaces with an attitude level.
- Train visits spaces in map order when the paper gives no distinct Train-space
  priority. For a primary Raid, it conservatively reserves cache donors if an
  ordinary Train would otherwise consume the only usable Raid, then tries a
  Contact or hold. This is a bounded reading of the printed donor protection.
- British plan previews do not draw dice or inspect concealed Intel. They use
  the worst Ambush die for deciding deterministic follow-up activity; final
  certainty excludes new Intel reveals and die-dependent plans.
- Japanese players are deterministic, one-step heuristics with distinct weights
  for extraction, hunting, repair and adaptive suppression. They evaluate a
  median die in previews and an expected value of one for unknown Intel when
  an Event removes it. Actual resolution uses seeded dice and real chits. These
  are purposeful legal policies, not human calibration, deep search or optimal play.
- The two weak controls override only normal Japanese turns; free nonfinal
  Japanese Propaganda choices remain active. They are not a fully idle opponent.
- Shared Sabotage/Terror counter exhaustion beyond the listed physical supply
  is not used as an extra rules prohibition; observed maximum use is recorded
  separately. The rules specify stacking and supplies, not an artificial cost.
- No physical turn time, usability, fun or player adaptation was measured.
  Scenario runs are not physical playtests, and confidence intervals do not
  account for transcription error or untested human strategies.

## Experimental policies

baseline: v0.2 Event-first procedure.
recovery_first: at zero on-map Force 136, restore the network before other
Events; retain an accepted Event that itself restores a marker.
cache_guard: with a Force 136 cache under Troops and fewer than two guerrillas,
use useful Train; prefer Limited and omit Raid in that emergency turn.
late_intel: from the fourth current-campaign Event, prefer INTEL if it can reveal
at least two new chits. This is a heuristic, not knowledge of when Propaganda is next.
primary_first: when the normal route reaches the printed primary, take it before
an ordinary Event. Existing final-scoring and urgent-route checks remain.
combined: recovery_first + cache_guard + late_intel.
primary_guard: recovery_first + cache_guard + primary_first.

All candidates keep the same deck, target priorities and rules unless explicitly
stated above. No candidate was installed into the delivered paper release.
