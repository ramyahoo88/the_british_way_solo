"""Find full public positions and replay two concrete paper-policy weaknesses."""
from pathlib import Path
from copy import deepcopy
import json
from engine import *
ROOT=Path(__file__).resolve().parents[1]
def resume_public(d,seed):
    g=Game(seed);g.reset_intel(d['campaign']-1);g.board=deepcopy(d['board_before'])
    g.resistance=d['resistance'];g.resources=d['resources'];g.zipper=d['zipper'];g.track_cache=sum(t>g.zipper for t in [6,18])
    g.campaign=d['campaign'];g.regular_seen=d['regular_seen'];g.event=d['event'];g.draw=d['draw'];g.card=deepcopy(d['active_card']);g.age=d['card_age']
    g.cap={int(k):v for k,v in d['cap'].items()};g.sabotage=deepcopy(d['sabotage']);g.chosen=deepcopy(d['chosen_before'])
    g.lost_cache=5-g.count('cache')-g.track_cache-d['available']['cache'];g.lost_k=3-g.count('kempeitai')
    g.away_f=3-g.count('force136')-d['available']['force136'];g.away_troops=15-g.count('troops')
    g.deck=[33]*d['cards_remaining'];g.deck_pos=0;g.invariants();return g

def main():
    found={};chosen_trace={}
    for seed in range(136300,136332):
        for policy in ['adaptive','hunting','extraction','repair']:
            g=Game(seed);g.policy=policy;result=g.run()
            for d in g.decisions:
                if d['plan']['task']!='EVENT':continue
                if 'S1' not in found and sum(v['force136'] for v in d['board_before'].values())==0:
                    base=resume_public(d,seed);base.policy=policy
                    candidate=base.normal_plan(d['free'])
                    if candidate['op']=='CONTACT':
                        e=resume_public(d,seed);e.apply_bot_plan(d['plan']);c=resume_public(d,seed);c.apply_bot_plan(candidate)
                        if e.count('force136')==0 and c.count('force136')>0:
                            found['S1']=dict(id='S1',title='Event before network recovery',seed=seed,policy=policy,decision=d,
                               baseline_force136=e.count('force136'),counter_force136=c.count('force136'),counterplan=candidate,
                               baseline_after=e.board,counter_after=c.board,expected='A productive Contact exists; the Event gate postpones it. This is a behavior weakness, not an illegal action.')
                            chosen_trace['S1']={'result':result,'log':g.log}
                risk=[s for s,v in d['board_before'].items() if v['force136'] and v['cache'] and gs(v)<2 and v['troops']]
                if 'S2' not in found and risk and 'Limited' in d['free']:
                    following=[row for row in g.log if row['draw']==d['draw'] and row['kind']=='Japanese turn']
                    if not following or 'J' in d['chosen_before']:continue
                    losses=[s for s in risk if not following[-1]['board'][s]['cache']]
                    if not losses:continue
                    e=resume_public(d,seed);e.apply_bot_plan(d['plan']);c=resume_public(d,seed)
                    counter=dict(task='TRAIN',op='TRAIN',box='Limited',sa=None,no_sa=True,hold=False,route='cache_guard')
                    c.apply_bot_plan(counter)
                    if not all(gs(c.board[s])>=2 for s in losses):continue
                    after_train=deepcopy(c.board)
                    # Strong legal immediate counter: Reprisal BEFORE Assault.
                    c.reprisal(losses,limit=2);c.assault()
                    if not all(c.board[s]['cache'] for s in losses):continue
                    found['S2']=dict(id='S2',title='Events leave a threatened cache undefended',seed=seed,policy=policy,decision=d,
                           threatened_cache_spaces=losses,observed_Japanese_plan=following[-1]['detail'],baseline_after_Japan=following[-1]['board'],
                           counterplan=counter,counter_after_Train=after_train,counter_after_Reprisal_Assault=c.board,
                           expected='Train at a cache can add two underground guerrillas. One Reprisal cannot remove both; an underground guerrilla protects the cache from Assault.',
                           guarantee_scope='Immediate normal Japanese operation and Special Activity, not all future turns or arbitrary cache-removing Events.')
                    chosen_trace['S2']={'result':result,'log':g.log}
            if len(found)==2:break
        if len(found)==2:break
    assert len(found)==2,found.keys()
    for key,value in found.items():
        (ROOT/'fixtures'/f'{key}.json').write_text(json.dumps(value,indent=2)+'\n')
        (ROOT/'results'/f'{key}_full_trace.json').write_text(json.dumps(chosen_trace[key],indent=2)+'\n')
    out={k:{'seed':v['seed'],'policy':v['policy'],'draw':v['decision']['draw'],'campaign':v['decision']['campaign'],
            'event':v['decision']['event'],'card':v['decision']['active_card']['id'],'baseline_plan':v['decision']['plan'],
            'counterplan':v['counterplan']} for k,v in found.items()}
    (ROOT/'results/behavior_witnesses.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
