"""Policy-separated results and paired seed-cluster confidence intervals."""
from pathlib import Path
import csv,hashlib,json,random,statistics,collections
ROOT=Path(__file__).resolve().parents[1]
POL=['extraction','hunting','repair','adaptive']
def mean(xs):return sum(xs)/len(xs)
def ci(xs,seed=136999,B=12000):
    rng=random.Random(seed);n=len(xs);samples=sorted(mean([xs[rng.randrange(n)] for _ in range(n)]) for _ in range(B))
    return [samples[int(.025*B)],samples[int(.975*B)]]
def metric(r,k):return r['metrics'].get(k,0)
def summary(rows):
    n=len(rows);turns=sum(metric(r,'bot_turns') for r in rows)
    return dict(n=n,winners=dict(collections.Counter(r['winner'] for r in rows)),mean_R=mean([r['final_resistance'] for r in rows]),
      event_turn_fraction=sum(metric(r,'task_EVENT') for r in rows)/turns,
      mean_gather_reveals=mean([metric(r,'gather_reveals') for r in rows]),
      mean_unguarded_cache_turn_exposures=mean([metric(r,'unguarded_caches_end_bot') for r in rows]),
      mean_turns_without_recovery=mean([metric(r,'turns_without_recovery') for r in rows]),
      mean_caches_assaulted=mean([metric(r,'caches_assaulted') for r in rows]),
      mean_primary_turn_fraction=sum(metric(r,'route_task') for r in rows)/turns)
def paired(rows,a,b,k='R'):
    cells={(r['seed'],r['policy'],r['variant']):r for r in rows};seeds=sorted({r['seed'] for r in rows});effects=[]
    for seed in seeds:
        ds=[]
        for p in POL:
            x=cells[seed,p,a];y=cells[seed,p,b]
            get=lambda r:r['final_resistance'] if k=='R' else int(r['winner']=='Force 136') if k=='British_win' else metric(r,k)
            ds.append(get(y)-get(x))
        effects.append(mean(ds))
    return dict(first=a,second=b,outcome=k,mean_difference=mean(effects),seed_cluster_95CI=ci(effects),seed_clusters=len(effects))
def main():
    files=['discovery','confirmation','corner_sensitivity','interior_sensitivity','controls']
    batches={name:json.loads((ROOT/'results'/f'{name}.json').read_text()) for name in files}
    confirm=batches['confirmation']['runs'];allrows=[dict(r,batch=name) for name,b in batches.items() for r in b['runs']]
    table=[]
    for p in POL:
        for v in ['baseline','primary_first','primary_guard']:
            table.append(dict(policy=p,variant=v,**summary([r for r in confirm if r['policy']==p and r['variant']==v])))
    pooled={v:summary([r for r in confirm if r['variant']==v]) for v in ['baseline','primary_first','primary_guard']}
    comparisons=[paired(confirm,a,b,k) for a,b,k in [('baseline','primary_first','R'),('baseline','primary_guard','R'),
        ('primary_first','primary_guard','R'),('baseline','primary_guard','unguarded_caches_end_bot'),
        ('primary_first','primary_guard','unguarded_caches_end_bot'),('baseline','primary_first','British_win'),('baseline','primary_guard','British_win'),('primary_first','primary_guard','British_win')]]
    sensitivity={name:{v:summary([r for r in batches[name]['runs'] if r['variant']==v]) for v in ['baseline','primary_guard']} for name in ['corner_sensitivity','interior_sensitivity']}
    out=dict(study_model_runs=len(allrows),batch_sizes={n:len(b['runs']) for n,b in batches.items()},
        confirmation_by_policy=table,confirmation_pooled=pooled,paired_comparisons=comparisons,
        sensitivity=sensitivity,controls={p:{v:summary([r for r in batches['controls']['runs'] if r['policy']==p and r['variant']==v]) for v in ['baseline','primary_guard']} for p in ['regular_pass','repeat_extract']},
        model_hash=hashlib.sha256((ROOT/'model/engine.py').read_bytes()).hexdigest(),
        uncertainty='CIs are percentile paired bootstraps over seed clusters, averaging the four policies within each seed; conditional on this model and these heuristics, not real-player win-rate estimates.')
    (ROOT/'results/analysis.json').write_text(json.dumps(out,indent=2)+'\n')
    with (ROOT/'results/all_runs.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=['batch','seed','policy','variant','corner','winner','final_resistance','camps','force136','draws','ending','bot_turns','event_turns','gather_reveals','unguarded_cache_turn_exposures','turns_without_recovery']);w.writeheader()
        for r in allrows:
            row={k:r[k] for k in ['batch','seed','policy','variant','corner','winner','final_resistance','camps','force136','draws','ending']}
            row.update(bot_turns=metric(r,'bot_turns'),event_turns=metric(r,'task_EVENT'),gather_reveals=metric(r,'gather_reveals'),unguarded_cache_turn_exposures=metric(r,'unguarded_caches_end_bot'),turns_without_recovery=metric(r,'turns_without_recovery'));w.writerow(row)
    print(json.dumps({'runs':out['study_model_runs'],'pooled':pooled,'paired':comparisons},indent=2))
if __name__=='__main__':main()
