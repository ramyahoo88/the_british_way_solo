"""Replay one complete model traversal, including public decisions and dice."""
from pathlib import Path
import argparse,json,random
from engine import Game,stable
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);p.add_argument('--policy',default='adaptive');p.add_argument('--variant',default='baseline');p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    g=Game(a.seed);g.policy=a.policy;g.variant=a.variant;r=g.run()
    rolls=[dict(draw=key[0],action=key[1],space=key[2],call=i,result=random.Random(stable(g.seed,'die',*key,i)).randint(1,6))
           for key,n in g.roll_counts.items() for i in range(n)]
    a.output.write_text(json.dumps({'result':r,'public_decisions':g.decisions,'dice':rolls,'log':g.log},indent=2)+'\n')
    print(json.dumps(r))
