"""Independent post-recruitment arithmetic checks over selected full traces."""
from pathlib import Path
import json
from engine import Game
ROOT=Path(__file__).resolve().parents[1]
def check(log):
    n=0
    for row in log:
        if row['kind'] not in ['Nonfinal scoring','Final scoring']:continue
        d=row['detail'];b=d['score_board'];n+=1
        g=lambda v:sum(v[k] for k in ['red_u','red_a','blue_u','blue_a'])
        intel=sum(v['intel'] if v['intel'] is not None else 0 for v in b.values())
        caches=sum(v['cache'] for v in b.values());majorities=sum(g(v)>v['troops']+v['police'] for v in b.values())
        neutral=sum(v['population'] for v in b.values() if not v['opposition']);police=sum(v['police']>0 for v in b.values())
        delta=intel+caches+majorities-d['resources_used']//4-neutral//5-police//3
        expected=max(0,min(20,d['resistance_before']+delta))
        assert (intel,caches,majorities,neutral,delta,expected)==(d['intel'],d['caches'],d['majorities'],d['neutral_population'],d['net_change'],d['resistance_after'])
        if row['kind']=='Final scoring':
            camps=sum(v['camp'] for v in b.values());f=sum(v['force136'] for v in b.values())
            winner='Japan' if expected<18 else 'Force 136' if expected==20 or camps<f else 'MPAJA'
            assert winner==d['winner']
    assert n==3
    return n
if __name__=='__main__':
    count=0;games=0;max_markers=0;marker_witness=None
    for seed in range(137500,137516):
        for policy in ['extraction','hunting','repair','adaptive']:
            for variant in ['baseline','primary_guard']:
                g=Game(seed);g.policy=policy;g.variant=variant;g.run();count+=check(g.log);games+=1
                for row in g.log:
                    markers=sum(row['sabotage'].values())+sum(v['terror'] for v in row['board'].values())
                    if markers>max_markers:max_markers=markers;marker_witness=dict(seed=seed,policy=policy,variant=variant,draw=row['draw'])
    out=dict(additional_validation_runs=games,post_recruitment_score_points=count,all_match=True,max_shared_Sabotage_Terror_markers_in_validation=max_markers,marker_witness=marker_witness,
             seeds=list(range(137500,137516)),scope='Independent arithmetic and final winner; action execution and recruitment are checked separately, not independently reimplemented here.')
    (ROOT/'results/independent_score_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
