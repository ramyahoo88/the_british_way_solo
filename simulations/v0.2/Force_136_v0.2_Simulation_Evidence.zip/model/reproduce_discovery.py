"""Matched-seed strategy study of the development executor and paper policies."""
import argparse,collections,json,math,time
from pathlib import Path
from discovery_engine import Game
ROOT=Path(__file__).resolve().parents[1]
POLICIES=['extraction','hunting','repair','adaptive']
def run_batch(seeds,variants=('baseline',),corner=False,name='exploration',traces=False):
    results=[];start=time.time()
    for si,seed in enumerate(seeds):
        for policy in POLICIES:
            for variant in variants:
                g=Game(seed,corner);g.policy=policy;g.variant=variant
                try:result=g.run()
                except Exception as e:
                    (ROOT/'results'/'failed_state.json').write_text(json.dumps({'seed':seed,'policy':policy,'variant':variant,'error':repr(e),'trace':g.log},indent=2))
                    raise
                results.append(result)
                if traces:(ROOT/'results'/f'trace_{name}_{seed}_{policy}_{variant}.json').write_text(json.dumps({'result':result,'log':g.log},indent=2))
        if (si+1)%8==0:print(json.dumps({'batch':name,'seeds_completed':si+1,'runs_completed':len(results)}),flush=True)
    path=ROOT/'results'/f'{name}.json';path.write_text(json.dumps({'name':name,'corner':corner,'variants':variants,'seeds':list(seeds),'runs':results,'elapsed_seconds':time.time()-start},indent=2)+'\n')
    for policy in POLICIES:
        for variant in variants:
            rows=[r for r in results if r['policy']==policy and r['variant']==variant]
            print(json.dumps(dict(policy=policy,variant=variant,n=len(rows),wins=dict(collections.Counter(r['winner'] for r in rows)),mean_R=round(sum(r['final_resistance'] for r in rows)/len(rows),3),
                    no_recovery=round(sum(r['metrics'].get('turns_without_recovery',0) for r in rows)/len(rows),3),
                    unguarded=round(sum(r['metrics'].get('unguarded_caches_end_bot',0) for r in rows)/len(rows),3))),flush=True)
    print(json.dumps({'file':str(path),'seconds':round(time.time()-start,2)}),flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,default=136300);ap.add_argument('--n',type=int,default=32)
    ap.add_argument('--name',default='exploration');ap.add_argument('--variants',default='baseline');ap.add_argument('--corner',action='store_true');ap.add_argument('--traces',action='store_true');a=ap.parse_args()
    run_batch(range(a.start,a.start+a.n),a.variants.split(','),a.corner,a.name,a.traces)
