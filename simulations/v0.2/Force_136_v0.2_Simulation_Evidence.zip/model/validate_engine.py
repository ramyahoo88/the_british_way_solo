"""Rule examples, invariants and focused controls for the new research model."""
import copy,json,unittest
from pathlib import Path
from engine import *
ROOT=Path(__file__).resolve().parents[1]


def from_fixture(n):
    f=json.loads((ROOT/'baseline/fixtures'/f'F{n}.json').read_text());g=Game(136200+n)
    b=f.get('board',f.get('board_after_operation'))
    for s,v in b.items():
        for k in g.board[s]:
            if k in v:g.board[s][k]=v[k]
        g.board[s]['intel']=v.get('intel_value') if v.get('intel_revealed') else None
    g.resistance=f.get('resistance',2);g.resources=f.get('japanese_resources',0);g.campaign=f.get('campaign',1)
    g.zipper=f.get('zipper',0);g.track_cache=sum(t>g.zipper for t in [6,18]);g.event=int(f['event'][1:]);g.card=copy.deepcopy(DATA['cards'][int(f['active_bot_card'])-1])
    return g

class Rules(unittest.TestCase):
    def test_setup_inventory(self):
        g=Game(1);g.invariants();self.assertEqual([g.available(k) for k in ['red','blue','police','cache','camp','force136']],[4,2,3,2,1,1])
    def test_real_deck_three_piles_and_bottom_three_props(self):
        for seed in range(100):
            g=Game(seed);events=[j for j in g.deck if j<33];self.assertEqual(len(set(events)),18)
            for p in range(3):self.assertIn(33+p,g.deck[p*7+4:p*7+7])
    def test_all_icons_partition(self):
        self.assertEqual(MOBILIZE|FOOD|SEIZE|KILL,set(range(1,33)))
        self.assertEqual(sum(map(len,[MOBILIZE,FOOD,SEIZE,KILL])),32)
    def test_official_scoring_snapshot(self):
        f=json.loads((ROOT/'fixtures/official_example_before_score.json').read_text());g=Game(1)
        # Published example's board immediately before Propaganda.
        b=f['board']
        for s,v in b.items():
            for k in g.board[s]:
                if k in v:g.board[s][k]=v[k]
            g.board[s]['intel']=v['intel_value'] if v['intel_revealed'] else None
        g.resources=8;g.resistance=3
        score=g.score_only(False)
        self.assertEqual((score['intel'],score['caches'],score['majorities'],score['neutral_population'],score['net_change'],g.resistance),(4,1,3,13,3,6))
    def test_F1_score_all_three_lines(self):
        g=from_fixture(1);g.deck_pos=20;g.chosen={'J':'Limited'}
        g.apply_bot_plan(g.task_plan('SUPPLY',['Event','Op & SA']));self.assertEqual(g.score_only(True)['resistance_after'],20)
        for side,expected in [('U',(18,'MPAJA')),('S',(17,'Japan'))]:
            g=from_fixture(1);g.execute_event(4,side);g.score_only(True);self.assertEqual((g.resistance,g.winner),expected)
    def test_F1_keen_card_final_guard(self):
        g=from_fixture(1);g.card=copy.deepcopy(DATA['cards'][0]);g.deck_pos=20;g.chosen={'J':'Limited'}
        self.assertEqual(g.bot_choose(['Event','Op & SA'])['task'],'SUPPLY')
    def test_final_guard_alternative_has_trace_route(self):
        g=from_fixture(1);g.card=copy.deepcopy(DATA['cards'][8]);g.deck_pos=20;g.chosen={'J':'Limited'}
        plan=g.bot_choose(['Event','Op & SA']);self.assertEqual(plan['task'],'SUPPLY');self.assertEqual(plan['route'],'final_guard')
        g.bot_turn(['Event','Op & SA']);g.invariants()
    def test_two_distinct_active_guerrillas_can_both_refresh(self):
        g=Game(1)
        for v in g.board.values():v['red_u']=0;v['red_a']=0
        g.board['Johore']['red_u']=8;g.board['Perak'].update(red_a=2,red_u=0)
        g.train(['Perak']);self.assertEqual(g.board['Perak']['red_u'],2);self.assertEqual(g.board['Perak']['red_a'],0)
    def test_train_empty_site_can_use_legal_other_color(self):
        g=Game(1);g.board['Negri Sembilan']['red_u']=0;g.board['Perak']['red_u']=0;g.board['Johore']['red_u']=10
        # All red donors protect a strict majority at one Japanese cube margin.
        g.board['Johore']['troops']=9;g.board['Johore']['police']=0
        g.train(['Negri Sembilan']);self.assertEqual(g.board['Negri Sembilan']['blue_u'],1)
    def test_F2_cap(self):
        g=from_fixture(2);self.assertIsNone(g.event_rating(26));self.assertTrue(g.strike())
        self.assertEqual(g.board['Negri Sembilan']['troops'],0)
    def test_F3_and_neighbor_post_operation(self):
        for add,expected in [(False,'Limited'),(True,'Op & SA')]:
            g=from_fixture(3)
            for s in ['Kedah','Perak','Negri Sembilan']:g.board[s]['red_u']=1;g.board[s]['red_a']=0
            if add:g.board['Kelantan']['red_u']=1
            self.assertEqual(g.task_plan('RAIL',BOXES)['box'],expected)
    def test_F4_red_actor(self):
        g=from_fixture(4);g.strike();self.assertEqual(g.board['Negri Sembilan']['red_a'],1);self.assertEqual(g.board['Negri Sembilan']['blue_u'],1)
    def test_J8_remote_one_and_no_extra_slot(self):
        g=Game(1);g.cap[8]='U';g.supply();self.assertEqual(g.count('cache'),3);self.assertFalse(g.board['Johore']['camp'])
    def test_Supply_only_Province_no_second_cache(self):
        g=Game(1);g.supply();self.assertEqual(g.count('cache'),2);self.assertTrue(g.board['Perak']['camp']);g.invariants()
    def test_zipper_release_and_return(self):
        g=Game(1);g.move_zipper(3);self.assertEqual((g.zipper,g.available('cache')),(18,4));g.move_zipper(-3);self.assertEqual(g.available('cache'),2);g.invariants()
    def test_J14_permanent_removal(self):
        g=Game(1);g.execute_event(14,'S');self.assertEqual(g.lost_cache,1);self.assertEqual(g.available('cache'),2);g.move_zipper(3);g.invariants()
    def test_J14_fixed_placement_can_mix(self):
        g=Game(1);g.board['Kedah']['cache']=True;g.execute_event(14,'U');self.assertEqual(g.board['Kedah']['red_u'],1)
    def test_J15_neutral(self):
        g=Game(1);g.board['Perak']['new_village']=True;g.cap[15]='S';before=red(g.board['Perak']);score=g.score_only()
        self.assertEqual(red(g.board['Perak']),before);self.assertEqual(score['neutral_population'],14)
    def test_J19_restricted_adjacency(self):
        g=Game(1);g.cap[19]='S';g.board['Perak']['red_u']=0;g.board['Perak']['red_a']=2
        targets=g.gather();self.assertLessEqual(len(targets),5);self.assertEqual(len(targets),len(set(targets)))
    def test_J22_no_activation_still_requires_UG(self):
        g=Game(1);g.cap[22]='U';before=sum(ug(v) for v in g.board.values());g.gather();self.assertEqual(sum(ug(v) for v in g.board.values()),before)
        for v in g.board.values():v['red_a']+=v['red_u'];v['red_u']=0;v['blue_a']+=v['blue_u'];v['blue_u']=0
        self.assertFalse(g.gather())
    def test_J27_supply_removes_only_one_opposition(self):
        g=Game(1);g.cap[27]='S';g.board['Kedah'].update(force136=1,camp=True,opposition=True);g.board['Negri Sembilan']['opposition']=True
        before=g.count('opposition');g.supply();self.assertEqual(g.count('opposition'),before-1)
    def test_underground_guard_protects_cache(self):
        g=Game(1);s='Perak';g.board[s]['troops']=10;g.assault();self.assertTrue(g.board[s]['cache'])
    def test_camp_protects_F_until_J22(self):
        g=Game(1);g.die=lambda *args:6;g.eliminate(['Perak'],1);self.assertFalse(g.board['Perak']['camp']);self.assertEqual(g.board['Perak']['force136'],1)
        g=Game(1);g.cap[22]='S';g.die=lambda *args:6;g.eliminate(['Perak'],1);self.assertEqual(g.board['Perak']['force136'],0);self.assertTrue(g.board['Perak']['camp'])
    def test_J6_markers_not_forces(self):
        g=Game(1);g.board['Negri Sembilan']['red_u']=0;g.die=lambda *args:1;g.mandatory(6)
        self.assertTrue(g.board['Negri Sembilan']['camp']);self.assertEqual(g.board['Negri Sembilan']['force136'],1)
    def test_J9_final_stops(self):
        g=Game(1);g.campaign=3;g.event=9;g.icon(9);g.mandatory(9);self.assertTrue(g.ended);self.assertFalse(any(x['kind']=='Reset complete' for x in g.log))
    def test_score_clashes_return_red_before_recruit(self):
        g=Game(1);g.board['Kedah'].update(red_u=1,opposition=True);g.score_only();self.assertEqual(g.board['Kedah']['red_u'],1)
    def test_resources_round_down_amount_removed(self):
        g=Game(1);g.resources=7;g.execute_event(10,'U');self.assertEqual(g.resources,4)
    def test_new_village_automatic_removal(self):
        g=Game(1);g.board['Kedah']['new_village']=True;g.cleanup();self.assertFalse(g.board['Kedah']['new_village'])
    def test_live_rail_dead_spur(self):
        g=Game(1);self.assertEqual(sum(live_and_yield(g.sabotage)[1].values()),8)
        g.sabotage['Perak-Pahang-Selangor']=1;live,y=live_and_yield(g.sabotage);self.assertNotIn('Negri Sembilan-Pahang',live);self.assertEqual(sum(y.values()),4)
    def test_secret_and_future_cards_not_in_bot_selection(self):
        g=Game(21);g.event=5;g.ensure_card();g.chosen={};one=g.bot_choose(BOXES)
        g.secret={s:999 for s in ORDER[:9]};g.deck=list(reversed(g.deck));two=g.bot_choose(BOXES)
        self.assertEqual(one,two)
    def test_all_Event_effects_preserve_stock(self):
        for j in set(range(1,33))-{6,9}:
            for side in ['U','S']:
                g=Game(j);g.ensure_card();g.execute_event(j,side);g.invariants()
    def test_primary_Raid_reserves_cache_donors(self):
        g=Game(7)
        for v in g.board.values():v['red_u']=0;v['red_a']=0
        g.board['Perak']['red_u']=8;g.board['Perak']['cache']=False
        g.board['Johore'].update(red_u=2,cache=True)
        g.card=copy.deepcopy(DATA['cards'][16])
        plan=g.task_plan('RAID',BOXES);self.assertTrue(plan['reserve_cache_donors'])
        g.apply_bot_plan(plan);self.assertGreaterEqual(gs(g.board['Johore']),1);self.assertTrue(g.metrics.get('raid_destinations'))
        g.invariants()
    def test_J18_existing_blue_before_empty_Force136(self):
        g=Game(7);g.board['Perak']['red_u']=0;g.execute_event(18,'U')
        self.assertEqual(blue(g.board['Perak']),0);g.invariants()
    def test_seed_repeat(self):
        a=Game(136202).run();b=Game(136202).run();self.assertEqual(a,b)
    def test_all_policies_terminate_with_legal_inventory(self):
        for policy in ['extraction','hunting','repair','adaptive']:
            g=Game(136211);g.policy=policy;g.run();g.invariants();self.assertTrue(g.ended)

if __name__=='__main__':unittest.main(verbosity=2)
