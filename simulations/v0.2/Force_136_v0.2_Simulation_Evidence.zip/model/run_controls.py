"""Weak/repetitive Japanese controls. Nonfinal free Japanese choices remain active."""
from pathlib import Path
import json
from engine import Game,BOXES
ROOT=Path(__file__).resolve().parents[1]
def regular_pass(self,free):
    box=min(free,key=BOXES.index);self.chosen['J']=box
    self.inc('japan_PASS');self.record('Japanese turn',dict(op='PASS',box=box,benefit_declined=True))
def regular_extract(self,free):
    if 'Op & SA' in free:plan=dict(op='DEPLOY',box='Op & SA',sa='EXTRACT')
    elif 'Limited' in free:plan=dict(op='DEPLOY',box='Limited',sa=None)
    else:plan=dict(op='PASS',box='Event',sa=None)
    self.chosen['J']=plan['box'];self.jp_apply(plan);self.inc('japan_'+plan['op'])
    if plan.get('sa'):self.inc('japan_'+plan['sa'])
    self.record('Japanese turn',plan)
class PassGame(Game):
    japan_turn=regular_pass
class ExtractGame(Game):
    japan_turn=regular_extract

if __name__=='__main__':
    rows=[]
    for seed in range(137100,137132):
        for name,policy in [('regular_pass',PassGame),('repeat_extract',ExtractGame)]:
            for variant in ['baseline','primary_guard']:
                g=policy(seed);g.policy='extraction';g.variant=variant
                # Instance override is intentionally retained by the model's
                # shallow selector calls, but clones do not execute turns.
                result=g.run();result['policy']=name;rows.append(result)
    out={'scope':'Regular-turn override only; nonfinal free Construct, Reprisal and redeploy still use extraction heuristics.',
         'seeds':list(range(137100,137132)),'runs':rows}
    (ROOT/'results/controls.json').write_text(json.dumps(out,indent=2)+'\n')
    from collections import Counter
    for name in ['regular_pass','repeat_extract']:
        for variant in ['baseline','primary_guard']:
            group=[r for r in rows if r['policy']==name and r['variant']==variant]
            print(json.dumps(dict(policy=name,variant=variant,n=len(group),winners=dict(Counter(r['winner'] for r in group)),mean_R=sum(r['final_resistance'] for r in group)/len(group))))
