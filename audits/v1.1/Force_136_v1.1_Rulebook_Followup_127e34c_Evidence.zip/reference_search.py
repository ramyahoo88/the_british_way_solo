"""Check whether the shared J13 correction changes the published reference search player."""
from pathlib import Path
from multiprocessing import Pool
import sys,json
ROOT=Path(__file__).resolve().parent
CODE=Path(sys.argv[1]).resolve()/'force136_v1/code'
POLS=('extraction','hunting','repair','adaptive','counter','mixed')
def one(job):
 sys.path.insert(0,str(CODE));from expert import ExpertGame
 s,p=job;g=ExpertGame(s);g.weights=None;g.policy=p;r=g.run()
 return {'seed':s,'policy':p,'winner':r['winner'],'R':r['final_resistance']}
if __name__=='__main__':
 with Pool(2) as pool:rows=pool.map(one,[(s,p) for s in range(20000,20128) for p in POLS],chunksize=8)
 Path(sys.argv[2]).write_text(json.dumps(rows)+'\n')
 print(json.dumps({'games':len(rows),'British_wins':sum(r['winner']=='Force 136' for r in rows)}))
