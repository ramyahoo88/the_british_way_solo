"""Re-run the old single-space J13 policy, reusing the already recorded paired baseline."""
from pathlib import Path
from multiprocessing import Pool
import sys,json
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'source_snapshot/original' if (ROOT/'source_snapshot/original').exists() else ROOT.parent/'force136_review_127e34c'
CODE=REPO/'force136_v1/code'
sys.path.insert(0,str(CODE));import ev_study_v104 as S
if __name__=='__main__':
 basefile=ROOT/'evidence/baseline_v104.json'
 d=json.loads(basefile.read_text());base={(s,p):(w,R) for s,p,w,R in d['_base']}
 jobs=[(s,p,13,'use') for s in range(900000,901000) if 13 in S.deck(s) for p in S.POLS]
 with Pool(2) as pool:rows=pool.map(S.one,jobs,chunksize=16)
 out={'effect':S.summarize(rows,base,(13,'use')),'rows':rows,'baseline_file':'evidence/baseline_v104.json, _base'}
 (ROOT/'evidence/j13_old_use.json').write_text(json.dumps(out)+'\n');print(json.dumps(out['effect']),flush=True)
