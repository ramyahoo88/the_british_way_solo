"""Matched v1.1 northern railway-corner trial, with no Event-policy changes."""
from pathlib import Path
from multiprocessing import Pool
import sys,json
ROOT=Path(__file__).resolve().parent
REPO=ROOT/'source_snapshot/corrected' if (ROOT/'source_snapshot/corrected').exists() else ROOT.parent/'force136_rules_followup'
CODE=REPO/'force136_v1/code'
POLS=('extraction','hunting','repair','adaptive','counter','mixed')
def one(job):
 sys.path.insert(0,str(CODE));import force136_v1 as F
 s,p=job;g=F.Force136(s,corner=True);g.policy=p;r=g.run()
 return {'seed':s,'pol':p,'level':'agent','winner':r['winner'],'R':r['final_resistance'],'camps':r['camps'],'force136':r['force136'],'goals':{k[2:]:v for k,v in r['metrics'].items() if k.startswith('g_')}}
if __name__=='__main__':
 out=ROOT/'evidence/northern_wide';out.mkdir(parents=True,exist_ok=True)
 with Pool(2) as pool:rows=pool.map(one,[(s,p) for s in range(900000,901000) for p in POLS],chunksize=8)
 (out/'games.json').write_text(json.dumps(rows)+'\n')
 print(json.dumps({'games':len(rows),'British_wins':sum(r['winner']=='Force 136' for r in rows)}),flush=True)
