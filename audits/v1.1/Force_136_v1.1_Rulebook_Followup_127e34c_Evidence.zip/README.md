# Force 136 v1.1 — rulebook follow-up evidence

Reviewed repository: `ramyahoo88/the_british_way_solo`, branch `claude-force136`, commit `127e34cdabae591901124c66fdbeba2e80ee2102` (v1.1 plus main merged). Report date: 21 November 2026.

Read `Force_136_v1.1_Rulebook_Followup_127e34c.md` or its PDF first. This is an addendum to the preceding v1.1 audit, not a new bot version or a replacement for the publisher's rules. The official rules and artwork are linked in the report and are not bundled.

## Contents and scope

- `J13_multispace.patch`: a portable research-engine correction, retaining its existing Sabotage-before-Ambush policy. It changes only British J13. It does not add J13 to Force 136's Event choices or change the northern-adjacency default.
- `source_snapshot/original/`: pinned repository Python sources, native fixture data and text/flowchart inputs needed to run the focused checks. Large stored simulation results and shipped PDFs are omitted.
- `source_snapshot/corrected/`: the same inputs with only the J13 engine patch applied. These two snapshots differ in one file, `force136_v1/code/engine.py`.
- `evidence/`: native fixtures, exact per-game simulation records, baseline inputs, logs and derived analysis. `SOURCE_PIN.json` and `SHA256SUMS.txt` identify the inputs and included files.

The J13 experiment uses a **v1.0.4 baseline with no British Event step**, following the author's Event-study design. The railway experiment uses **current v1.1, Agent, J4/J25 unchanged**. The reference experiment uses **ExpertGame, weights=None**, not the Force 136 bot. Do not combine these denominators.

## Quick reproduction (Python 3.11+, standard library; tested with 3.12.14)

Run these commands from the extracted evidence directory. Use separate processes so imported engines cannot be mixed.

```sh
python3 fixture_driver.py source_snapshot/original
python3 fixture_driver.py source_snapshot/corrected --corrected
python3 single_reference_case.py source_snapshot/original
python3 single_reference_case.py source_snapshot/corrected
FORCE136_REPO=source_snapshot/corrected python3 event_boundaries.py
python3 source_snapshot/corrected/force136_v1/code/review_fixtures.py
python3 analyze.py
```

The native J13 assertions check two versus five Sabotage placements, two versus six Ambush attempts, no Special Activity, a one-space control and a blue-guerrilla exclusion control. Both versions also assert J2/J23 stacking, J19 anchor behavior and the two northern-adjacency settings.

The quick reference case is seed **20038 / repair / weights=None**. Original: Japan, Resistance 17. Corrected: Force 136, Resistance 20. The old search does not execute J13 in this live game; its previews differ and lead to a different choice. The corrected game executes British J13 at draw 16. This is a reproducible consequence of the shared engine change, not a claim that the two games remain paired after that decision.

`event_boundaries.py` reports 36 implementation executions plus five preview/hidden-information checks. The native suite reports 19 fixtures passed. `analyze.py` independently recomputes paired differences, checks all 6,000 corrected J13 controls against the retained baseline and verifies the reference comparison. The analysis bootstrap is deterministic, seed 33745, 10,000 whole-seed resamples; the native Event-study bootstrap uses seed 7 and 2,000 resamples. In both, a seed's six Japan policies stay together.

## Full simulation reproduction

These commands take longer. They overwrite the corresponding local evidence records; retain the supplied archive for comparison.

```sh
python3 run_old_j13.py
cd evidence/j13_corrected
python3 ../../source_snapshot/corrected/force136_v1/code/ev_study_v104.py confirm 13:use,13:deny,13:second 1000 900000
cd ../..
python3 wide_run.py
python3 reference_search.py source_snapshot/original evidence/reference_original.json
python3 reference_search.py source_snapshot/corrected evidence/reference_corrected.json
python3 analyze.py
```

J13 and railway cohorts: seeds **900000–900999**, each crossed with extraction, hunting, repair, adaptive, counter and mixed Japan. Each has 6,000 baseline seed-policy pairs. J13 variants run the subset whose deck includes J13 and store decision records only where it is reached; no-change games are baseline-equivalent. Tables describe the games where J13 was actually taken. The supplied `baseline_v104.json` and `narrow_v11_games.json` are retained inputs from the previous audit's fresh-seed runs, not newly generated controls from this follow-up.

Reference cohort: **20000–20127 × six policies = 768 games per engine**. The patched reference gains four wins overall; six winners and twelve final Resistance values differ. This study does not rerun the separate search-player/lookahead comparison or all 30,000 Force 136 level games.

To verify the patch, copy `source_snapshot/original` to a temporary directory and run `patch -p1 < /absolute/path/to/J13_multispace.patch` there. Compare the resulting engine's SHA-256 with `SOURCE_PIN.json`.

Rebuilding the review PDF requires ReportLab and the DejaVu fonts. `build_report.py` renders this audit only; it does not rebuild the author's print-and-play. No physical tabletop session was conducted in this follow-up.
