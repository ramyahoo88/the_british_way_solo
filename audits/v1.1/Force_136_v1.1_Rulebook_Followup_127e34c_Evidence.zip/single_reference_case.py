"""Fast native-engine reproduction of J13's effect on the reference search player."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(sys.argv[1])/'force136_v1/code'))
from expert import ExpertGame
class Seen(ExpertGame):
 def execute_event(self,j,side='U'):
  if j!=13 or self.preview:return super().execute_event(j,side)
  before={'R':self.resistance,'sabotage':dict(self.sabotage)}
  result=super().execute_event(j,side)
  self.event_records.append({'draw':self.draw,'side':side,'before':before,'after':{'R':self.resistance,'sabotage':dict(self.sabotage)}})
  return result
g=Seen(20038);g.event_records=[];g.weights=None;g.policy='repair';r=g.run()
print(json.dumps({'seed':20038,'policy':'repair','winner':r['winner'],'R':r['final_resistance'],'J13_live_executions':g.event_records},indent=2))
