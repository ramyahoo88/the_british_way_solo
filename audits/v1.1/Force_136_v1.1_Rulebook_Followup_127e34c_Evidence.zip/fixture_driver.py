"""Small rulebook-driven states. Called in separate processes for each code revision."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(sys.argv[1])/'force136_v1/code'))
import engine as E,force136_v1 as F
corrected='--corrected' in sys.argv[2:]
class Traced(F.Force136):
 def rail(self,*args,**kw):
  self.ops.append(('Sabotage',list(args[1]) if len(args)>1 and args[1] is not None else None));return super().rail(*args,**kw)
 def strike(self,*args,**kw):
  self.ops.append(('Ambush',list(args[0]) if args and args[0] is not None else None));return super().strike(*args,**kw)
 def special(self,*args,**kw):self.specials+=1;return super().special(*args,**kw)
 def die(self,tag,space=''):return super().die(tag,space) if self.preview else 6
def empty():
 g=Traced(1122001);g.board=E.new_board();g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3);g.ops=[];g.specials=0;return g
rows=[]
for name,spaces,kind in [('J13 multi-space Sabotage',['Kedah','Kelantan','Johore'],'rail'),('J13 two multi-space Ambush Operations',['Kedah','Kelantan','Johore'],'ambush'),('J13 one-space control',['Kelantan'],'rail'),('J13 blue-only control',['Kedah','Kelantan','Johore'],'blue')]:
 g=empty()
 for s in spaces:g.board[s]['blue_u' if kind=='blue' else 'red_u']=1 if kind=='blue' else 2
 if kind=='ambush':
  g.sabotage={r:1 for r in E.EDGES};g.board['Kuala Lumpur']['troops']-=6
  for s in spaces:g.board[s]['troops']=2
 g.invariants();g.execute_event(13,'U');g.invariants()
 assert g.specials==0
 if kind=='ambush':
  assert len(g.ops)==2 and all(op=='Ambush' for op,_ in g.ops)
  assert sum(len(s) for _,s in g.ops)==(6 if corrected else 2)
  assert g.resistance==(8 if corrected else 4)
 elif kind=='blue':assert not g.ops and sum(g.sabotage.values())==0
 elif len(spaces)==1:assert sum(g.sabotage.values())==2
 else:assert sum(g.sabotage.values())==(5 if corrected else 2)
 rows.append({'name':name,'ops':g.ops,'specials':g.specials,'sabotage':g.sabotage,'R':g.resistance,'red_active':{s:g.board[s]['red_a'] for s in spaces},'troops':{s:g.board[s]['troops'] for s in spaces}})
for j in (2,23):
 g=empty();g.sabotage={r:1 for r in E.EDGES}
 for s in E.PROV:g.board[s]['opposition']=True
 g.execute_event(j,'U');g.invariants()
 assert sum(g.sabotage.values())==8+(3 if j==2 else 2)
 assert sum(n==2 for n in g.sabotage.values())==(3 if j==2 else 2)
 rows.append({'name':f'J{j} Event stacking on already sabotaged railways','sabotage':g.sabotage})
g=empty();g.cap={19:'S'}
for s in ('Perak','Johore'):g.board[s]['force136']=1
for s in ('Perak','Kelantan','Johore','Negri Sembilan'):g.board[s]['red_u']=1
g.invariants();revealed=g.gather();g.invariants()
assert set(revealed)=={'Perak','Kelantan','Johore'} and g.board['Negri Sembilan']['intel'] is None
rows.append({'name':'J19 shaded still uses both selected spaces but adjacency only for one','revealed':revealed})
for corner in (False,True):
 g=empty();g.corner=corner
 sets={r:sorted(g.rail_adj(r)) for r in ('Thailand-Kedah *','Thailand-Perak','Thailand-Kelantan *')}
 g.sabotage={r:1 for r in E.EDGES};g.sabotage['Thailand-Kedah *']=0;g.board['Perak'].update(force136=1,red_u=1)
 choice=g.rail_choice('Perak')
 assert (choice=='Thailand-Kedah *') if corner else choice is None
 rows.append({'name':'northern railway-corner eligibility','corner':corner,'adjacent_spaces':sets,'Perak_only_open_target':choice})
print(json.dumps(rows,indent=2))
