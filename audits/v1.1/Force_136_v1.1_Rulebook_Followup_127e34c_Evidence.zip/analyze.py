"""Analyze the two isolated rulebook follow-ups, retaining exact paired identities."""
from pathlib import Path
from collections import defaultdict
import json,random
ROOT=Path(__file__).resolve().parent;E=ROOT/'evidence'
base=json.loads((E/'baseline_v104.json').read_text())['_base']
fixed=json.loads((E/'j13_corrected/ev_confirm_900000_1000.json').read_text())
assert base==fixed['_base'], 'J13 patch changed a V104 control game'
baseline={(s,p):(w,R) for s,p,w,R in base}
pols=('extraction','hunting','repair','adaptive','counter','mixed')
assert len(base)==len(baseline)==6000 and set(baseline)=={(s,p) for s in range(900000,901000) for p in pols}
old=json.loads((E/'j13_old_use.json').read_text())
oldrows={(r[0],r[1]):(r[4],r[5],r[6]) for r in old['rows']}
newrows={(r[0],r[1]):(r[2],r[3],r[4]) for r in fixed['13:use']['rows']}
j13={}
for label in ('first','second'):
 def selected(rows):return {k:v for k,v in rows.items() if v[2] and v[2]['take'] and v[2]['first']==(label=='first')}
 a=selected(oldrows);b=selected(newrows);assert set(a)==set(b)
 N=len(a);da=sum(int(v[0])-int(baseline[k][0]) for k,v in a.items());db=sum(int(v[0])-int(baseline[k][0]) for k,v in b.items())
 j13[label]={'taken_games':N,'old_difference_pp':100*da/N,'corrected_difference_pp':100*db/N,'improvement_from_correction_pp':100*(db-da)/N,'corrected_95':fixed['13:use']['effect'][label]['ci']}
 assert abs(old['effect'][label]['dwin']-100*da/N)<.006
 assert abs(fixed['13:use']['effect'][label]['dwin']-100*db/N)<.006
assert fixed['13:use']['effect']['second']==fixed['13:second']['effect']['second']
a=json.loads((E/'narrow_v11_games.json').read_text());b=json.loads((E/'northern_wide/games.json').read_text())
aa={(x['seed'],x['pol']):x for x in a};bb={(x['seed'],x['pol']):x for x in b}
assert len(a)==len(aa)==len(b)==len(bb)==6000 and set(aa)==set(bb)==set(baseline)
by=defaultdict(int)
for s,p in aa:by[s]+=(bb[s,p]['winner']=='Force 136')-(aa[s,p]['winner']=='Force 136')
values=[by[s] for s in sorted(by)];rng=random.Random(33745)
bs=sorted(100*sum(rng.choices(values,k=len(values)))/6000 for _ in range(10000))
wide={'games':6000,'narrow_wins':sum(x['winner']=='Force 136' for x in a),'wide_wins':sum(x['winner']=='Force 136' for x in b),'difference_pp':100*sum(values)/6000,'seed_bootstrap_95':[bs[249],bs[9749]],'by_policy':{p:{'narrow_wins':sum(x['winner']=='Force 136' for x in a if x['pol']==p),'wide_wins':sum(x['winner']=='Force 136' for x in b if x['pol']==p)} for p in pols}}
ra=json.loads((E/'reference_original.json').read_text());rb=json.loads((E/'reference_corrected.json').read_text())
ra={(x['seed'],x['policy']):x for x in ra};rb={(x['seed'],x['policy']):x for x in rb}
assert len(ra)==len(rb)==768 and set(ra)==set(rb)
ref={'games':768,'old_wins':sum(x['winner']=='Force 136' for x in ra.values()),'corrected_wins':sum(x['winner']=='Force 136' for x in rb.values()),'changed_winners':sum(ra[k]['winner']!=rb[k]['winner'] for k in ra),'changed_final_R':sum(ra[k]['R']!=rb[k]['R'] for k in ra),'example':{'old':ra[20038,'repair'],'corrected':rb[20038,'repair']}}
out={'seed_range':[900000,900999],'policies':pols,'J13_control_games_identical':6000,'J13_v104_trial':j13,'J13_deny_trial':fixed['13:deny']['effect'],'reference_search_J13_effect':ref,'northern_v11_trial':wide}
(E/'analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
