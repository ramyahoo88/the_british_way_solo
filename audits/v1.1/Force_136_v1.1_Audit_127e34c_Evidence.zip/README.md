# Force 136 v1.1 re-audit: 127e34c

Reviewed: `ramyahoo88/the_british_way_solo`, `claude-force136`, commit `127e34cdabae591901124c66fdbeba2e80ee2102` (v1.1 at `47e5a2d5d46905ad674de9e70e72d761ca4d2e0f`). No production file was changed by the review.

The PDF/Markdown gives the verdict, fresh paired results, exact optional refinements and coverage limits. The evidence contains 6,000 fresh matched Agent games per complete variant, the two single-Event trials on that cohort, independent data checks, fixtures, source identities and full raw logs. All fresh games use seeds **900000-900999**, six Japan policies. The additional differential fuzzer uses **1060000-1071999**.

## Included runtime and independent checks

`source_snapshot` is a small exact runtime/card-text snapshot. It includes the inputs needed for these checks, not all historical reports or the shipped PDFs. Python 3.11+ and the standard library suffice:

```sh
python event_boundaries.py
python victory_tie_fixture.py
python check_evidence.py
```

The Event fixtures run 18 cases through both implementations and add five hidden-information/pure-preview checks. The victory fixture isolates the 18/19 equal-Camp boundary and its nearby control. The independent analysis checks complete matched identities and recomputes all published level gains and the fresh combined gain.

Rerun the fresh single-Event experiments from an isolated output directory using `source_snapshot/force136_v1/code/ev_study_v104.py`:

```sh
python /absolute/path/to/source_snapshot/force136_v1/code/ev_study_v104.py confirm 4:second,25:second 1000 900000
```

Rerun the full current package with `holdout_v1.py 900000 1000 auditfresh agent`. Its recorded output is `evidence/package_fresh/results_auditfresh.json`; the baseline is `_base` in `evidence/event_confirmation_fresh/ev_confirm_900000_1000.json`. `check_evidence.py` pairs them and resamples whole seeds, preserving the six policies.

## Full-repository verification

For the entire author verification/report suite, use a complete checkout at the reviewed commit. Set `FORCE136_REPO` to its absolute path, then run:

```sh
python run_review_suite.py
python check_printed.py /absolute/path/to/the_british_way_solo
```

The printed-file check requires PyMuPDF. This review inspected the delivered PDFs; no Chrome PDF rebuild is claimed. `rendered/` thumbnails are omitted from this compact bundle, but the text/bounds/assembly checks and source hashes are retained.

The initial shortened mutation probe used **8** seeds and returned exit 1 because it missed the rare equal-Camp victory error. The complete **16**-seed run in `evidence/mutants_full/` catches all 17. This is fully disclosed in the report and both logs are included. The reproduction harness now uses the full setting by default. `victory_tie_fixture.py` demonstrates how a deterministic test avoids reliance on chance exposure. The legality self-test's ten negative controls are a separate set of tests.

`source_verification.json` verifies 222 release/source Git blobs. `SOURCE_PIN.json` records rules references and scope. `AUDIT_MANIFEST_SHA256.json` authenticates this bundle. Original publisher artwork and the publisher's rulebook are not redistributed. The shared engine, bounded Japanese policies and absence of physical tabletop playtesting remain important limits.
