"""Independently audit complete paired data and recompute published/fresh effects."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,gzip,json,random,os
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'source_snapshot' if (ROOT/'source_snapshot').exists() else ROOT.parent/'force136_review_127e34c'
REPO=Path(os.environ.get('FORCE136_REPO',str(DEFAULT)))
DATA=REPO/'force136_v1/code/results'
POLS=('extraction','hunting','repair','adaptive','counter','mixed')
LEVELS=('recruit','agent','veteran','legend','mastermind')
def csvload(name):
 rows=list(csv.DictReader(gzip.open(DATA/name,'rt')))
 keys=[(int(r['seed']),r['policy'],r['level']) for r in rows]
 assert len(keys)==len(set(keys))==30000
 assert set(keys)=={(s,p,l) for s in range(1000) for p in POLS for l in LEVELS}
 return dict(zip(keys,rows))
def paired(new,old,levels,bootstrap=10000):
 assert set(new)==set(old)
 out={}
 for level in levels:
  keys=sorted(k for k in new if k[2]==level);by=defaultdict(int)
  for s,p,l in keys:by[s]+=int(new[s,p,l]['win'])-int(old[s,p,l]['win'])
  values=[by[s] for s in sorted(by)];rng=random.Random(33745);n=len(keys)
  bs=sorted(100*sum(rng.choices(values,k=len(values)))/n for _ in range(bootstrap))
  out[level]={'games':n,'seeds':len(by),'old_wins':sum(old[k]['win'] for k in keys),'new_wins':sum(new[k]['win'] for k in keys),'old_rate':100*sum(old[k]['win'] for k in keys)/n,'new_rate':100*sum(new[k]['win'] for k in keys)/n,'difference_pp':100*sum(values)/n,'seed_bootstrap_95':[bs[int(.025*bootstrap)-1],bs[int(.975*bootstrap)-1]],'by_policy':{p:{'games':sum(k[1]==p for k in keys),'old_wins':sum(old[k]['win'] for k in keys if k[1]==p),'new_wins':sum(new[k]['win'] for k in keys if k[1]==p)} for p in POLS}}
 return out
old=csvload('results_fresh_v103.csv.gz');new=csvload('results_fresh_v110.csv.gz')
published=paired({k:{'win':r['winner']=='Force 136'} for k,r in new.items()},{k:{'win':r['winner']=='Force 136'} for k,r in old.items()},LEVELS)
def study(path,first,n):
 raw=json.load(gzip.open(path,'rt') if path.suffix=='.gz' else path.open())
 base={(s,p):(w,R) for s,p,w,R in raw['_base']}
 assert len(raw['_base'])==len(base)==n*6 and set(base)=={(s,p) for s in range(first,first+n) for p in POLS}
 out={}
 for spec,value in raw.items():
  if spec=='_base':continue
  rows=value['rows'];assert len(rows)==len({(r[0],r[1]) for r in rows})
  pos={}
  for label in ('first','second','second_lim','second_full','all'):
   rs=[r for r in rows if r[4]['take'] and (label=='all' or label=='first' and r[4]['first'] or label=='second' and not r[4]['first'] or label=='second_lim' and not r[4]['first'] and r[4]['normal'][0]=='Limited' or label=='second_full' and not r[4]['first'] and r[4]['normal'][0]=='Op & SA')]
   if not rs:continue
   d=[int(r[2])-int(base[r[0],r[1]][0]) for r in rs];N=len(rs)
   expected=value['effect'][label]
   assert expected['n']==N and abs(expected['dwin']-100*sum(d)/N)<.006
   pos[label]={'taken_games':N,'difference_pp':100*sum(d)/N,'policy_deltas':{p:sum(x for r,x in zip(rs,d) if r[1]==p) for p in POLS},'reported_seed_bootstrap_95':expected['ci']}
  out[spec]=pos
 return out
blocks={str(s):study(DATA/f'ev_confirm_{s}_1000.json.gz',s,1000) for s in (420000,430000)}
screen=json.loads((DATA/'ev_screen_410000_256.json').read_text())
assert {int(k.split(':')[0]) for k in screen if k!='_base'}==set(range(1,33))-{6,9}
first_use={int(k.split(':')[0]):v['effect']['first']['dwin'] for k,v in screen.items() if k.endswith(':use') and 'first' in v['effect']}
assert len(first_use)==30 and max(first_use.values())<0
result={'published_complete_grid':True,'published_levels':published,'confirmation_blocks':blocks,'screen_first_player_use_estimates':first_use,'screen_range':[min(first_use.values()),max(first_use.values())]}
fresh_study=ROOT/'evidence/event_confirmation_fresh/ev_confirm_900000_1000.json'
if fresh_study.exists():result['fresh_individual_events']=study(fresh_study,900000,1000)
fresh_package=ROOT/'evidence/package_fresh/results_auditfresh.json'
if fresh_package.exists() and fresh_study.exists():
 raw=json.loads(fresh_study.read_text());old={(s,p,'agent'):{'win':w} for s,p,w,R in raw['_base']}
 rows=json.loads(fresh_package.read_text());new={(r['seed'],r['pol'],'agent'):{'win':r['winner']=='Force 136'} for r in rows}
 assert len(rows)==len(new)==6000 and set(new)==set(old)
 result['fresh_combined_package']=paired(new,old,('agent',))
 result['fresh_combined_package']['bot_event_turns']=sum(r['goals'].get('EVENT',0) for r in rows)
(ROOT/'evidence/independent_data_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ('published_levels','fresh_individual_events','fresh_combined_package')},indent=2))
