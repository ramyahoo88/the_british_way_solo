"""Inspect delivered PDF text, tables/goal order and component assembly. Requires PyMuPDF."""
from pathlib import Path
import fitz,json,re,sys
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_127e34c'
PR=REPO/'force136_v1/print';rows=[];texts={}
for name in ('Rules','Reference','Cards','Record_Sheet','Sample_Game','Sim_Report','Print_and_Play'):
 d=fitz.open(PR/f'Force_136_v1_{name}.pdf');bad=[]
 for i,p in enumerate(d):
  for b in p.get_text('blocks'):
   if b[6]==0 and (b[0]<0 or b[1]<0 or b[2]>p.rect.width+.1 or b[3]>p.rect.height+.1):bad.append((i+1,b[:4]))
 assert not bad,(name,bad)
 rows.append({'document':name,'pages':len(d),'text_outside_page':bad})
 texts[name]=' '.join(' '.join(p.get_text().split()) for p in d)
for name in ('Rules','Reference','Cards','Sample_Game','Sim_Report'):
 assert 'J4' in texts[name] and 'J25' in texts[name],name
assert texts['Cards'].count('Japan acted first on J4 or J25')==9
assert 'Event box is free' in texts['Rules'] and 'Event box free' in texts['Reference']
assert 'British side (Contact + Supply)' in texts['Sample_Game']
rules=fitz.open(PR/'Force_136_v1_Rules.pdf')
for i,page in enumerate(rules):assert f'Force 136 rules · page {i+1}' in page.get_text()
cards=json.loads((PR/'cards.json').read_text());cardpdf=fitz.open(PR/'Force_136_v1_Cards.pdf')
for index,card in enumerate(cards):
 col=index%3;row=index//3;text=cardpdf[0].get_text(clip=fitz.Rect(36+col*180,18+row*252,36+(col+1)*180,18+(row+1)*252))
 assert card['name'] in text,(card['id'],'title')
 pos=0
 for goal in ['PLACE']+card['goals']+['CONTACT']:
  pos=text.index(goal,pos)+len(goal)
 assert card['limited_first'] in text.split('LIMITED OPERATION')[-1]
full=fitz.open(PR/'Force_136_v1_Print_and_Play.pdf');index=0
for name in ('Rules','Reference','Cards','Record_Sheet'):
 for page in fitz.open(PR/f'Force_136_v1_{name}.pdf'):
  assert full[index].get_text()==page.get_text(),(name,index)
  index+=1
assert index==len(full)==11
out={'documents':rows,'all_nine_card_names_and_goal_orders_checked':True,'combined_packet_matches_all_components':True,'optional_footer_omission':'Card reminder omits the Event-box-free guard; rules, reference and flowchart include it.'}
(ROOT/'evidence/printed_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
