"""Package the independent review without publisher artwork or historical bulk."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'force136_review_127e34c'
items={}
for name in ['README.md','SOURCE_PIN.json','source_verification.json','event_boundaries.py','victory_tie_fixture.py','check_evidence.py','check_printed.py','run_review_suite.py','build_report.py','make_package.py','Force_136_v1.1_Reaudit_127e34c.md','Force_136_v1.1_Reaudit_127e34c.pdf']:
 items[name]=(ROOT/name).read_bytes()
for p in sorted((ROOT/'evidence').rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:items[str(p.relative_to(ROOT))]=p.read_bytes()
code=REPO/'force136_v1/code'
for p in sorted(code.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or 'results' in p.relative_to(code).parts:continue
 if p.suffix in ('.py','.json','.md'):items['source_snapshot/'+str(p.relative_to(REPO))]=p.read_bytes()
for p in sorted((REPO/'force136_v1/print').iterdir()):
 if p.is_file() and p.suffix in ('.md','.json','.py','.svg'):items['source_snapshot/'+str(p.relative_to(REPO))]=p.read_bytes()
for name in ['results_fresh_v103.csv.gz','results_fresh_v110.csv.gz','ev_confirm_420000_1000.json.gz','ev_confirm_430000_1000.json.gz','ev_screen_410000_256.json']:
 p=code/'results'/name;items['source_snapshot/'+str(p.relative_to(REPO))]=p.read_bytes()
manifest={k:{'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in items.items()}
(ROOT/'AUDIT_MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
items['AUDIT_MANIFEST_SHA256.json']=(ROOT/'AUDIT_MANIFEST_SHA256.json').read_bytes()
out=ROOT/'Force_136_v1.1_Audit_127e34c_Evidence.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in items.items():z.writestr(name,data)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for name,meta in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==meta['sha256']
print(json.dumps({'files':len(items),'zip_bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
