"""Deterministic control for the rare 18/19 equal-Camp/marker victory mutation."""
from pathlib import Path
import sys,json,os
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'source_snapshot' if (ROOT/'source_snapshot').exists() else ROOT.parent/'force136_review_127e34c'
REPO=Path(os.environ.get('FORCE136_REPO',str(DEFAULT)))
sys.path.insert(0,str(REPO/'force136_v1/code'))
import engine as E,force136_v1 as F,verify_v1 as V
Bad=next(c for name,c,levels,forced,side in V.mutants() if name=='18-19 tie counted for Britain')
rows=[]
for R in (18,19):
 for camps in (1,2):
  for cls in (F.Force136,Bad):
   g=cls(11091002);g.board=E.new_board();g.resistance=R;g.lost_cache=3
   g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
   g.board['Perak'].update(force136=1,camp=True);g.board['Johore'].update(force136=1,camp=camps==2)
   # Mobilize produces two majorities; 14 Neutral Population costs two points.
   g.board['Kedah']['opposition']=True;g.board['Kelantan']['opposition']=True
   g.invariants();result=g.score_only(True);assert g.resistance==R,result
   expected='Force 136' if camps==1 or cls is Bad else 'MPAJA'
   assert g.winner==expected,(R,camps,cls,g.winner)
   rows.append(dict(R=R,camps=camps,force136=2,implementation=cls.__name__,winner=g.winner))
(ROOT/'evidence/victory_tie_fixture.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Actual bot: equal Camps/markers loses to MPAJA at 18 and 19; one fewer Camp wins. Planted tie error isolated in both equal cases.')
