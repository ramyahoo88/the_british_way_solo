"""Run v1.1 verification from pinned code; independent fresh position seeds.
No production file is modified. Each job has an isolated output folder.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import subprocess,sys,json,time,os
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'source_snapshot' if (ROOT/'source_snapshot').exists() else ROOT.parent/'force136_review_127e34c'
REPO=Path(os.environ.get('FORCE136_REPO',str(DEFAULT)))
CODE=REPO/'force136_v1/code'
JOBS={
 'fixtures':['review_fixtures.py'],
 'verify':['verify_v1.py','8'],
 'mutants':['verify_v1.py','--mutants','16'],
 'fuzz_fresh':['fuzz_v1.py','12000','1060000'],
 'legality_games':['legality_v1.py','games','32'],
 'legality_fuzz':['legality_v1.py','fuzz','12000'],
 'legality_selftest':['legality_v1.py','selftest'],
 'report':['report_check.py'],
 'exit_status':['check_exit_status.py'],
}
def run(item):
 name,args=item;out=ROOT/'evidence'/name;out.mkdir(parents=True,exist_ok=True);start=time.time()
 with (out/'stdout.txt').open('w') as so,(out/'stderr.txt').open('w') as se:
  p=subprocess.run([sys.executable,str(CODE/args[0])]+args[1:],cwd=out,stdout=so,stderr=se)
 row={'name':name,'arguments':args,'exit_code':p.returncode,'seconds':round(time.time()-start,2)}
 (out/'run.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);return row
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,JOBS.items()))
 (ROOT/'evidence/suite.json').write_text(json.dumps(rows,indent=2)+'\n')
 sys.exit(any(r['exit_code'] for r in rows))
