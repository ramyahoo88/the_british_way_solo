"""Independent J4/J25 fixtures for Force 136 v1.1. Run with Python 3.
Uses the actual engine; constructed positions are isolated rule/decision tests.
"""
from pathlib import Path
from copy import deepcopy
import sys,json,random,os
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'source_snapshot' if (ROOT/'source_snapshot').exists() else ROOT.parent/'force136_review_127e34c'
REPO=Path(os.environ.get('FORCE136_REPO',str(DEFAULT)))
CODE=REPO/'force136_v1/code'
sys.path.insert(0,str(CODE));sys.path.insert(0,str(CODE/'cleanroom'))
import engine as E,force136_v1 as F,cleanroom as C
rows=[]
def empty(cls,j,level='agent'):
 g=cls(11091001,level=level);g.board=E.new_board()
 g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
 g.event=j;g.chosen={'J':'Op & SA'};g.resistance=5
 return g
def no_contact(g):g.board['Perak']['force136']=3
def no_supply(g):g.lost_cache=3
def no_gather(g):g.removed_intel=set(E.ORDER[:9])
def minimal(g):return dict(seed=g.seed,event=g.event,chosen=g.chosen,board=g.board,resistance=g.resistance,zipper=g.zipper,lost_cache=g.lost_cache,track_cache=g.track_cache,removed_intel=sorted(g.removed_intel),level=g.level)
def run(name,setup,want_event,want_sa=None,expect=None):
 outcomes=[]
 for cls in (F.Force136,C.CleanForce136):
  g=setup(cls);g.invariants();before=deepcopy(minimal(g));free=[x for x in E.BOXES if x not in g.chosen.values()]
  g.bot_turn(free);g.invariants();p=g.last_plan
  assert (p['op']=='EVENT')==want_event,(name,cls.__name__,p)
  if want_sa is not None:assert p.get('sa')==want_sa,(name,cls.__name__,p)
  if expect:expect(g)
  outcomes.append((g.board,g.sabotage,g.resistance,g.cap,g.away_f,g.lost_cache))
  rows.append(dict(case=name,implementation=cls.__name__,before=before,free=free,plan=p,after=deepcopy(minimal(g))))
 assert outcomes[0]==outcomes[1],name
def check(cond):assert cond
def j4(cls):
 g=empty(cls,4);g.board['Perak'].update(force136=2,camp=True);g.board['Johore'].update(force136=1,camp=True);return g
run('J4 counts spaces, not stacked markers',j4,True,expect=lambda g:check(g.resistance==7))
def alter(g,**kw):
 for k,v in kw.items():setattr(g,k,v)
 return g
run('J4 caps Resistance at 20',lambda cls:alter(j4(cls),resistance=19),True,expect=lambda g:check(g.resistance==20))
run('J4 at 20 is declined',lambda cls:alter(j4(cls),resistance=20),False)
run('J4 as first player is declined',lambda cls:alter(j4(cls),chosen={}),False)
run('J4 with Event occupied is declined',lambda cls:alter(j4(cls),chosen={'J':'Event'}),False)
run('J4 after Japan Limited is allowed',lambda cls:alter(j4(cls),chosen={'J':'Limited'}),True)
def no_camps(cls):
 g=j4(cls)
 for v in g.board.values():v['camp']=False
 return g
run('J4 with markers but no matching Camp is declined',no_camps,False)
def contact_only(cls):
 g=empty(cls,25);no_supply(g);no_gather(g);return g
run('J25 Contact-only qualifies',contact_only,True,expect=lambda g:check(g.count('force136')==1 and not g.last_plan.get('sa')))
def supply_only(cls):
 g=empty(cls,25);no_contact(g);no_gather(g);g.board['Perak']['camp']=True;return g
run('J25 no Contact but Supply qualifies',supply_only,True,'SUPPLY',lambda g:check(g.board['Perak']['cache'] and not g.board['Perak']['camp']))
def gather_only(cls):
 g=empty(cls,25);no_contact(g);no_supply(g);g.board['Perak']['red_u']=1;return g
run('J25 no Contact but Gather qualifies',gather_only,True,'GATHER',lambda g:check(any(v['intel'] is not None for v in g.board.values())))
def raid_only(cls,level='agent'):
 g=empty(cls,25,level);no_contact(g);no_gather(g);g.board['Perak'].update(cache=True,red_u=2);return g
run('J25 no Contact but Raid qualifies',raid_only,True,'RAID')
run('Recruit skips Raid-only J25',lambda cls:raid_only(cls,'recruit'),False)
def nothing(cls):
 g=empty(cls,25);no_contact(g);no_supply(g);no_gather(g);return g
run('J25 all actions ineffective is declined',nothing,False)
run('J25 after Japan took Event is declined',lambda cls:alter(gather_only(cls),chosen={'J':'Event'}),False)
run('J25 as first player is declined',lambda cls:alter(gather_only(cls),chosen={}),False)
run('J25 after Japan Limited is allowed',lambda cls:alter(gather_only(cls),chosen={'J':'Limited'}),True,'GATHER')
def failed_j8(cls,roll):
 class Fixed(cls):
  def die(self,tag,space=''):
   return super().die(tag,space) if self.preview else roll
 g=supply_only(Fixed);g.cap={8:'S',27:'S'};g.board['Perak']['opposition']=True;return g
run('J25 Supply selected; failed J8 still removes J27 Opposition',lambda cls:failed_j8(cls,1),True,'SUPPLY',lambda g:check(g.board['Perak']['camp'] and not g.board['Perak']['cache'] and not g.board['Perak']['opposition']))
run('J25 Supply selected; J8 roll 3 converts Camp',lambda cls:failed_j8(cls,3),True,'SUPPLY',lambda g:check(not g.board['Perak']['camp'] and g.board['Perak']['cache'] and not g.board['Perak']['opposition']))

# Pure previews and hidden information. The target locations and Event decision
# must be independent of concealed Intel and future cards. Resolved Intel values
# may differ after a real Gather; that is not a hidden-information leak.
for make in (j4,supply_only,gather_only,raid_only,nothing):
 a=make(F.Force136);before=deepcopy(a.__dict__);decision=a.take_event(['Limited','Event'])
 assert a.__dict__==before,make.__name__+' preview mutated the live game'
 b=make(F.Force136);b.secret={k:2-v for k,v in b.secret.items()};b.deck=list(reversed(b.deck));b.dqueue=list(reversed(F.DECK))
 assert b.take_event(['Limited','Event'])==decision,make.__name__+' hidden information changed the Event decision'
 rows.append(dict(case=make.__name__+' Event preview pure and independent of hidden information',pass_=True))
out=ROOT/'evidence';out.mkdir(exist_ok=True)
(out/'event_boundaries.json').write_text(json.dumps(rows,indent=2,default=str)+'\n')
print(json.dumps({'cases':18,'implementation_executions':36,'hidden_information_checks':5,'failures':0}))
