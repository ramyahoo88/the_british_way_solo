# Reproduce the Force 136 print cleanup review

Pinned source: `ramyahoo88/the_british_way_solo`, commit `370ae906270464be64a304d95e6ee7a509c9fc1c`. Report date: 21 November 2026.

This archive contains the focused review, independent PDF checker and retained evidence. It does not duplicate the repository or the shipped game PDFs; obtain those from the pinned commit. No publisher artwork is included. `evidence/source_tree.json` identifies all 222 selected files by Git blob ID; `source_verification.json` records the successful local check.

Use Python 3.12 with PyMuPDF and Python-Markdown for the independent checker. Its repository argument must point to the directory containing `force136_v1/`:

```sh
python print_verify.py /path/to/pinned/repository
python /path/to/pinned/repository/force136_v1/code/review_fixtures.py
cd /path/to/pinned/repository/force136_v1/code
python report_check.py
```

`evidence/print_checks.json` records all source-text, card-order, page-count and pixel-composition checks. `runtime_and_manifest.json` records unchanged runtime inputs and the 220 package-manifest entries checked. The stored native check outputs are also included. These are verification runs, not new simulation samples.

`rebuild.py` is an optional adapter that invokes the repository's unmodified build functions with the installed `chromium` binary in place of `google-chrome`. It additionally needs pypdf and a working headless browser. Run `python rebuild.py /path/to/repository /path/to/output`. In this environment Chromium's process socket was denied; the included failure log is a coverage limit, not evidence of a bad shipped PDF. The failed attempt did not modify the shipped files.

P1 is optional: print the rules, reference and cards as separate jobs for duplex printing. The report contains exact page numbers and proposed wording. No source or shipped PDF was modified by this review.
