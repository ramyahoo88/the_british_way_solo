"""Focused checks of shipped Force 136 v1.1 printables at 370ae90.
Run: python print_verify.py /path/to/repository
Requires PyMuPDF and Python-Markdown. Uses no simulation outcomes.
"""
from pathlib import Path
from html.parser import HTMLParser
import sys,json,re,unicodedata,hashlib,importlib.util
import fitz,markdown

ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve()
PRINT=REPO/'force136_v1/print'
def norm(t):
 return ''.join(c for c in unicodedata.normalize('NFKD',t).lower() if c.isascii() and c.isalnum())
def text(d):
 return '\n'.join(re.sub(r'Force 136 rules · page \d+','',p.get_text()) for p in d)
class Blocks(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.items=[]
 def handle_starttag(self,tag,attrs):
  if tag in ('p','li','h2','h3','th','td'):self.stack.append([tag,[]])
 def handle_data(self,data):
  for _,bits in self.stack:bits.append(data)
 def handle_endtag(self,tag):
  if self.stack and self.stack[-1][0]==tag:
   name,bits=self.stack.pop();value=''.join(bits).strip()
   if value:self.items.append((name,value))

docs={name:fitz.open(PRINT/f'Force_136_v1_{name}.pdf') for name in ('Rules','Reference','Cards','Print_and_Play','Record_Sheet')}
want={'Rules':5,'Reference':2,'Cards':2,'Print_and_Play':9,'Record_Sheet':1}
assert {name:len(d) for name,d in docs.items()}==want
source=(PRINT/'Force_136_v1_Rules.md').read_text()
rt=text(docs['Rules']);rn=norm(rt)
for value in (source,rt):
 assert not re.search('simulat|computer|design notes|win rate',value,re.I)
 assert not re.search(r'\b(?:40|63|72|80|90)\s*%',value)
 assert norm('Start at Agent and move up after two wins in a row') in norm(value)
 assert norm('Mastermind is for Japan players who have learned the bot') in norm(value)
assert re.findall(r'^## (\d+)\.',source,re.M)==[str(i) for i in range(1,12)]
assert '## 11. Sources' in source
parser=Blocks();parser.feed(markdown.markdown('## 1. Overview'+source.split('## 1. Overview',1)[1],extensions=['tables']))
missing=[{'tag':tag,'text':value} for tag,value in parser.items if norm(value) and norm(value) not in rn]
assert not missing,missing
saved_argv=list(sys.argv)
sys.argv=['build.py',str(ROOT/'html_inputs')]
spec=importlib.util.spec_from_file_location('print_build_inputs',PRINT/'build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
sys.argv=saved_argv
ref_parser=Blocks();ref_parser.feed(build.build_reference())
ref_normalized=norm(text(docs['Reference']))
missing_ref=[{'tag':tag,'text':value} for tag,value in ref_parser.items if norm(value) and norm(value) not in ref_normalized]
assert not missing_ref,missing_ref
cells=[]
level=source.split('## 9. Levels',1)[1].split('## 10.',1)[0]
for line in level.splitlines():
 if line.startswith('|') and not re.fullmatch(r'[| :\-]+',line):
  parts=[s.strip() for s in line.strip('|').split('|')];assert len(parts)==2
  for s in parts:assert norm(s) in rn;cells.append(s)

cards=json.loads((PRINT/'cards.json').read_text())
page=docs['Cards'][0]
for i,card in enumerate(cards):
 col=i%3;row=i//3
 region=fitz.Rect(36+180*col,18+252*row,36+180*(col+1),18+252*(row+1))
 ct=norm(page.get_text(clip=region))
 assert norm(card['name']) in ct and f'directive{card["id"]}9' in ct
 goals=ct.split('opspecialactivity',1)[1].split('limitedoperation',1)[0]
 cursor=0
 for g in ['PLACE',*card['goals'],'CONTACT']:
  cursor=goals.index(norm(g),cursor)+len(norm(g))
 other='TRAIN' if card['limited_first']=='AMBUSH' else 'AMBUSH'
 limited=ct.split('limitedoperation',1)[1].split('japanactedfirst',1)[0]
 assert norm('PLACE'+card['limited_first']+other+'CONTACT') in limited
 assert norm('Japan acted first on J4 or J25 and the Event box is free') in ct
 assert norm('Otherwise never execute the Event') in ct

parts=[*docs['Rules'],*docs['Reference'],*docs['Cards']]
composition=[]
for i,(combined,individual) in enumerate(zip(docs['Print_and_Play'],parts),1):
 assert combined.get_text()==individual.get_text()
 a=combined.get_pixmap();b=individual.get_pixmap()
 assert (a.width,a.height,a.samples)==(b.width,b.height,b.samples)
 composition.append({'packet_page':i,'pixel_sha256':hashlib.sha256(a.samples).hexdigest()})
assert 'playtest record' not in text(docs['Print_and_Play']).lower()
assert 'playtest record' in text(docs['Record_Sheet']).lower()
outside=[]
for name,d in docs.items():
 for i,p in enumerate(d,1):
  for block in p.get_text('dict')['blocks']:
   for line in block.get('lines',[]):
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox']
     if min(x0,y0)<-1 or x1>p.rect.width+1 or y1>p.rect.height+1:outside.append([name,i,span['text']])
assert not outside,outside
result={'reviewed_commit':'370ae906270464be64a304d95e6ee7a509c9fc1c','page_counts':want,'source_blocks_found_in_rules_pdf':len(parser.items),'source_blocks_found_in_reference_pdf':len(ref_parser.items),'level_table_cells_verified':len(cells),'directive_cards_verified':len(cards),'packet_composition':composition,'outside_page_text':outside,'whole_packet_duplex_advisory':{'reference_pages':[6,7],'reference_sheets':[3,4],'card_pages':[8,9],'card_sheets':[4,5],'fix':'Print the separate reference and card PDFs as separate duplex jobs; print the rules separately.'}}
(ROOT/'evidence/print_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
