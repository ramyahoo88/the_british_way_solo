"""Rebuild unmodified print sources with the available Chromium executable."""
from pathlib import Path
import sys,subprocess,shutil,importlib.util
repo=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve()
out.mkdir(parents=True,exist_ok=True)
real_run=subprocess.run
def run(args,*a,**kw):
 if args[0]=='google-chrome':args=[shutil.which('chromium'),*args[1:]]
 return real_run(args,*a,**kw)
subprocess.run=run
sys.argv=['build.py',str(out)]
spec=importlib.util.spec_from_file_location('force136_print_build',repo/'force136_v1/print/build.py')
build=importlib.util.module_from_spec(spec);spec.loader.exec_module(build)
build.main()
