#!/usr/bin/env python3
"""Check printable contents against the exported original bot source.

Requires PyMuPDF. This validates artifacts, not the game rules or bot strength.
"""
from pathlib import Path
import json
import re
import fitz

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output' if (ROOT/'output').exists() else ROOT
DATA=json.loads((ROOT/'bot_data.json').read_text())

def norm(t):return ' '.join(t.split())

def verify():
    full=fitz.open(OUT/'Force_136_Solo_v0.1.pdf')
    cards=fitz.open(OUT/'Force_136_Cards_v0.1.pdf')
    ref=fitz.open(OUT/'Force_136_Reference_v0.1.pdf')
    assert len(full)==16 and len(cards)==3 and len(ref)==2
    pages=[norm(p.get_text()) for p in full]
    prose_count=0
    for i,(title,sections) in enumerate(DATA['rule_pages']):
        assert norm(title) in pages[i],('Missing rule title',title)
        for heading,text in sections:
            assert norm(heading) in pages[i],('Missing section',heading)
            assert norm(text) in pages[i],('Missing or stale rule prose',heading)
            prose_count+=1
    event_text=' '.join(pages[8:11])
    for jid,title,side,gate,target in DATA['events']:
        for item in [f'{jid} {title} [{side}]',gate,target]:
            assert norm(item) in event_text,('Missing or stale Event entry',jid,item)
    for label,text in DATA['quick_reference']:
        assert norm(label+'. '+text) in pages[11],('Stale quick reference',label)
    for region,seq in DATA['rail_orders'].items():
        assert norm(' > '.join(seq)) in pages[12],('Stale rail order',region)
    rects=0
    for i,p in enumerate(cards):
        part=norm(p.get_text())
        for card in DATA['cards'][i*6:i*6+6]:
            expected=[card['id']+' '+card['primary'],card['title'],card['preparation'],
                      card['other_special'],f"RAIL ORDER: {card['rail_order']} | B EVENTS: {card['b_events']}",
                      DATA['task_summaries'][card['primary']]]
            for item in expected:
                assert norm(item) in part,('Missing or stale card',card['id'],item)
        these=[d['rect'] for d in p.get_drawings() if abs(d['rect'].width-180)<.05 and abs(d['rect'].height-252)<.05]
        assert len(these)==6,('Wrong card dimensions/count',i,len(these))
        rects+=len(these)
        clip=fitz.Rect(25,85,590,720)
        a=p.get_pixmap(matrix=fitz.Matrix(1,1),clip=clip)
        b=full[13+i].get_pixmap(matrix=fitz.Matrix(1,1),clip=clip)
        assert a.samples==b.samples,('Separate card sheet differs',i)
    for i,p in enumerate(ref):
        clip=fitz.Rect(25,85,590,720)
        assert p.get_pixmap(clip=clip).samples==full[11+i].get_pixmap(clip=clip).samples,('Separate reference differs',i)
    span_count=0
    for doc in [full,cards,ref]:
        for p in doc:
            for block in p.get_text('dict')['blocks']:
                for line in block.get('lines',[]):
                    for span in line['spans']:
                        r=fitz.Rect(span['bbox']);span_count+=1
                        assert r.x0>=20 and r.x1<=590 and r.y0>=12 and r.y1<=778,('Text outside page',p.number,span['text'])
                        assert '\ufffd' not in span['text'],('Broken glyph',span['text'])
    return {'combined_pages':len(full),'card_pages':len(cards),'reference_pages':len(ref),
            'rule_sections_matched':prose_count,'event_entries_matched':len(DATA['events']),
            'cards_matched':len(DATA['cards']),'poker_size_card_rectangles':rects,
            'card_size_inches':[2.5,3.5],'text_spans_in_page':span_count,
            'separate_sheets_match_combined_body_pixels':True}

if __name__=='__main__':print(json.dumps(verify(),indent=2))
