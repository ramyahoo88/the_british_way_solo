#!/usr/bin/env python3
"""Narrow reference checks for the paper bot; THIS IS NOT A GAME ENGINE.

Standard-library checks cover the published card data and small independently
specified decision functions. They do not execute game actions, read a map,
simulate Events, or establish balance. Flags such as 'useful' are supplied by
the test fixture, not inferred from a complete board state.
"""
from dataclasses import dataclass
from pathlib import Path
from collections import Counter
import itertools
import json
import random
import unittest

ROOT = Path(__file__).resolve().parent
DATA = json.loads((ROOT/'bot_data.json').read_text())
CARDS = DATA['cards']
PAIRINGS = {
    'TRAIN': {'SUPPLY','RAID'},
    'CONTACT': {'SUPPLY','GATHER','RAID'},
    'RAIL': {'GATHER','RAID'},
    'STRIKE': {'GATHER','RAID'},
}
SPECIAL_TASKS = {'SUPPLY','INTEL','RAID'}

def winner(resistance, camps, force136):
    if not 0 <= resistance <= 20:
        raise ValueError('Resistance out of range')
    if min(camps,force136)<0:
        raise ValueError('Negative marker count')
    if resistance<18:return 'Japan'
    if resistance==20:return 'Force 136'
    return 'Force 136' if camps<force136 else 'MPAJA'

def ambush_faces(cubes, cache_bonus):
    if cubes<0 or cache_bonus<0:raise ValueError('Negative count')
    return sum(d+cache_bonus>cubes for d in range(1,7))

def strike(police, troops, kempeitai, cache_bonus=0, in_kl=False):
    """Choose a normal attack at one otherwise eligible location."""
    good=ambush_faces(police+troops,cache_bonus)>=3
    if kempeitai and good and not in_kl:return 'Kempeitai'
    if police:return 'Police'
    if troops and good and not in_kl:return 'Troop'
    return None

def first_special(operation, order, useful):
    return next((s for s in order if s in PAIRINGS[operation] and s in useful),None)

def initiative(task, free, planned_special=False, useful=True):
    """Choose a normal Initiative box for a known useful candidate task.

    None means the caller must try preparation; Event selection is separate.
    This function grants neither a Special Activity nor an action execution.
    """
    if not useful:return None
    if task in SPECIAL_TASKS:return 'Op & SA' if 'Op & SA' in free else None
    if planned_special and 'Op & SA' in free:return 'Op & SA'
    if 'Limited' in free:return 'Limited'
    if 'Op & SA' in free:return 'Op & SA'
    return None

def event_choice(rating, keen, event_available, mandatory=False):
    if mandatory or not event_available:return None
    if rating=='A' or (rating=='B' and keen):return 'Execute'
    if rating=='D':return 'Pass/Contact in Event'
    return None

def primary_complete(printed, performed, attempted):
    return printed==performed and attempted

def next_card_state(used_turns, primary_attempted, propaganda=False):
    """0 means discard/no active card; 1 means sideways with one turn left."""
    if used_turns not in (0,1):raise ValueError('Cards cannot survive two turns')
    if propaganda or primary_attempted or used_turns==1:return 0
    return 1

def train_color(red,blue,camp,cache,available_red,available_blue):
    """Available-pool placement only. Donor relocations are outside this model."""
    red_legal=camp or cache
    if red and not blue:return 'red' if red_legal and available_red else None
    if blue and not red:return 'blue' if available_blue else None
    if red and blue:
        if red>=blue:return 'red' if red_legal and available_red else None
        return 'blue' if available_blue else None
    if not red and not blue:
        if red_legal and available_red:return 'red'
        if available_blue:return 'blue'
    return None

def contact_can_escort(placing, source_blue, destination_red, donor_safe):
    return not placing and source_blue>0 and destination_red==0 and donor_safe

def generated_camp(action, marker_actually_moved_or_placed, province, already_camp):
    return action=='CONTACT' and marker_actually_moved_or_placed and province and not already_camp

def gather_opportunity(concealed, underground, covered, already_revealed_this_action=False):
    # There intentionally is no Intel-value argument.
    return concealed and underground>0 and covered and not already_revealed_this_action

def voluntary_donor_allowed(guerrillas,cubes,send,has_cache):
    if send<1 or send>guerrillas:return False
    remaining=guerrillas-send
    if has_cache and remaining<1:return False
    if guerrillas>cubes and remaining<=cubes:return False
    return True

class DeckData(unittest.TestCase):
    def test_eighteen_distinct_cards(self):
        self.assertEqual(len(CARDS),18)
        self.assertEqual([x['id'] for x in CARDS],[f'{i:02d}' for i in range(1,19)])
    def test_distribution(self):
        self.assertEqual(Counter(x['primary'] for x in CARDS),
                         Counter(SUPPLY=4,INTEL=4,RAIL=4,STRIKE=2,TRAIN=2,RAID=2))
    def test_six_event_keen_cards(self):
        self.assertEqual(sum(c['b_events']=='YES' for c in CARDS),6)
    def test_preparation_is_operation_only_and_no_duplicates(self):
        for c in CARDS:
            prep=c['preparation'].split(' > ')
            self.assertEqual(len(prep),len(set(prep)))
            self.assertTrue(set(prep)<=set(PAIRINGS))
            self.assertNotIn(c['primary'],prep)
    def test_other_special_order_valid(self):
        for c in CARDS:
            seq=c['other_special'].split(' > ')
            self.assertTrue(set(seq)<={'SUPPLY','GATHER','RAID'})
            self.assertEqual(len(seq),len(set(seq)))
    def test_complete_event_reference(self):
        self.assertEqual([e[0] for e in DATA['events']],[f'J{i}' for i in range(1,33)])
        self.assertEqual([e[0] for e in DATA['events'] if e[2]=='AUTO'],['J6','J9'])
    def test_each_rail_order_is_same_eight_rails(self):
        rails=DATA['rail_orders']
        for r in rails.values():
            self.assertEqual(len(r),8)
            self.assertEqual(len(set(r)),8)
            self.assertEqual(set(r),set(rails['C']))
            self.assertEqual(sum('*' in name for name in r),4)
        self.assertTrue(all(c['rail_order'] in rails for c in CARDS))
    def test_randomized_deck_cycling_and_two_turn_bound(self):
        # 500 deck cycles are NOT game simulations. Every cycle preserves
        # one copy per card and each individual card has a maximum of 2 uses.
        rng=random.Random(136001)
        for _ in range(500):
            deck=[c['id'] for c in CARDS];rng.shuffle(deck)
            drawn=[]
            for ident in deck:
                drawn.append(ident);uses=1
                state=next_card_state(0,rng.choice([False,True]))
                if state:
                    uses+=1;state=next_card_state(1,rng.choice([False,True]))
                self.assertEqual(state,0);self.assertLessEqual(uses,2)
            self.assertEqual(sorted(drawn),sorted(c['id'] for c in CARDS))

class Outcomes(unittest.TestCase):
    def test_japan_below_threshold(self):
        for r in [0,2,16,17]:self.assertEqual(winner(r,4,0),'Japan')
    def test_force136_at_twenty(self):
        self.assertEqual(winner(20,4,0),'Force 136')
    def test_british_tiebreak_needs_strictly_fewer_camps(self):
        for r in [18,19]:
            self.assertEqual(winner(r,1,2),'Force 136')
            self.assertEqual(winner(r,2,2),'MPAJA')
            self.assertEqual(winner(r,3,2),'MPAJA')
    def test_zero_markers_is_mpaJa_at_eighteen(self):
        self.assertEqual(winner(18,0,0),'MPAJA')
    def test_invalid_inputs(self):
        for args in [(-1,1,2),(21,1,2),(18,-1,2)]:
            with self.assertRaises(ValueError):winner(*args)

class InitiativeAndEvents(unittest.TestCase):
    def test_main_special_requires_its_box(self):
        for t in SPECIAL_TASKS:
            self.assertIsNone(initiative(t,{'Limited','Event'}))
            self.assertEqual(initiative(t,{'Op & SA','Event'}),'Op & SA')
    def test_plain_operation_preserves_initiative_without_special(self):
        self.assertEqual(initiative('TRAIN',{'Limited','Op & SA'}),'Limited')
    def test_useful_special_uses_full_box(self):
        self.assertEqual(initiative('RAIL',{'Limited','Op & SA'},True),'Op & SA')
    def test_op_sa_can_be_used_without_special_when_limited_taken(self):
        self.assertEqual(initiative('TRAIN',{'Op & SA','Event'}),'Op & SA')
    def test_blocked_boxes_not_selected(self):
        for task in set(PAIRINGS)|SPECIAL_TASKS:
            for size in range(4):
                for boxes in itertools.combinations(['Limited','Event','Op & SA'],size):
                    chosen=initiative(task,set(boxes),True)
                    self.assertTrue(chosen is None or chosen in boxes)
    def test_no_useless_main_attempt(self):
        self.assertIsNone(initiative('RAIL',{'Limited'},useful=False))
    def test_train_cannot_gather(self):
        self.assertIsNone(first_special('TRAIN',['GATHER'],{'GATHER'}))
        self.assertEqual(first_special('TRAIN',['GATHER','SUPPLY'],{'GATHER','SUPPLY'}),'SUPPLY')
    def test_attacks_cannot_supply(self):
        for op in ['RAIL','STRIKE']:
            self.assertIsNone(first_special(op,['SUPPLY'],{'SUPPLY'}))
    def test_contact_has_all_three_pairings(self):
        for sa in ['SUPPLY','GATHER','RAID']:
            self.assertEqual(first_special('CONTACT',[sa],{sa}),sa)
    def test_special_follows_card_order(self):
        self.assertEqual(first_special('CONTACT',['RAID','GATHER','SUPPLY'],{'GATHER','SUPPLY'}),'GATHER')
    def test_a_and_b_events(self):
        self.assertEqual(event_choice('A',False,True),'Execute')
        self.assertIsNone(event_choice('B',False,True))
        self.assertEqual(event_choice('B',True,True),'Execute')
    def test_mandatory_event_closes_box_even_when_immediate_effect_empty(self):
        self.assertIsNone(event_choice('A',True,True,mandatory=True))
    def test_occupied_event_not_stolen(self):
        self.assertIsNone(event_choice('A',True,False))
    def test_denial_is_event_pass_not_free_execution(self):
        self.assertEqual(event_choice('D',False,True),'Pass/Contact in Event')

class CardLife(unittest.TestCase):
    def test_preparation_retains_once(self):self.assertEqual(next_card_state(0,False),1)
    def test_second_preparation_discards(self):self.assertEqual(next_card_state(1,False),0)
    def test_primary_attempt_discards_including_failed_roll(self):
        self.assertEqual(next_card_state(0,True),0)
        self.assertTrue(primary_complete('STRIKE','STRIKE',True))
    def test_event_is_not_primary_completion(self):
        self.assertFalse(primary_complete('INTEL','EVENT',True))
    def test_limited_train_does_not_complete_intel(self):
        self.assertFalse(primary_complete('INTEL','TRAIN',True))
    def test_nonfinal_propaganda_discards_unfinished_card(self):
        self.assertEqual(next_card_state(1,False,propaganda=True),0)
    def test_invalid_third_turn_state(self):
        with self.assertRaises(ValueError):next_card_state(2,False)

class StrikeChecks(unittest.TestCase):
    def test_strictly_greater_than_cubes(self):
        self.assertEqual(ambush_faces(3,0),3)
        self.assertEqual(ambush_faces(4,0),2)
        self.assertEqual(ambush_faces(4,1),3)
    def test_impossible_roll(self):
        self.assertEqual(ambush_faces(6,0),0)
        self.assertIsNone(strike(0,6,1))
    def test_kempeitai_priority_at_good_odds(self):
        self.assertEqual(strike(1,2,1),'Kempeitai')
    def test_police_removal_when_shot_is_poor(self):
        self.assertEqual(strike(1,4,1),'Police')
    def test_kuala_lumpur_does_not_farm_displacement(self):
        self.assertIsNone(strike(0,2,1,in_kl=True))
        self.assertEqual(strike(1,2,1,in_kl=True),'Police')
    def test_troop_only_good_shot(self):
        self.assertEqual(strike(0,3,0),'Troop')
        self.assertIsNone(strike(0,4,0))

class PiecesAndInformation(unittest.TestCase):
    def test_red_recruit_needs_permission(self):
        self.assertEqual(train_color(0,0,False,False,5,2),'blue')
        self.assertIsNone(train_color(0,0,False,False,5,0))
    def test_cache_or_camp_allows_red(self):
        self.assertEqual(train_color(0,0,True,False,5,2),'red')
        self.assertEqual(train_color(0,0,False,True,5,2),'red')
    def test_avoid_mixed_recruits(self):
        self.assertEqual(train_color(0,1,True,True,5,2),'blue')
        self.assertEqual(train_color(1,0,True,True,5,2),'red')
        self.assertIsNone(train_color(0,1,True,True,5,0))
    def test_existing_mixed_group_reinforces_majority(self):
        self.assertEqual(train_color(2,1,True,False,5,2),'red')
        self.assertEqual(train_color(1,2,True,False,5,2),'blue')
        self.assertEqual(train_color(1,1,True,False,5,2),'red')
        self.assertIsNone(train_color(2,1,False,False,5,2))
    def test_contact_placement_has_no_escort(self):
        self.assertFalse(contact_can_escort(True,1,0,True))
        self.assertTrue(contact_can_escort(False,1,0,True))
    def test_contact_escort_obeys_donor_and_color(self):
        self.assertFalse(contact_can_escort(False,1,1,True))
        self.assertFalse(contact_can_escort(False,1,0,False))
    def test_only_actual_contact_move_generates_camp(self):
        self.assertTrue(generated_camp('CONTACT',True,True,False))
        for op in ['PROPAGANDA','J16','J28']:
            self.assertFalse(generated_camp(op,True,True,False))
        self.assertFalse(generated_camp('CONTACT',False,True,False))
        self.assertFalse(generated_camp('CONTACT',True,False,False))
    def test_no_second_camp(self):
        self.assertFalse(generated_camp('CONTACT',True,True,True))
    def test_gather_needs_real_underground_piece_and_concealed_chit(self):
        self.assertTrue(gather_opportunity(True,1,True))
        self.assertFalse(gather_opportunity(True,0,True))
        self.assertFalse(gather_opportunity(False,1,True))
        self.assertFalse(gather_opportunity(True,1,False))
    def test_gather_overlap_not_counted_twice(self):
        self.assertFalse(gather_opportunity(True,1,True,True))
    def test_protect_last_cache_defender(self):
        self.assertFalse(voluntary_donor_allowed(1,2,1,True))
        self.assertTrue(voluntary_donor_allowed(2,2,1,True))
    def test_preserve_existing_majority(self):
        self.assertFalse(voluntary_donor_allowed(3,2,1,False))
        self.assertTrue(voluntary_donor_allowed(4,2,1,True))

if __name__=='__main__':
    unittest.main(verbosity=2)
