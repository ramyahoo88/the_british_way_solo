# Force 136 - paper opponent for Japan

Version 0.1, 20 November 2026. Original unofficial automa prototype for the
standard standalone **Japanese Occupation** game in **The British Way: Enemy
of My Enemy**. The human plays Japan. The physical base game and expansion
are required. No app or computer is needed at the table.

Print `Force_136_Solo_v0.1.pdf` for the full 16-page package. The separate
card and reference PDFs are provided for reprinting. Cards are 2.5 x 3.5 inches;
print at actual size / 100%, single sided. Shuffle only the 18 bot cards.

This is a usable first draft. It has **not** been physically playtested or
validated with complete simulated games. Its competitive strength is not
established. The rules include a test plan and record sheet.

## Contents

- `Force_136_Solo_v0.1.pdf`: guide, all 32 Event decision entries, references,
  and all 18 cards.
- `Force_136_Cards_v0.1.pdf`: three card sheets.
- `Force_136_Reference_v0.1.pdf`: two reference sheets, including a test log.
- `Force_136_Rules_v0.1.md`: editable text of the original bot rules.
- `bot_data.json`: editable rules, Event policies and deck data.
- `build_force136.py`: deterministic PDF builder, using ReportLab and
  system DejaVu Sans fonts. Edit its source constants and rebuild to update
  both the exported JSON and the PDFs.
- `reference_checks.py`: small development checks; not an executable opponent
  or full game simulator.
- `verify_printables.py`: compares every original rules paragraph, all Event
  decision entries and every card against the PDFs; checks card dimensions
  and that the separate sheets match the complete PDF.
- `provenance.json`: source metadata and limits of validation.
- `validation.json`: exact validation results from this build.

## Development

Run `python3 reference_checks.py` for the standard-library checks. Run
`python3 build_force136.py` with ReportLab installed to rebuild the printables.
The 52 decision checks cover deck composition, selected initiative decisions, permitted
action pairings, limited information, bounded card retention, selected target
policies and victory boundaries. They do not model railway geometry, execute
actions, implement the complete Event deck, or test human strategies.

The source rulebook was read for development and is not included. The bot's
decision instructions use the physical Event cards and published player aids.
All official game rules, terminology, marks and artwork remain their owners'.
This is an independent fan variant, not a GMT publication.

## Deliberate scope limits

No linked campaign, Pre-War Options, Personas, difficulty levels, app,
voluntary cache recycling, multi-marker Contact relocation, or selected J17
Event policy. The bot deliberately takes a bounded subset of legal decisions.
The MPAJA remains the official independent actor; its victory is recorded as
a loss for both Japan and the British opponent.
