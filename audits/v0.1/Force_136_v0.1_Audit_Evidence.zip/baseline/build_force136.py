#!/usr/bin/env python3
"""Build an original, paper-first Force 136 automa prototype.

The source rulebook is a reference only and is not redistributed. This script
builds the bot's original decision rules and print sheets; it is not a game AI.
"""
from pathlib import Path
import hashlib
import json
import re
from xml.sax.saxutils import escape

from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'output'
VERSION = '0.1'
DATE = '20 November 2026'
SOURCE_URL = 'https://gamers-hq.de/media/pdf/6a/3a/5c/EomE_JapOcc_Rules.pdf'
PRODUCT_URL = 'https://www.gmtgames.com/p-1107-the-british-way-enemy-of-my-enemy.aspx'

CARDS = [
    ('01','Establish the network','SUPPLY','TRAIN > CONTACT > RAIL','N','YES','GATHER > RAID'),
    ('02','Equip the interior','SUPPLY','TRAIN > CONTACT > STRIKE','C','NO','RAID > GATHER'),
    ('03','Southern supply line','SUPPLY','CONTACT > TRAIN > RAIL','S','NO','RAID > GATHER'),
    ('04','Secure the caches','SUPPLY','TRAIN > CONTACT > STRIKE','C','NO','GATHER > RAID'),
    ('05','Northern intelligence','INTEL','TRAIN > CONTACT > RAIL','N','YES','RAID > SUPPLY'),
    ('06','Collect the reports','INTEL','CONTACT > TRAIN > STRIKE','C','NO','SUPPLY > RAID'),
    ('07','Coastal contacts','INTEL','TRAIN > CONTACT > RAIL','S','YES','SUPPLY > RAID'),
    ('08','Penetrate the defenses','INTEL','CONTACT > TRAIN > STRIKE','C','NO','RAID > SUPPLY'),
    ('09','Cut the trunk route','RAIL','TRAIN > CONTACT > STRIKE','C','NO','GATHER > RAID'),
    ('10','Disrupt the north','RAIL','CONTACT > TRAIN > STRIKE','N','NO','RAID > GATHER'),
    ('11','Disrupt the south','RAIL','TRAIN > CONTACT > STRIKE','S','NO','GATHER > RAID'),
    ('12','Deny the exports','RAIL','CONTACT > TRAIN > STRIKE','C','YES','RAID > GATHER'),
    ('13','Hunt the Kempeitai','STRIKE','TRAIN > CONTACT > RAIL','N','NO','GATHER > RAID'),
    ('14','Undermine the police','STRIKE','CONTACT > TRAIN > RAIL','S','NO','RAID > GATHER'),
    ('15','Recruit local resistance','TRAIN','CONTACT > RAIL > STRIKE','N','YES','SUPPLY > RAID > GATHER'),
    ('16','Rebuild the cells','TRAIN','CONTACT > RAIL > STRIKE','S','NO','SUPPLY > GATHER > RAID'),
    ('17','Spread the resistance','RAID','TRAIN > CONTACT > RAIL','C','NO','GATHER > SUPPLY'),
    ('18','Strike beyond the camps','RAID','TRAIN > CONTACT > STRIKE','S','YES','SUPPLY > GATHER'),
]

TASK_SHORT = {
    'SUPPLY':'Contact, then Supply. Establish defensible caches and reduce dependence on Jungle Camps.',
    'INTEL':'Contact, then Gather. Reach concealed intelligence using the guerrillas on the board.',
    'RAIL':'Sabotage. Use underground guerrillas to attack clear railways in this card\'s regional order.',
    'STRIKE':'Ambush. Select targets using the strike priorities; avoid attacks with no useful result.',
    'TRAIN':'Train. Reinforce compatible guerrilla groups, or refresh active guerrillas when useful.',
    'RAID':'Train if useful; otherwise Contact. Then Raid from a cache to an adjacent target.',
}

# These are original event-selection policies, not transcriptions of the cards.
# A, B and D are bot preference ratings. U/S name which printed option to use.
EVENTS = [
 ('J1','Sook Ching','U','A with at least 2 Terror markers; B with 1. Skip if Resistance already 20.','No bot target. Count markers without imagining future Japanese reprisals.'),
 ('J2','Greater East Asia Co-Prosperity Sphere','U','A if at least 2 clear railways are eligible; B if 1.','Use rail order. Fresh damage first; only then add another marker to an eligible damaged railway.'),
 ('J3','Overseas Chinese Association','U','A if at least 2 placements help without creating a mixed-color space; B if 1.','Place red with red, blue with blue or in an empty space. Use placement priorities. Skip rather than cause avoidable clashes.'),
 ('J4','Chin Peng','U / S','A if U raises Resistance by at least 2; B if by 1. Third campaign: use S instead only when current Resistance is 18-19, U cannot reach 20, and S would leave fewer Camps than Force 136. That S is A.','Count the printed eligible spaces. Do not treat a camp-count tie as a British win. Otherwise skip S.'),
 ('J5','Hill Rats','U','A if at least 2 active guerrillas at Force 136 or cache spaces become useful underground; B if 1.','No selection. Count only pieces that could enable Sabotage, Gather or a useful Ambush.'),
 ('J6','Jungle is Neutral','AUTO','Mandatory: resolve after the MPAJA icon. No Event box this round.','For a British loss, remove an active guerrilla before an underground one; remove a mixed-color minority first within that group; preserve a cache while any guerrilla can be lost. Markers are not wooden forces.'),
 ('J7','South East Asia Command','U','A if Gather can reveal at least 2 concealed chits; B if it can reveal 1, or Zipper can advance.','Use Gather priorities. Apply the track change and all its consequences before the free Gather.'),
 ('J8','Air Drops','U','A in campaigns 1-2. B early in campaign 3 if a Camp without Force 136 could be Supplied.','Use the printed capability whenever applicable; it adds no extra Supply slot. See capability checklist.'),
 ('J9','Atomic Bombings','AUTO','Mandatory: obey the physical card before either normal turn. No Event box.','If it ends the game, stop the bot procedure immediately and use the final scoring sequence. Do not finish the campaign first.'),
 ('J10','Rationing System','U','A with Japanese Resources at least 8; B with 2-7.','No target. With 0-1, skip. Use the physical card for its rounding instruction.'),
 ('J11','KMT Guerrillas','U','A if 2 northern spaces can make useful attacks; B if 1.','In each permitted space use RAIL before STRIKE, following normal target priorities. This Event supplies its own permissions; it is not an ordinary Force 136 operation.'),
 ('J12','Labor Service Corps','U','A in campaigns 1-2. B early in campaign 3 with Sabotage on the board.','When the capability offers Opposition after Japanese repairs, use Opposition priorities. This choice does not use a bot turn.'),
 ('J13','Lai Teck Betrayal','U','A if 2 useful permitted attacks exist; B if 1. D if there is no useful U attack and the printed Japanese option could threaten the last Force 136 marker.','Choose attacks one at a time: RAIL, then STRIKE. Use only the guerrillas and permissions named on the physical card. Recheck after the first attack.'),
 ('J14','Secret Army','U','A if at least 2 useful, non-mixing placements are possible; B if 1. Otherwise D if a cache on the map could be lost to the Japanese option.','Place only where instructed. If D, occupy Event and Pass with Contact instead of executing either option. Do not manufacture recruits by moving protected donors.'),
 ('J15','Resettlement Schemes','U','A in campaigns 1-2. B early in campaign 3 if a New Village exists.','When the Japanese Extract, use the compatible-color placement rule for each offered recruit. Follow the printed eligibility, even without Force 136.'),
 ('J16','Freddie Spencer Chapman','U','A if it brings an Available Force 136 marker into useful play, or moves a threatened marker to safety; B for another productive relocation.','Available markers before on-map moves. Select distinct Camp spaces, safe sites before hot sites, then ones useful for Supply, then more guerrillas, then map order. Do not create Camps with this Event.'),
 ('J17','Burma Theater','SKIP','The bot never selects this Event in v0.1.','If Japan selects it, resolve the physical card and normal track consequences. The bot does not model the trade-off between the two theaters.'),
 ('J18','Thai Administration','U','A if at least 2 useful, non-mixing placements are possible; B if 1.','Use only the eligible northern Provinces. Existing blue groups before empty spaces; avoid red groups. Use placement priorities.'),
 ('J19','Radios','U','A in campaigns 1-2. B early in campaign 3 if 3 Force 136 spaces could contribute to Gather.','Apply the printed capability. If the Japanese version is in play, choose the one anchor allowed to use adjacent guerrillas first.'),
 ('J20','Lim Bo Seng','U','B only late in a campaign, with at least 2 Force 136 on the map and 2 concealed chits, when an ordinary Gather could not reveal 2 this turn. Otherwise D if the Japanese option can remove the last Force 136.','For U remove the least productive, most exposed Force 136; reveal chits outside Kempeitai spaces first, then map order. Do not inspect concealed values. D means Event + Pass/Contact.'),
 ('J21','Malay Collaboration','U','A if at least 2 useful blue placements avoid red groups; B if 1.','Use placement priorities, keeping blue recruits together where practical. Do not move blue pieces out of protected cache or majority spaces merely to use this Event.'),
 ('J22','Jikeidan System','U','A in campaigns 1-2. B early in campaign 3 if Gather could use an underground guerrilla.','The positive capability changes activation, not Intel eligibility. The Japanese version changes which marker Eliminate may target; account for that when judging exposure.'),
 ('J23','Allied Bombing','U','A if at least 2 clear railways remain; B if 1. If all are damaged, B for extra damage.','Use rail order. Fill distinct clear targets before stacking; when only damaged targets remain, choose the fewest markers, then rail order.'),
 ('J24','Victory in Europe','U','A if the resulting free Supply can make at least 2 caches; B if it can make 1 or Zipper can advance.','Apply track consequences first, then Supply priorities. An extra cache released from the track is not automatically placed on the map.'),
 ('J25','John Davis','U','A if Contact plus its free Special Activity can complete SUPPLY, INTEL or RAID; B for another productive Contact.','Try SUPPLY, then INTEL, then RAID. Take only one Special Activity. Age the bot card once for a normal Event turn, never separately for the actions within it.'),
 ('J26','Subhas Chandra Bose','U','A if a permitted attempt can succeed on at least 3 die faces; otherwise skip.','Choose the best legal success chance, then most supporting caches, then map order. Use this Event\'s printed outcome, not the normal displacement outcome; Force 136 and an underground guerrilla are still needed unless the card says otherwise.'),
 ('J27','Jungle Conference','U','A in campaigns 1-2. B early in campaign 3 if an underground guerrilla without Force 136 could use the permission.','Include its extra legal location in ordinary RAIL and STRIKE. It does not grant an additional Special Activity or an extra Raid destination.'),
 ('J28','Operation Gustavus','U','A if a useful Available Force 136 or Available cache can be placed; otherwise D if the Japanese option could remove the last Force 136 or a cache.','Use an eligible Camp Province, no cache already there if a cache will be placed. Safe sites, then a new Force 136 location, then more guerrillas, then map order. Do not create or convert a Camp.'),
 ('J29','Kempeitai','U','A whenever at least 1 Kempeitai remains in the game.','Remove one threatening Force 136 first; then one guarding revealed positive Intel; then one with more Police; then map order. The removal is permanent: do not return it on later turns.'),
 ('J30','Malayan Volunteer Corps','U','A if Police can be removed from at least 2 eligible spaces; B if 1.','Remove exactly one Police from each selected eligible space, within the printed space limit. Use strike priorities for the target order.'),
 ('J31','Comfort Women','U','A if it removes at least 4 Resources; B if it removes 1-3. Skip when no Resources would be lost.','No bot target. Never reduce Resources below zero. Read the physical card for its historical context.'),
 ('J32','MPAJU','U','A if at least 2 useful red placements avoid mixed groups; B if 1. Otherwise skip.','Use only the printed eligible spaces. Do not resolve the Japanese option on behalf of the bot.'),
]

RULE_PAGES = [
('A paper opponent for Japan', [
 ('Scope and components', 'You play Japan in the standard standalone Japanese Occupation scenario. Force 136 is controlled by this original fan-made prototype; the MPAJA remains the game\'s existing independent actor. You need The British Way, Enemy of My Enemy, their physical Event cards and player aids, and the 18 bot cards. No application is required. Campaign linking, Pre-War Options and Faction Personas are outside v0.1.'),
 ('Set up', 'Use the published scenario setup without bonuses for either side. Shuffle the bot cards separately. Leave room for one active bot card and a bot discard pile. Use the printed map and railway orders on the reference sheet. The labels A, B and D in the Event guide are bot preferences, not new game rules. The bot begins with no active card.'),
 ('The bot turn', 'First finish the physical card\'s MPAJA icon and any Mandatory Event. Resolve them in the printed order and end the game immediately if instructed. Japan makes the choices assigned to Japan; use page 6 for British choices. When the British normal turn begins, draw a bot card only if there is no active one. Then follow the steps below.'),
 ('1. Check the Event', 'If the Event box is legally available, consult its J-number. Take an applicable A Event. Take a B Event only if the active bot card says B EVENTS: YES. If the row is D and no useful U option qualifies, select the Event box and Pass, using the normal Contact benefit. A skipped or unavailable Event sends you to step 2. AUTO Events never offer the Event box. Use the physical card\'s text for execution.'),
 ('2. Check two urgent needs', 'If no Force 136 remains on the map, try a productive Contact before the printed task. In campaign 3, if Resistance is at least 16 and Camps are at least as numerous as on-map Force 136, try SUPPLY first, or a Contact that places an Available Force 136 if Supply is unavailable. These are decision priorities only: they grant no extra action. If neither need can be addressed legally, continue.'),
 ('3. Attempt the card', 'Try the primary task, then preparation tasks from left to right, using pages 3-5. Skip an option with no permitted useful result. A primary task needing a Special Activity requires an Operation plan that preserves a useful target for it. Select the Initiative box using page 2: one Operation and at most one Special Activity. Recheck targets after every change.'),
 ('4. Keep or discard', 'Discard the card if its printed primary task was attempted, including a failed die roll or a revealed zero-value Intel chit. If an Event, urgent need or preparation used the turn instead, rotate a fresh card sideways and keep it for one more normal British turn. After that second turn discard it regardless. Free actions and MPAJA choices never age the card. Draw a replacement only at the next normal British turn. Shuffle the discard pile only when a draw is needed and the bot draw pile is empty.'),
 ]),
('How to resolve every choice', [
 ('Useful means a real opportunity', 'A recruit or refresh, a new useful Force 136 position, a legal new Sabotage marker, a permitted Ambush with a useful target, a cache placement, a new Intel reveal, or a Raid that can attack or gain a majority is useful. Unknown Intel counts as an opportunity regardless of its eventual value. Never look beneath a concealed chit, inspect future Events, invent a success or reroll a failure. A pure Contact hold may accompany a useful Special Activity.'),
 ('Initiative and the single action budget', 'SUPPLY, INTEL and RAID as primary tasks require the Operation & Special Activity box. If it is unavailable, try preparation. For RAIL, STRIKE, TRAIN or a preparation Operation, choose Operation & Special Activity if a compatible, useful Special Activity is available in the card\'s printed order; otherwise choose Limited Operation if available; otherwise choose Operation & Special Activity without a Special Activity if available. If no productive action can be taken, Pass in the leftmost legal box and use Contact if useful. Keep the mandatory-card Event restriction. Follow the printed cylinder order for next eligibility.'),
 ('Special Activity timing', 'Resolve the Operation first and then the one chosen Special Activity. The bot deliberately forgoes more elaborate interleaving in v0.1. For SUPPLY use Contact then Supply; for INTEL use Contact then Gather; for RAID use Train if useful, otherwise Contact, then Raid. A Contact movement option may move no markers when the existing positions support the Special Activity. After an ordinary Operation, choose the first useful compatible Special Activity from the card; if none is compatible and useful, omit it. Never add another Special Activity after a primary SUPPLY, INTEL or RAID.'),
 ('Map order and ties', 'Apply only the priorities stated for the decision, in order. Break remaining space ties by: Kedah, Perak, Kelantan, Trengganu, Pahang, Selangor, Kuala Lumpur, Negri Sembilan, Johore, northern Economic Center, southern Economic Center. Economic Centers have no Population or Intel. Treat their Population as zero for a preference only. Thailand, Singapore and Indonesia are not playable spaces. A specified reverse map order reverses this list. With no active card, use rail order C and Contact toward Supply if an Available cache exists, otherwise Intel.'),
 ('Opposition priorities', 'Among legal neutral targets, prefer a space whose Opposition will count normally at Propaganda, then larger Population, then no Terror, then map order. The Japanese side of J15 can make a New Village\'s Opposition ineffective at Propaganda without removing its marker. Terror is a prohibition only when the particular action says so; do not impose it on every Event effect. For removal of the bot\'s Opposition when a choice is assigned to Britain, reverse this preference.'),
 ('Protect donors and avoid clashes', 'For voluntary guerrilla relocations, preserve the last guerrilla at a cache and do not break a current strict guerrilla majority at the source. Do not mix red and blue through voluntary placement or movement. Exceptions are mandatory effects and effects with no legal alternative. These are bot choices, not new restrictions on Japan. One piece can be voluntarily placed or moved at most once during a given Operation or Raid. Do not recycle a cache from the map voluntarily in v0.1.'),
 ('Forced losses and global choices', 'When Britain chooses its own forced guerrilla loss: active before underground; then a minority color in a mixed group; then a space without a cache; then most guerrillas; then reverse map order. A tie between colors at one space loses blue first. Lose a cache only when the effect requires it or no eligible guerrilla can be lost. If forced to return a cache to Zipper after Available caches are exhausted, choose the cache with fewest guerrillas, then most Troops, then reverse map order.'),
 ]),
('Contact and Train', [
 ('CONTACT: choose a plan', 'Prefer placing an Available Force 136 in a Province without Force 136. If none is Available, move one on-map Force 136 to an adjacent playable space without Force 136, but only to escape exposure, enable the current primary task, or open a future Supply site. Do not relocate wooden red guerrillas with Contact. Do not exchange a marker from another place for an Available marker. A zero-move Contact is allowed only to accompany a useful Special Activity or as an unproductive Pass benefit.'),
 ('Contact destination priorities', 'First prefer no Kempeitai. Next prefer a site useful for this card\'s primary task: SUPPLY = a Province without a cache when an Available cache exists; INTEL = most concealed chits that could actually be Gathered from this new position; RAIL = an existing underground guerrilla beside a clear railway; STRIKE = an existing underground guerrilla with a useful attack; TRAIN = a cache, then a Camp; RAID = a cache with guerrillas to send. Next prefer more guerrillas, then larger Population, then map order. A placement cannot carry a blue guerrilla, so do not count an imagined escort when assessing it.'),
 ('When moving a marker', 'Among markers able to make a useful move, choose an exposed one first, then one unable to contribute to its primary task, then one without a cache, then one with fewer guerrillas, then reverse map order. A marker is exposed when Kempeitai share its space and could target it: no Camp protects it, or the Japanese J22 capability is active. Re-evaluate a destination using only the pieces that can legally be there.'),
 ('Blue escort and Camps', 'Take one blue guerrilla with a moving marker if the destination has no red guerrilla and the donor protection rule permits it. Choose underground before active. After an actual Contact placement or move, resolve the printed Camp instruction. If a Camp must be recycled, choose a Camp without Force 136, then one with a cache, then smaller Population, then reverse map order. Do not generate a Camp when no marker moved. Event and Propaganda marker moves create no Camps unless specifically instructed.'),
 ('TRAIN: recruit or refresh', 'Select every Force 136 space where Train can make a useful legal placement, even during a British Limited Train. Match its existing color. At a mixed site reinforce the larger group; a tie favors red. If that color is illegal, skip the site. At an empty site prefer legal red, otherwise blue. Do not create a mixed group merely to use spare pieces. At a cache use the printed larger allowance, applying the color choice to each placement.'),
 ('If the preferred color is unavailable', 'First refresh an active guerrilla of that color in the same space if useful. Otherwise take a same-color donor with no Force 136, respecting donor protection: active donors first, then more Japanese cubes, then reverse map order. Preserve pieces needed for this turn\'s primary Raid. If neither exists, another color is permissible only in an empty destination and only if legal. Otherwise skip. Never reuse a guerrilla twice in one Train.'),
 ('Placement priorities for Events and automatic recruits', 'When the effect lets Britain choose placement spaces, prefer: a Force 136 space with no guerrilla; a cache with no guerrilla; a destination where one recruit creates a strict majority; then a Force 136 space; then a cache; then fewer Japanese cubes; then larger Population; then map order. Apply compatible colors first. If pieces run short, process eligible spaces in this order. A fixed or mandatory destination overrides color preferences; do not silently cancel a forced mixed group.'),
 ]),
('Supply, Gather and railway attacks', [
 ('SUPPLY: a Contact with a purpose', 'The primary SUPPLY task uses Contact and Supply. It is useful if a legal Contact plan or a zero-move hold leaves a Camp that can be converted with an Available cache. Choose a Contact destination for Supply, then resolve Supply in all useful permitted spaces. Prefer no Kempeitai, then more guerrillas, then larger Population, then map order. Use the applicable printed space allowance and capabilities. Never place a second cache in a space or place one in an Economic Center. A failed J8 roll consumes that attempt.'),
 ('INTEL: reach the evidence', 'The primary INTEL task uses Contact and Gather. Contact may hold if current positions already give a useful Gather. Otherwise place or move using the Intel destination priorities. For Gather, choose a Force 136 anchor that can reveal the most distinct eligible concealed chits, then one with its own eligible concealed chit, then no Kempeitai, then map order. Resolve it before choosing the next anchor so overlaps are not counted twice. Use every legal reveal from that anchor, taking target spaces in map order. Each chit is revealed at most once.'),
 ('Gather restrictions matter', 'Count only spaces with the required underground guerrilla; do not count all neighbors as automatic Intel. Activate the required guerrilla unless J22 says otherwise. With Japanese J19, the first selected anchor is the one allowed to use adjacent guerrillas; later anchors use only their own space. With British J19 use its larger anchor allowance. Known zero-value revealed chits are not concealed and give no new Gather opportunity. Concealed values never enter target selection.'),
 ('RAIL: use Sabotage', 'Choose every useful eligible Force 136 space, in map order, and assign an adjacent clear railway using the card\'s N, C or S rail order. Resolve one before selecting the next so two spaces do not attack the same newly damaged railway. Use an underground red guerrilla before blue if both colors are present. With British J27, add one permitted non-Force-136 location using rail order, then map order. Ordinary Sabotage never adds a second marker to an already damaged railway.'),
 ('Live railway and regional order', 'Prefer a live railway: a clear one on an all-clear route between an Economic Center and a clear starred exit. Trace the public map; if none of the candidates is live, use regional order among other clear candidates. Orders are on the reference sheet. This preference changes neither connectivity nor adjacency. An Event permitting stacked damage targets fresh railways first, then fewest markers, then regional order. Select distinct railways within an Event unless its printed text explicitly allows repeats.'),
 ('After an ordinary Operation', 'Follow the card\'s Special Activity order only if Operation & Special Activity was selected and the pairing is legal. Train can add Supply or Raid; Contact can add Supply, Gather or Raid; Sabotage and Ambush can add Gather or Raid. Recheck after the Operation: its activated guerrillas may no longer Gather. If the planned Special Activity has become useless, another compatible one in the same card order may be chosen. Never redraw the bot card for a better result.'),
 ]),
('Ambush and Raid', [
 ('STRIKE: identify useful attacks', 'Use each eligible Force 136 space with an underground guerrilla. At a space, first try to displace Kempeitai when the shot is good; otherwise remove a Police if present; otherwise try to displace a Troop when the shot is good. A good shot succeeds on at least 3 of the 6 die results, counting the printed cache modifiers. Do not try to displace something that is already in Kuala Lumpur, and do not roll when success is impossible. Event J26 has its own outcome and is handled separately.'),
 ('Priorities between strike spaces', 'Prefer a useful Kempeitai displacement, then removing the last Police in a space, then another Police removal, then a useful Troop displacement. Within a category prefer the higher success chance, then more supporting caches, then map order. Removing Police is certain when legal. With British J27, add its permitted location without Force 136 using these same priorities. An attempted failed Ambush still completes the card\'s STRIKE task.'),
 ('RAID: one Special Activity', 'For the primary RAID task, use a useful Train first if possible; otherwise use a productive Contact or Contact hold. Then Raid. The ordinary card Special Activity option uses the same procedure. Each chosen destination needs an adjacent cache source that can supply one or two guerrillas without violating donor protection. Move each piece at most once. An incoming guerrilla can act under the Raid permission without Force 136; this permission is confined to that Raid destination.'),
 ('Choose a Raid destination', 'Prefer a destination where an incoming underground guerrilla can Sabotage a live clear railway; then one with another clear railway to Sabotage; then one with a useful STRIKE; then one where the move creates a strict guerrilla majority. Break rail ties by the card\'s regional order, strike ties by strike priorities, and other ties by map order. Recheck after each Raid destination. Do not select the same destination twice.'),
 ('Choose source and number', 'Among eligible adjacent cache sources, prefer one that can send the required pieces while keeping its majority and last cache defender; then the source with more remaining guerrillas; then map order. Send the fewest pieces needed: one underground guerrilla for a permitted attack, otherwise the minimum up to two needed to create a strict majority. If an attack needs an underground piece and only active pieces can be sent, that attack is not a candidate. Prefer the color already at the destination; at an empty destination prefer red. If no non-mixing transfer works, skip the destination.'),
 ('Perform the Raid attack', 'After moving, perform the chosen Limited Sabotage or Ambush with an incoming underground guerrilla, if still legal. A territorial Raid may omit the attack. Use the printed maximum number of Raid destinations and the Zipper modifier. J27 does not make the bot attack an additional remote space from a Raid. If moving guerrillas removes a New Village under the normal rule, remove it immediately.'),
 ('If the whole turn stalls', 'Do not reroll or draw again. Use the next preparation task on the active card. If none can do anything, Pass in the leftmost permitted Initiative box and take its normal Contact benefit if useful. A bot turn can deliberately have no board effect. Age the active card normally; a two-turn card can never lock the deck indefinitely.'),
 ]),
('Decisions between normal turns', [
 ('MPAJA icons', 'Resolve the icon before the Mandatory Event or either normal player turn. For a British Mobilize Population choice, use Opposition priorities among the printed legal targets. For a British Kill Traitors choice, prefer removing the last Police in a space, then Police sharing a space with Force 136, then most revealed Intel value, then map order. Japan chooses its own Seize Supplies and Food Shortage targets. Do not draw, rotate or discard a bot card for an icon.'),
 ('Mandatory effects and Japanese Events', 'Use the physical card for the effect, eligible pieces and who makes each choice. Japan keeps its assigned choices. For a British optional action, use the matching priorities and act if useful; otherwise decline. A free choice of Operation tries RAIL, STRIKE, TRAIN, CONTACT; a free Special Activity tries SUPPLY, GATHER, RAID, within the effect\'s permissions. No new bot card is drawn. For forced losses use page 2. A Mandatory Event still closes the Event box when its immediate effect does nothing.'),
 ('Standing British capability decisions', 'With British J12, use Opposition priorities for the offered placement after each affected repair. With British J15, use the compatible-color rule for the offered guerrilla at each New Village after Extract. Neither is a new normal turn. Apply Japanese capability restrictions even if they make the current card fail. A physical Event always governs the legality and outcome of its actions; the bot guide only supplies choices.'),
 ('Propaganda: keep the published sequence', 'Complete the MPAJA phase and Resistance phase from the physical aid, including clashes before recruitment and the net score change. If this is the final scoring, stop before later phases. Otherwise make the British choices below at their published points, with Japan taking its intervening actions normally. No bot card is drawn, used or aged. At the end of a nonfinal round discard any unfinished bot card; keep the remaining deck and discard pile in their existing order.'),
 ('British Propaganda choices', 'For each damaged railway, use Opposition priorities among its eligible adjacent targets, resolving them one at a time. During the free Supply, use Supply priorities and current capabilities. For optional Force 136 redeployment, move one marker at a time to a distinct Camp space without Force 136: no Kempeitai, then a new Supply site with an Available cache, then more guerrillas, then larger Population, then map order. Move only if escaping exposure, leaving a space with neither guerrillas nor cache, or opening a new Supply site from a space that already has a cache. Staying is allowed; redeployment does not create Camps.'),
 ('Scoring and the third actor', 'Use section 7 of the published rules to decide the winner. In particular, a camp-count tie at Resistance 18-19 is not a British win. Record an MPAJA victory separately: Japan and the Force 136 bot both lose. This prototype adds no early victory when Resistance temporarily reaches a high value. Follow J9 when it causes final scoring before the expected end of campaign 3.'),
 ('Check the physical aid on reset', 'Apply the printed reset, capabilities, marker limits and automatic removals. Sabotage is not cleared merely because a campaign ended. The bot\'s card discard instruction adds no game effect. All compulsory placements, removals and track consequences still occur in the published order.'),
 ]),
('Capabilities and a worked start', [
 ('A short capability checklist', 'Keep executed physical Capability cards visible. Before a matching action, check J8 for Supply eligibility or losses; J12 for Opposition after repair or repair during Extract; J15 for recruits during Extract or New Village treatment at Propaganda; J19 for Gather anchors and adjacency; J22 for Gather activation or marker-target order; and J27 for extra ordinary attack locations or Opposition loss during Supply. Use the printed wording and limits, including mandatory negative effects.'),
 ('An illustrative opening: card 01', 'Assume the published starting board and a current Event skipped by the Event guide. Card 01 wants SUPPLY. The British begin first eligible, so Operation & Special Activity is free. Contact brings in the Available Force 136. Kedah and Kelantan both have a blue guerrilla, no Kempeitai, no Force 136 and Population 2; map order selects Kedah. This placement carries no escort and adds a Camp. Supply can then convert the Camps in Kedah and Negri Sembilan using the two Available caches. Both have one guerrilla and Population 2, so Kedah is processed first. Perak already has a cache and cannot take another. Discard card 01.'),
 ('What this opening demonstrates', 'The bot can expand and Supply during one legal Contact/Supply turn, using one Operation and one Special Activity. This is a rules walk-through, not a recommendation that a human would always choose that opening. Playtests should check whether its modestly guarded caches need stronger protection and whether blue recruits are exposed to later MPAJA clashes. The draft leaves those decisions visible for feedback.'),
 ('An interrupted plan', 'An INTEL card is active but Japan has taken Operation & Special Activity. The bot cannot Gather this turn. It tries its first preparation task, TRAIN, using Limited Operation. The British Limited operation may cover multiple Force 136 spaces. Rotate the card sideways. On the next British normal turn it tries INTEL again. If a Gather is legally attempted it discards the card even if all newly revealed chits are zero. If Japan blocks the required box again, the bot prepares or Passes, then discards the card because it has had two turns.'),
 ('Three important checks', 'RAIL and Gather cannot both spend the same already-activated guerrilla without a printed exception. A Contact placement or move can generate a Camp; an ordinary Event relocation or Propaganda redeployment cannot. A cache can support Raid without Force 136 at the destination, but cannot allow a guerrilla to act from a space it never legally entered.'),
 ('Prototype status', 'This is a playable design draft, not a measured competitive release. Development checks cover the deck, initiative decisions and selected rules-sensitive decisions. They do not model full games, Event history, railway geometry, action execution or human strategy. No simulated win rate, physical playtest or balance claim is made. The bot uses deliberately bounded choices, including at most one Contact marker move and no voluntary cache recycling. J17 is deliberately skipped as an Event choice.'),
 ]),
('First tabletop test and provenance', [
 ('A focused first session', 'Play one standard game with Japan pursuing a coherent plan, such as reliable extraction supported by Police and selective repair. Record every normal British task, failed or stalled turn, ambiguous choice, and card kept for a second turn. Separately record MPAJA losses. At the end note the actual winner, Resistance and the two marker counts. Do not describe one result as a win rate.'),
 ('Then vary the Japanese plan', 'Try a second game focused on eliminating Force 136, and a third focused on railway defense and removing caches. Watch whether one repeated Japanese action strands the bot, whether it repeatedly builds undefended caches, whether it can recover its marker network, and whether it spends late turns feeding the MPAJA. Preserve the rules and card distribution during this first comparison.'),
 ('Measure administration', 'Time at least five normal bot turns after learning the procedures. Record the longest lookup, any choice requiring more than three comparisons, and any rule you have to read twice. The design target is most ordinary turns around a minute once learned; this has not been measured. Event and Propaganda turns may take longer. Prefer fixing wording or priorities before adding new tracks or tokens.'),
 ('Before calling it competitive', 'Validate a complete rules engine against the official example and scoring before running full-game simulations. Include the real Event deck, all six capabilities, the independent MPAJA, legal Japanese policies, public-information limits, and the final-phase stop. Test multiple purposeful Japanese strategies and adversarial repetition. Separate engine correctness, strategy quality and tabletop usability. A large sample of an incomplete model cannot settle those questions.'),
 ('Sources and precedence', 'Rules source: GMT Games, The British Way: Japanese Occupation, copyright 2026, 28-page rulebook, mirrored at the URL below. The physical game and current official corrections take precedence. The original bot rules and priorities in this document are a fan variant, not publisher rules. The source rulebook, physical Event text, historical commentary, maps and game artwork are not included in the source package.'),
 ('Relevant references', 'Sections 1.4, 1.8-1.12 and 1.15: pieces, markers and information. Sections 2.3-2.5: icons, initiative and interruptions. Sections 3.2 and 4.2: British actions. Sections 5.1-5.5: Events and capabilities. Sections 6-7: Propaganda, Zipper and victory. Section 9: physical Event identification and execution. Scenario setup: page 27. Consult these for the underlying rules; this document supplies decisions.'),
 ('Build and reproducibility', 'Version 0.1, dated '+DATE+'. The ZIP includes this guide, separate card and reference PDFs, editable Markdown and JSON, the PDF builder, and a narrow development check script. It contains no runtime opponent or digital recreation of the board game. Run reference_checks.py with Python; build the PDFs with Python and ReportLab. A source hash and validation receipt are in the package.'),
 ]),
]

RAIL_ORDERS = {
 'N': ['Perak-Kelantan','Thailand-Perak','Thailand-Kelantan *','Thailand-Kedah *','Perak-Pahang-Selangor','Negri Sembilan-Pahang','Pahang-Johore *','Negri Sembilan-Johore *'],
 'C': ['Perak-Pahang-Selangor','Perak-Kelantan','Negri Sembilan-Pahang','Thailand-Perak','Thailand-Kelantan *','Negri Sembilan-Johore *','Pahang-Johore *','Thailand-Kedah *'],
 'S': ['Negri Sembilan-Pahang','Negri Sembilan-Johore *','Pahang-Johore *','Perak-Pahang-Selangor','Perak-Kelantan','Thailand-Perak','Thailand-Kelantan *','Thailand-Kedah *'],
}

QUICK = [
 ('Turn','Resolve icon and Mandatory Event first. At a normal British turn draw only if no active bot card. Check Event, urgent needs, primary task, preparation, then Pass.'),
 ('Card life','Primary task attempted: discard. Other action on first use: rotate and retain. After second normal turn: discard regardless. Nonfinal Propaganda: discard the active card. Free effects never age it.'),
 ('Event','A: take if applicable. B: take only on B EVENTS: YES cards. D: Event box + Pass/Contact. AUTO: follow physical card; no Event box. Late = at least 4 regular Events have appeared in this campaign, including current.'),
 ('Urgent','No Force 136: productive Contact. Campaign 3, Resistance >=16, Camps >= Force 136: useful SUPPLY, otherwise Contact to place an Available marker. One action budget still applies.'),
 ('Tasks','SUPPLY = Contact + Supply. INTEL = Contact + Gather. RAID = useful Train, else Contact + Raid. RAIL = Sabotage. STRIKE = Ambush. TRAIN = Train.'),
 ('Pairings','Train: Supply/Raid. Contact: Supply/Gather/Raid. Sabotage or Ambush: Gather/Raid. Never two Special Activities. Main special tasks require Op & SA.'),
 ('Initiative','Other tasks: Op & SA if a useful compatible SA exists; otherwise Limited, otherwise Op & SA without SA. Respect occupied boxes and Mandatory Event restrictions. British Limited is not generally one space.'),
 ('Safety','No hidden Intel values or future cards. Protect last cache defender and existing donor majorities on voluntary moves. Avoid mixed guerrilla colors. Do not reuse one piece in the same Operation or Raid.'),
 ('Strike','Good Kempeitai shot, else Police, else good Troop shot. Good = succeeds on at least 3 die faces. Do not displace pieces already in Kuala Lumpur. Dice failure still uses the action.'),
 ('Information','Gather needs actual eligible guerrillas, not merely adjacency. Overlaps reveal once. After Sabotage, recheck which guerrillas remain underground.'),
 ('Ties','Kedah > Perak > Kelantan > Trengganu > Pahang > Selangor > Kuala Lumpur > Negri Sembilan > Johore > northern EC > southern EC.'),
 ('Scoring','Use physical aid. An MPAJA win is a loss for Japan and Force 136. Camp-count equality at Resistance 18-19 is not a British win. Final scoring stops before later phases.'),
]

INK=colors.HexColor('#18352F')
GOLD=colors.HexColor('#C69C48')
PALE=colors.HexColor('#F0F4F0')
GREY=colors.HexColor('#56625E')
TASK_COLORS={'SUPPLY':'#2E6256','INTEL':'#304B70','RAIL':'#7B5A29','STRIKE':'#78423B','TRAIN':'#49633A','RAID':'#655075'}

def fonts():
    candidates = [Path('/usr/share/fonts/truetype/dejavu'), Path('/usr/share/fonts/truetype/liberation2')]
    for p in candidates:
        if (p/'DejaVuSans.ttf').exists():
            for key,name in [('Bot','DejaVuSans.ttf'),('BotBold','DejaVuSans-Bold.ttf')]:
                pdfmetrics.registerFont(TTFont(key,str(p/name)))
            pdfmetrics.registerFontFamily('Bot',normal='Bot',bold='BotBold',italic='Bot',boldItalic='BotBold')
            return
    raise RuntimeError('DejaVu Sans fonts are required for this build')

BODY=ParagraphStyle('body',fontName='Bot',fontSize=9.1,leading=12.25,textColor=INK,spaceAfter=0)
SMALL=ParagraphStyle('small',parent=BODY,fontSize=8.0,leading=10.4)
CARD=ParagraphStyle('card',parent=BODY,fontSize=8.6,leading=11.1)
HEAD=ParagraphStyle('head',parent=BODY,fontName='BotBold',fontSize=10.4,leading=13)

LAYOUT=[]

def pdraw(c,text,x,y,width,style=BODY):
    p=Paragraph(text,style)
    _,h=p.wrap(width,10000)
    p.drawOn(c,x,y-h)
    LAYOUT.append((c.getPageNumber(),x,y-h,width,h))
    return y-h

def shell(c,title,kind='FIELD GUIDE'):
    c.setFillColor(INK);c.rect(0,744,612,48,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('BotBold',10.8);c.drawString(36,766,'FORCE 136')
    c.setFont('Bot',8.4);c.drawRightString(576,766,f'v{VERSION}  |  {kind}')
    c.setFillColor(INK);c.setFont('BotBold',18);c.drawString(36,712,title)
    c.setStrokeColor(GOLD);c.setLineWidth(1.5);c.line(36,697,576,697)
    c.setFillColor(GREY);c.setFont('Bot',7.1)
    c.drawString(36,23,'Unofficial fan prototype  |  Japanese Occupation  |  Physical game required')
    c.drawRightString(576,23,str(c.getPageNumber()))
    return 680

def rule_pages(c):
    for title,sections in RULE_PAGES:
        y=shell(c,title)
        for h,t in sections:
            y=pdraw(c,escape(h),36,y,540,HEAD)-4
            y=pdraw(c,escape(t),36,y,540,BODY)-10
        if y<42:
            raise ValueError(f'Rule page overflow: {title}, y={y}')
        if title=='First tabletop test and provenance':
            y=pdraw(c,f'<link href="{SOURCE_URL}" color="#304B70">Rulebook source PDF</link>  |  <link href="{PRODUCT_URL}" color="#304B70">GMT product and official resources</link>',36,y,540,SMALL)
        c.showPage()

def event_pages(c):
    for start,stop in [(0,10),(10,21),(21,32)]:
        y=shell(c,f'Event decisions: J{start+1}-J{stop}','EVENT REFERENCE')
        y=pdraw(c,'Use the physical card for its effect. U = unshaded, S = shaded. A: take. B: only on keen cards. D: Event box + Pass/Contact. AUTO: mandatory. Late = at least 4 regular Events have appeared this campaign, including current; otherwise early.',36,y,540,SMALL)-9
        for jid,title,side,gate,target in EVENTS[start:stop]:
            label=f'<b>{jid}  {escape(title)}  [{side}]</b>'
            y=pdraw(c,label,36,y,540,SMALL)-2
            y=pdraw(c,'<b>Take:</b> '+escape(gate)+' <b>Choose:</b> '+escape(target),36,y,540,SMALL)-8
        if y<42: raise ValueError(f'Event page overflow at {stop}: {y}')
        c.showPage()

def reference_pages(c):
    y=shell(c,'The bot at a glance','QUICK REFERENCE')
    for label,t in QUICK:
        y=pdraw(c,'<b>'+escape(label)+'.</b> '+escape(t),36,y,540,SMALL)-9
    if y<42: raise ValueError(f'Quick reference overflow {y}')
    c.showPage()
    y=shell(c,'Railway orders and test log','TABLE REFERENCE')
    y=pdraw(c,'First choose among eligible live clear railways, then other eligible clear railways. For Events that allow stacking, prefer fresh targets; then fewest existing markers. An asterisk marks a starred exit. These lists set preferences; the physical map determines adjacency and connectivity.',36,y,540,BODY)-17
    for label,rails in RAIL_ORDERS.items():
        y=pdraw(c,{'N':'N - North','C':'C - Center','S':'S - South'}[label],36,y,540,HEAD)-3
        y=pdraw(c,escape(' > '.join(rails)),36,y,540,BODY)-14
    y=pdraw(c,'First game record',36,y,540,HEAD)-8
    for label in ['Japanese plan:','Winner / final Resistance / Camps / Force 136:','Normal bot turns / stalled turns:','Longest bot turn / hardest lookup:','Ambiguous choice or repeated weakness:','Change to consider after this game:']:
        y=pdraw(c,label,36,y,540,BODY)-20
        c.setStrokeColor(colors.HexColor('#B4C1B7'));c.line(36,y+10,576,y+10)
    y=pdraw(c,'No published win rate. The included development checks test selected decisions and print consistency, not complete games.',36,y,540,SMALL)
    if y<42: raise ValueError(f'Rail reference overflow {y}')
    c.showPage()

def card_pages(c):
    for batch in range(3):
        y=shell(c,f'Bot cards {batch*6+1:02d}-{batch*6+6:02d}','PRINT AT 100%')
        pdraw(c,'Single-sided poker-size cards: 2.5 x 3.5 inches. Cut on the borders. Shuffle all 18 together. Keep the active card upright on its first turn; rotate it sideways if it is retained.',36,y,540,SMALL)
        for idx,row in enumerate(CARDS[batch*6:batch*6+6]):
            num,title,task,prep,rail,keen,special=row
            col=idx%3; rr=idx//3
            x=36+col*180; top=625-rr*252; bottom=top-252
            c.setStrokeColor(INK);c.setLineWidth(.65);c.rect(x,bottom,180,252,fill=0,stroke=1)
            c.setFillColor(colors.HexColor(TASK_COLORS[task]));c.rect(x,top-38,180,38,fill=1,stroke=0)
            c.setFillColor(colors.white);c.setFont('BotBold',9);c.drawString(x+10,top-15,f'{num}  {task}')
            c.setFont('Bot',6.9);c.drawString(x+10,top-29,'FORCE 136  /  v0.1')
            cy=top-49
            cy=pdraw(c,escape(title),x+10,cy,160,ParagraphStyle('ct',parent=CARD,fontName='BotBold',fontSize=10.4,leading=12.5))-8
            cy=pdraw(c,'<b>PRIMARY</b><br/>'+escape(TASK_SHORT[task]),x+10,cy,160,CARD)-9
            cy=pdraw(c,'<b>IF UNAVAILABLE</b><br/>'+escape(prep),x+10,cy,160,CARD)-8
            cy=pdraw(c,'<b>OTHER SPECIAL ACTIVITY</b><br/>'+escape(special)+'<br/><font size="7">Only when compatible and permitted.</font>',x+10,cy,160,CARD)-7
            cy=pdraw(c,f'<b>RAIL ORDER: {rail}  |  B EVENTS: {keen}</b>',x+10,cy,160,SMALL)
            if cy<bottom+30: raise ValueError(f'Card {num} overflow {cy-bottom}')
            c.setFillColor(PALE);c.rect(x+1,bottom+1,178,24,fill=1,stroke=0)
            pdraw(c,'Primary attempted: discard. Other action:<br/>retain once; discard after second turn.',x+8,bottom+21,164,ParagraphStyle('foot',parent=SMALL,fontSize=6.8,leading=8.2))
        c.showPage()

def markdown():
    lines=['# Force 136: a card-driven opponent for Japan',f'\nVersion {VERSION} | {DATE} | Unofficial playable prototype\n']
    for title,sections in RULE_PAGES:
        lines+=['## '+title,'']
        for h,t in sections:lines+=['### '+h,'',t,'']
    lines+=['## Event decisions','']
    for jid,title,side,gate,target in EVENTS:
        lines += [f'### {jid}: {title} [{side}]','',gate,'',target,'']
    lines+=['## Regional railway orders','']
    for k,v in RAIL_ORDERS.items():lines += [f'**{k}:** '+ ' > '.join(v),'']
    lines+=['## Bot cards','']
    for n,title,t,prep,rail,keen,sa in CARDS:
        lines += [f'### {n}: {title}',f'Primary: {t}. {TASK_SHORT[t]}',f'Preparation: {prep}. Other Special Activity: {sa}. Rail order: {rail}. B Events: {keen}.','']
    lines+=['## Sources','',SOURCE_URL,'',PRODUCT_URL,'']
    return '\n'.join(lines)

def build():
    fonts();OUT.mkdir(exist_ok=True)
    data={'version':VERSION,'date':DATE,'scope':'Human Japan; paper Force 136 bot; standard standalone Japanese Occupation',
          'source_url':SOURCE_URL,'product_url':PRODUCT_URL,'rule_pages':RULE_PAGES,'rail_orders':RAIL_ORDERS,'events':EVENTS,
          'cards':[dict(zip(['id','title','primary','preparation','rail_order','b_events','other_special'],r)) for r in CARDS],
          'task_summaries':TASK_SHORT,'quick_reference':QUICK}
    (ROOT/'bot_data.json').write_text(json.dumps(data,indent=2)+'\n')
    (ROOT/'Force_136_Rules_v0.1.md').write_text(markdown())
    for name,parts in [
        ('Force_136_Solo_v0.1.pdf',[rule_pages,event_pages,reference_pages,card_pages]),
        ('Force_136_Cards_v0.1.pdf',[card_pages]),
        ('Force_136_Reference_v0.1.pdf',[reference_pages]),
    ]:
        c=canvas.Canvas(str(OUT/name),pagesize=(612,792),pageCompression=1,invariant=1)
        c.setTitle(name.replace('_',' ').replace('.pdf',''));c.setAuthor('Original fan automa prototype')
        for f in parts:f(c)
        c.save()
        print(name,(OUT/name).stat().st_size)
    (OUT/'layout_bounds.json').write_text(json.dumps(LAYOUT))
    source=ROOT.parent/'research/EomE_JapOcc_Rules.pdf'
    receipt={'version':VERSION,'date':DATE,'rulebook_url':SOURCE_URL,'rulebook_pages':28,
             'rulebook_sha256':hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None,
             'full_game_simulation':False,'physical_playtesting':False,
             'validation_scope':'Deck structure, selected decision rules, print text and layout; not a game engine.'}
    (ROOT/'provenance.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':build()
