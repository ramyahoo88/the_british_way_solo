#!/usr/bin/env python3
"""Independent focused audit fixtures for Force 136 v0.1.

NOT a full game engine, opponent, or balance simulator. The score oracle and
the scripted official example are independent of the shipped helper functions.
Paper decision branches are stated explicitly rather than disguised as an
executable implementation of the complete prose. No future card or concealed
Intel value is supplied to a bot decision.
"""
from pathlib import Path
import argparse, copy, hashlib, importlib.util, json, shutil, subprocess, sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'baseline'
RESULTS=ROOT/'results'
FIXTURES=ROOT/'fixtures'
POP={'Kedah':2,'Perak':3,'Kelantan':2,'Trengganu':1,'Pahang':1,
     'Selangor':1,'Kuala Lumpur':2,'Negri Sembilan':2,'Johore':2,
     'Northern EC':0,'Southern EC':0}

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
    return m

def board():
    b={s:dict(population=p,troops=0,police=0,red_u=0,red_a=0,blue_u=0,blue_a=0,
                   force136=0,camp=False,cache=False,kempeitai=0,opposition=False,
                   terror=False,new_village=False,intel_revealed=False,intel_value=None)
            for s,p in POP.items()}
    # All three non-removable-to-Available markers remain accounted for. It is
    # legal to stack Kempeitai in Kuala Lumpur; none affect these local cases.
    b['Kuala Lumpur']['kempeitai']=3
    return b

def gs(v):return sum(v[k] for k in ['red_u','red_a','blue_u','blue_a'])
def cubes(v):return v['troops']+v['police']
def count(b,field):return sum(int(v[field]) for v in b.values())
def clamp(r):return max(0,min(20,r))

def oracle_winner(r,b):
    if r<=17:return 'Japan'
    if r==20:return 'Force 136'
    return 'Force 136' if count(b,'camp')<count(b,'force136') else 'MPAJA'

def propaganda_oracle(b,resistance,resources,red_available=0,j15_japanese=False):
    """Only the published Clashes, Mobilize, net Resistance, and winner.

    This deliberately stops before Resources/Support/Redeploy/Reset. The
    caller chooses whether to use the winner, since ordinary early Propaganda
    does not end the game. Fixed destinations are processed in printed map order.
    """
    b=copy.deepcopy(b);clashes=0;recruits=0
    for v in b.values():
        red=v['red_u']+v['red_a'];blue=v['blue_u']+v['blue_a']
        if red and blue:
            # Explicit audit tie choice: active before underground for each
            # compulsory color loss. Scoring depends on counts, not this tie.
            v['red_a' if v['red_a'] else 'red_u']-=1
            v['blue_a' if v['blue_a'] else 'blue_u']-=1
            clashes+=1
    for v in b.values():
        effective_opp=v['opposition'] and not (j15_japanese and v['new_village'])
        if effective_opp and red_available:
            v['red_u']+=1;red_available-=1;recruits+=1
    intel=sum(v['intel_value'] for v in b.values() if v['intel_revealed'])
    caches=count(b,'cache')
    majorities=sum(gs(v)>cubes(v) for v in b.values())
    neutral=sum(v['population'] for v in b.values()
                if not v['opposition'] or (j15_japanese and v['new_village']))
    police_spaces=sum(v['police']>0 for v in b.values())
    delta=intel+caches+majorities-resources//4-neutral//5-police_spaces//3
    result=clamp(resistance+delta)
    return {'resistance_before':resistance,'intel':intel,'caches':caches,
            'guerrilla_majorities':majorities,'resources':resources,'resource_deduction':resources//4,
            'neutral_population':neutral,'neutral_deduction':neutral//5,
            'police_spaces':police_spaces,'police_deduction':police_spaces//3,
            'clash_spaces':clashes,'automatic_red_recruits':recruits,
            'net_change':delta,'resistance_after':result,'winner_if_final':oracle_winner(result,b),
            'camps':count(b,'camp'),'force136':count(b,'force136'),'board_after':b}

def inventory(b,red_available,blue_available,caches_available,camps_available,f_available,track_caches=0):
    assert count(b,'troops')==15
    assert count(b,'police')<=6
    assert sum(v['red_u']+v['red_a'] for v in b.values())+red_available==10
    assert sum(v['blue_u']+v['blue_a'] for v in b.values())+blue_available==4
    assert count(b,'cache')+caches_available+track_caches==5
    assert count(b,'camp')+camps_available==4
    assert count(b,'force136')+f_available==3
    assert count(b,'kempeitai')==3

def final_trap():
    b=board()
    for s,t in {'Kedah':2,'Perak':2,'Kelantan':2,'Trengganu':2,'Pahang':2,
                'Selangor':1,'Negri Sembilan':1,'Northern EC':1,'Southern EC':2}.items():b[s]['troops']=t
    b['Kuala Lumpur']['police']=3;b['Johore']['police']=3
    for s in ['Kedah','Perak','Pahang']:
        b[s].update(red_u=1,force136=1,camp=True,opposition=True)
    for s in ['Selangor','Kuala Lumpur','Negri Sembilan','Johore']:b[s]['red_u']=1
    b['Kelantan']['blue_u']=2;b['Trengganu']['blue_u']=2
    inventory(b,3,0,5,1,0)
    fixture={'id':'F1','campaign':3,'regular_events_seen_in_campaign':6,
             'phase':'after icons and Japanese Limited action, before British normal turn',
             'event':'J4','active_bot_card':'02','resistance':19,'zipper':18,'japanese_resources':0,
             'free_initiative_boxes':['Event','Op & SA'],'red_available':3,'blue_available':0,
             'cache_available':5,'camp_available':1,'force136_available':0,
             'all_intel_concealed':True,'concealed_values_used_by_bot':False,
             'capabilities':[],'board':b,'next_card_is_known_final_propaganda':True}
    # Shipped gate J4 A: three qualifying spaces, then current R is capped.
    matching=sum(v['force136']>0 and v['camp'] for v in b.values())
    assert matching==3
    event=propaganda_oracle(b,clamp(19+matching),0,3)
    assert (event['resistance_after'],event['winner_if_final'])==(18,'MPAJA')
    shade=copy.deepcopy(b)
    for v in shade.values():
        if v['force136']:v['camp']=False
    shaded=propaganda_oracle(shade,19,0,3)
    assert (shaded['resistance_after'],shaded['winner_if_final'])==(17,'Japan')
    # A legal Contact/Supply alternative; follow the prose's source/destination
    # priorities: Pahang -> Kelantan. The red guerrilla cannot escort Contact.
    supply=copy.deepcopy(b)
    supply['Pahang']['force136']=0;supply['Kelantan']['force136']=1;supply['Kelantan']['camp']=True
    for s in ['Kelantan','Perak','Kedah']:
        assert supply[s]['force136'] and supply[s]['camp'] and not supply[s]['cache']
        supply[s]['camp']=False;supply[s]['cache']=True
    inventory(supply,3,0,2,3,0)
    alt=propaganda_oracle(supply,19,0,3)
    assert (alt['resistance_after'],alt['winner_if_final'])==(20,'Force 136')
    assert alt['guerrilla_majorities']==event['guerrilla_majorities']==0
    hold=copy.deepcopy(b)
    for s in ['Kedah','Perak','Pahang']:hold[s]['camp']=False;hold[s]['cache']=True
    alt_hold=propaganda_oracle(hold,19,0,3)
    assert alt_hold['winner_if_final']=='Force 136'
    # Nearby differing case: with R16 neither line wins; do not claim that
    # Camp conversion always wins or that this fixture measures a win rate.
    neighbors=[]
    for r in [16,17,18,19,20]:
        e=propaganda_oracle(b,clamp(r+3),0,3)
        a=propaganda_oracle(supply,r,0,3)
        neighbors.append({'resistance':r,'event_winner':e['winner_if_final'],
                          'event_final':e['resistance_after'],'supply_winner':a['winner_if_final'],
                          'supply_final':a['resistance_after']})
    return fixture,{'finding':'F1','event_branch':event,'shaded_event_branch':shaded,
                    'supply_branch':alt,'supply_hold_branch':alt_hold,'neighbors':neighbors}

def cap_trap():
    b=board();s=b['Negri Sembilan'];s.update(troops=1,red_u=1,force136=1,cache=True)
    b['Kuala Lumpur']['troops']=14;b['Kuala Lumpur']['police']=6
    inventory(b,9,4,4,4,2)
    fixture={'id':'F2','campaign':2,'resistance':20,'zipper':18,'event':'J26',
             'active_bot_card':'13','japan_has_already_selected':'Limited',
             'free_initiative_boxes':['Event','Op & SA'],'die':1,'board':b}
    # Six die faces succeed because the cache supplies +1 against one cube.
    faces=[d for d in range(1,7) if d+1>1];assert len(faces)==6
    chosen=copy.deepcopy(b);chosen['Negri Sembilan']['red_u']-=1;chosen['Negri Sembilan']['red_a']+=1
    event_r=clamp(20+2);assert event_r==20 and chosen['Negri Sembilan']['troops']==1
    regular=copy.deepcopy(chosen);regular['Negri Sembilan']['troops']-=1;regular['Kuala Lumpur']['troops']+=1
    # After the bot selects Event, Japan's prior Limited cylinder leaves it
    # first on the next card, and this exposed guerrilla is a legal Assault loss.
    chosen['Negri Sembilan']['red_a']-=1
    return fixture,{'finding':'F2','successful_faces':faces,'event_resistance_gain':event_r-20,
                    'event_troops_left_at_target':1,'active_guerrilla_exposed':True,
                    'following_japanese_assault_guerrilla_losses':1,
                    'regular_ambush_troops_left_at_target':regular['Negri Sembilan']['troops'],
                    'japanese_event_denial_needed':False,
                    'nearby_control_resistance_18_event_gain':clamp(18+2)-18}

def initiative_trap(ref):
    b=board();b['Kuala Lumpur'].update(troops=15,police=6)
    for s in ['Kedah','Perak','Negri Sembilan']:b[s].update(red_u=1,force136=1,camp=True)
    b['Perak']['opposition']=True  # J31 Mobilize resolved before the normal turn.
    inventory(b,7,4,3,1,0,track_caches=2)
    before=sum(v['red_u']+v['blue_u'] for v in b.values())
    assert before==3
    assert ref.first_special('RAIL',['GATHER','RAID'],{'GATHER'})=='GATHER'
    selected=ref.initiative('RAIL',{'Limited','Event','Op & SA'},planned_special=True)
    for s in ['Kedah','Perak','Negri Sembilan']:
        b[s]['red_u']-=1;b[s]['red_a']+=1
    after=sum(v['red_u']+v['blue_u'] for v in b.values())
    assert after==0 and selected=='Op & SA'
    assert ref.first_special('RAIL',['GATHER','RAID'],set()) is None
    counter=ref.initiative('RAIL',{'Limited','Event','Op & SA'},planned_special=False)
    assert counter=='Limited'
    extra=copy.deepcopy(b);extra['Kelantan']['red_u']=1
    assert sum(v['red_u']+v['blue_u'] for v in extra.values())==1
    assert ref.initiative('RAIL',{'Limited','Event','Op & SA'},planned_special=True)=='Op & SA'
    fixture={'id':'F3','campaign':1,'event':'J31','japanese_resources':0,'active_bot_card':'09',
             'british_first_eligible':True,'caches_on_map':0,'zipper':0,
             'all_relevant_intel_concealed':True,'guerrilla_sites_before_sabotage':['Kedah','Perak','Negri Sembilan'],
             'all_three_guerrillas_start_underground':True,
             'sabotage_targets':['Thailand-Kedah *','Perak-Pahang-Selangor','Negri Sembilan-Johore *'],
             'other_guerrillas_on_map':0,'board_after_operation':b}
    return fixture,{'finding':'F3','current_board_planned_special':'GATHER','box_selected':selected,
                    'underground_after_sabotage':after,'special_actually_possible':None,
                    'same_operation_under_limited':True,'smallest_box_fix':counter,
                    'nearby_control':'One additional underground guerrilla in Kelantan can Gather via the Perak anchor; Op & SA is then useful',
                    'next_eligibility_with_full_box_and_japanese_limited':'Japan first',
                    'next_eligibility_with_british_limited':'Britain first'}

def actor_gap():
    b=board();b['Negri Sembilan'].update(troops=1,police=1,red_u=1,blue_u=1,force136=1,camp=True,cache=True)
    b['Kuala Lumpur'].update(troops=14,police=5)
    inventory(b,9,3,4,3,2)
    fixture={'id':'F4','campaign':2,'event':'J17','active_bot_card':'13','japan_has_already_selected':'Op & SA',
             'british_action':'Limited Ambush','target':'Negri Sembilan','board':b,
             'next_referee_test':'J6: Food Shortage has no eligible red target (cache protection), then Negri Sembilan attrition die 1; this is not visible to the bot'}
    outcomes=[]
    for color in ['red','blue']:
        z=copy.deepcopy(b);v=z['Negri Sembilan'];v[color+'_u']-=1;v[color+'_a']+=1;v['police']-=1
        assert v['cache'] and all(not (w['red_u']+w['red_a']) or w['cache'] for w in z.values())
        # The mandatory attrition is a separate prescribed test, not a bot
        # decision based on a future card. Page 2 removes the active guerrilla.
        v[color+'_a']-=1
        outcomes.append({'ambush_actor':color,'after_J6_red':v['red_u'],
                         'after_J6_blue':v['blue_u'],'police_removed':1})
    assert outcomes[0]['after_J6_red']!=outcomes[1]['after_J6_red']
    source=(BASE/'bot_data.json').read_text()
    data=json.loads(source)
    sabotage=dict(data['rule_pages'][3][1])['RAIL: use Sabotage']
    strike=dict(data['rule_pages'][4][1])['STRIKE: identify useful attacks']
    gather=dict(data['rule_pages'][3][1])['INTEL: reach the evidence']
    assert 'red guerrilla before blue' in sabotage
    assert 'red' not in strike.lower() and 'blue' not in strike.lower()
    assert 'red' not in gather.lower() and 'blue' not in gather.lower()
    return fixture,{'finding':'F4','legal_actor_choices':2,'single_color_control_actor_choices':1,
                    'Food_Shortage_icon_before_J6_attrition_has_no_target':True,
                    'tie_break_in_sabotage_only':True,'branches':outcomes}

def mutation_test():
    import fitz
    d=ROOT/'mutated_card09'
    if d.exists():shutil.rmtree(d)
    shutil.copytree(BASE,d)
    changed=[]
    for name,page_index in [('Force_136_Cards_v0.1.pdf',1),('Force_136_Solo_v0.1.pdf',14)]:
        path=d/name;doc=fitz.open(path);p=doc[page_index]
        # Card 09 is in the top-right cell of the second six-card sheet.
        hits=[r for r in p.search_for('GATHER > RAID') if r.x0>395 and r.y0<419]
        assert len(hits)==1,(name,hits)
        target=hits[0]
        p.add_redact_annot(target,fill=(1,1,1));p.apply_redactions(images=0,graphics=0)
        temp=path.with_suffix('.redacted.pdf');doc.save(temp);doc.close();temp.replace(path)
        fresh=fitz.open(path);clip=fitz.Rect(396,167,576,419)
        # The exact field is missing from 09, while 11 still carries it.
        assert 'GATHER > RAID' not in fresh[page_index].get_text(clip=clip)
        assert 'GATHER > RAID' in fresh[page_index].get_text()
        changed.append({'file':name,'page':page_index+1,'removed_field':'card 09 OTHER SPECIAL ACTIVITY: GATHER > RAID'})
    run=subprocess.run([sys.executable,str(d/'verify_printables.py')],text=True,capture_output=True)
    assert run.returncode==0,run.stderr
    (RESULTS/'mutant_verifier_stdout.txt').write_text(run.stdout)
    # Independent per-card scan catches the missing instruction.
    fresh=fitz.open(d/'Force_136_Cards_v0.1.pdf')
    crop=fresh[1].get_text(clip=fitz.Rect(396,167,576,419))
    strict_pass='GATHER > RAID' in ' '.join(crop.split())
    assert not strict_pass
    return {'finding':'F5','mutations':changed,'shipped_verifier_exit':run.returncode,
            'shipped_verifier_claims_all_18_cards_matched':json.loads(run.stdout)['cards_matched']==18,
            'independent_card09_clip_check_passes':strict_pass,
            'baseline_deliverables_were_modified':False}

def score_boundaries():
    # Rulebook §7 boundaries independent of the shipped winner helper.
    out=[]
    for r in [0,17,18,19,20]:
        for camps,f in [(0,0),(1,2),(2,2),(3,2)]:
            b=board();b['Kuala Lumpur'].update(troops=15,police=6)
            for s in list(POP)[:camps]:b[s]['camp']=True
            for s in list(POP)[:f]:b[s]['force136']=1
            inventory(b,10,4,5,4-camps,3-f)
            expected='Japan' if r<18 else ('Force 136' if r==20 or camps<f else 'MPAJA')
            assert oracle_winner(r,b)==expected
            out.append({'resistance':r,'camps':camps,'force136':f,'winner':expected})
    return out

def main():
    RESULTS.mkdir(exist_ok=True);FIXTURES.mkdir(exist_ok=True)
    ref=load_module('shipped_reference',BASE/'reference_checks.py')
    results=[]
    for func in [final_trap,cap_trap,lambda:initiative_trap(ref),actor_gap]:
        fixture,result=func();(FIXTURES/f"{fixture['id']}.json").write_text(json.dumps(fixture,indent=2)+'\n')
        results.append(result)
    if '--skip-pdf-mutation' not in sys.argv:results.append(mutation_test())
    result={'scope':'Four focused paper-decision fixtures, one print-verifier mutation and 20 score boundary cases; not complete games',
            'findings_reproduced':results,'score_boundaries':score_boundaries(),'complete_simulated_games':0}
    (RESULTS/'audit_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'confirmed_findings':[x['finding'] for x in results],
                      'F1_event':results[0]['event_branch']['winner_if_final'],
                      'F1_supply':results[0]['supply_branch']['winner_if_final'],
                      'score_boundary_cases':20,'complete_games':0},indent=2))

if __name__=='__main__':main()
