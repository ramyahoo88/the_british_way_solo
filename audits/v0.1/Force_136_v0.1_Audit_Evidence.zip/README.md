# Force 136 v0.1 comprehensive audit evidence

Audit date: 20 November 2026. Scope: human Japan, paper Force 136 opponent,
standard standalone Japanese Occupation.

The original release is frozen under `baseline/`. Nothing in that folder was
fixed or re-released as part of the audit. The report records **five findings:
one High and four Medium**, two internal bot design questions, and optional
improvements. The release verdict is **HOLD for competitive public release**.

## Reproduce

```sh
python3 reproduce_audit.py
python3 desk_traces.py
python3 baseline/reference_checks.py
python3 baseline/verify_printables.py
```

PyMuPDF (`fitz`) is required for PDF checks and mutation. The four board
fixtures and winner boundaries can run without it:

```sh
python3 reproduce_audit.py --skip-pdf-mutation
```

The mutation script creates a disposable `mutated_card09/` directory. It removes
one instruction from card 09 in both copied PDFs, and demonstrates that the
original page-wide checker still passes. The frozen originals are unchanged.
The supplied `mutant_witness/` PDFs are intentionally defective evidence: do
not use them as game components.

`desk_traces.py` is a scripted desk reconstruction, not an automated general
opponent. It reconstructs the published six-Event example and separately traces
six paper-bot turns against a stated Japanese hunting sequence, with a disclosed
Contact interpretation. Both traces reach the first nonfinal Propaganda.
The fixtures cover the final scoring cases. **No complete three-campaign game
or statistical balance study is claimed.**

## Files

- `audit_report.md` and `Force_136_v0.1_Comprehensive_Audit.pdf`: full report.
- `findings.json`: machine-readable impact, expected/observed behavior,
  reproduction, exact frozen-source lines, and proposed fixes.
- `fixtures/F1.json` through `F4.json`: complete reproducible local positions
  and prescribed dice/phase data. These are audit input, not app save files.
- `fixtures/F1_board.csv`: the full endgame board in a readable table.
- `results/audit_results.json`: score branches, nearby controls, actor forks,
  winner boundaries, and print-checker mutation result.
- `results/desk_traces.json`: stage-by-stage boards for both desk traces.
- `results/strict_card_cells.json`: independent checks of all 18 card cells.
- `results/clean_rebuild.json`: byte-identical hashes for all three rebuilt PDFs.
- `results/source_review.json`: exact rules source, public module version,
  scope, and MPAJA icon distribution read from all 32 regular card faces.
- `sources/module_assets_manifest.json`: component filenames and hashes.
- `manifest.json`: exact release archive and standalone-PDF identities.
- `write_report.py`: report generator, using ReportLab and DejaVu Sans. It
  writes a report PDF and Markdown next to the evidence folder.

The official rulebook, Event art, map art, and player-aid images are linked and
hashed, not redistributed in this package. The current GMT rulebook's text
matches the retailer mirror used for development. Its exact current bytes and
the public module graphics used for review are identified in the report.

The original 52 checks and the print checker pass the intact release. That
does not invalidate the newly reproduced counterexamples: those checks do not
execute the full paper opponent or a complete game.
