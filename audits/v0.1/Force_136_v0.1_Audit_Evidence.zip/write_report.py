#!/usr/bin/env python3
"""Generate the v0.1 audit report from the frozen evidence and findings."""
from pathlib import Path
from xml.sax.saxutils import escape
import json,hashlib,csv
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
OUT=WORK/'Force_136_v0.1_Comprehensive_Audit.pdf'
RULE_URL='https://gmtwebsiteassets.s3.us-west-2.amazonaws.com/TheBritishWay_EnemyofMyEnemy/EomE_JapOcc_Rules.pdf'
MODULE_URL='https://vassalengine.org/library/projects/The_British_Way_Counterinsurgency_at_the_End_of_Empire'
FINDINGS=[
dict(id='F1',severity='High',category='Strategy / terminal decision',title='The Event-first priority can turn a certain British win into an MPAJA win',
impact='A legal final-turn Supply wins for Force 136, but the compulsory A-Event gate takes J4 instead and hands the victory to the independent MPAJA. Japan and the bot both lose. This is a reproducible tactical blunder, not a measured overall win-rate result.',
reference='Published rules 1.13, 4.2.1, 6.1, 6.2, 6.7.3 and 7.0.1; physical J4. Bot goal: a competitive Force 136 opponent that distinguishes its own victory from an MPAJA victory.',
source='baseline/build_force136.py:64 (J4 gate), :100 (Event before urgent needs), :101 (camp-count rescue); shipped PDF pages 1 and 9.',
setup='Campaign 3, sixth regular Event already revealed, J4 current; Japan has taken Limited, so Event and Op & SA are free. Resistance 19, Zipper 18, Resources 0. Force 136 and Camps are together in Kedah, Perak and Pahang. No caches on the map; five Available. Three red guerrillas Available. Opposition is in those same three Provinces: 6 Population opposed and 10 Neutral. Police occupy only Kuala Lumpur and Johore. The complete 15-Troop / 6-Police / 14-guerrilla inventory and all positions are in fixtures/F1.json. No Intel is revealed and no capability is active.',
steps=['Confirm that the next card is necessarily final Propaganda: all six regular Events in the last campaign have appeared. This uses public deck information.',
'Follow page 1: consult J4 before the urgent camp-count rule. Three Force 136/Camp spaces make the unshaded option an A Event.',
'Execute it: Resistance increases only from 19 to the cap of 20. At final Propaganda, three automatic red recruits create no guerrilla majorities. The 10 Neutral Population deduct 2. No other score modifier applies.',
'As a counterfactual, use Contact/Supply. The reproduced legal move is Pahang to Kelantan, creating a Camp, followed by three Supplies at Kelantan, Perak and Kedah. A Contact hold followed by three Supplies also wins. Neither line uses concealed Intel.'],
expected='Choose an available guaranteed British-winning line over an Event that is known to lose for Britain. Forecast the final Propaganda net and the independent winner, including the Resistance cap.',
observed='J4 U: 20 - 2 = 18, with Camps = Force 136 = 3: MPAJA wins. J4 S is no rescue: 19 - 2 = 17, so Japan wins. Contact/Supply: 19 + 3 caches - 2 = 20, so Britain wins. In the moving-Contact version one Camp remains against three Force 136; in the hold version none remain.',
fix='On a publicly certain final scoring turn, rank otherwise legal candidate actions by their actual post-Propaganda winner before applying Event preference. A guaranteed Force 136 win must outrank an MPAJA win or Japanese win. Reuse the existing camp-count check; do not add a recurring player track.',
evidence='reproduce_audit.py: final_trap(); fixtures/F1.json; results/audit_results.json. Assertions require Event = MPAJA, shaded Event = Japan, both Supply variants = Force 136. Nearby Resistance 16 is a negative control: neither unshaded Event nor Supply wins.'),
dict(id='F2',severity='Medium',category='Strategy / no-effect Event',title='J26 is an A Event even when its only reward is lost at the Resistance cap',
impact='The bot exposes an underground guerrilla while gaining no Resistance and moving no Japanese unit. The ordinary Ambush available on its own card instead removes the local Troop threat with certainty.',
reference='Published rules 1.13, 2.4.5 and 3.2.4; physical J26 replaces Troop movement with its Resistance reward. The bot itself defines useful actions on PDF page 2.',
source='baseline/build_force136.py:86 (J26 chance-only gate), :100 (A Event first), :106 (usefulness), :132 (normal STRIKE); shipped PDF pages 1, 2, 5 and 11.',
setup='Campaign 2, Resistance 20, current J26, active bot card 13. Japan has already taken Limited. Negri Sembilan has one Troop, one underground red guerrilla, one Force 136 and one cache; no Police, Kempeitai or Camp. The cache gives +1 against one cube. All other pieces are accounted for in fixtures/F2.json. The Kill Traitors icon has no eligible target.',
steps=['Read J26: all six die faces succeed, so the printed gate rates it A.',
'Take Event and roll 1: modified 2 beats the one cube. Activate the guerrilla. Apply the Event reward in place of displacement.',
'For a nearby counterfactual, take ordinary STRIKE using Op & SA without a Special Activity. The same die displaces the Troop to Kuala Lumpur.',
'On a following ordinary J3, with no eligible Mobilize icon effect, Japan is first after its prior Limited. It can Assault the exposed guerrilla in the Event branch. It cannot Assault Negri Sembilan in the ordinary-Ambush branch because no Troop remains there.'],
expected='At the cap, do not rate a reward-only Event as a positive A Event unless an explicit denial benefit justifies spending the turn. Here Japan has already acted, so there is no such benefit.',
observed='Event branch: Resistance stays 20, the Troop stays, and the guerrilla becomes Active. Ordinary Ambush: Resistance also stays 20, but the Troop leaves. The next Japanese Assault can remove the exposed guerrilla only in the Event branch.',
fix='Add an actual-gain condition to the J26 gate: require min(20, Resistance + 2) > Resistance. If Event denial is desired, express it separately rather than treating a capped reward as useful. Apply the same cap-aware review to J4.',
evidence='reproduce_audit.py: cap_trap(); fixtures/F2.json. Success faces are 1-6; actual Event gain is 0. Nearby control at Resistance 18 produces a real gain of 2.'),
dict(id='F3',severity='Medium',category='Decision procedure / interpretation-dependent tempo loss',title='Ordinary Operation planning does not pin down post-operation Special Activity usefulness',
impact='A current-board reading chooses Op & SA for a Gather that Sabotage itself makes impossible. Britain makes the same Sabotage attacks it could make under Limited, but yields first eligibility without a Special Activity. A reader who forecasts the activation may avoid the mistake; the two readings are not distinguished in the printed procedure.',
reference='Published rules 2.4.4, 2.4.5, 3.2.3 and 4.2.2; British player-aid columns. Limited British Sabotage may use multiple Force 136 spaces. Ordinary Gather still needs underground guerrillas.',
source='baseline/build_force136.py:107 (box choice), :108 (Operation before Special Activity), :129 (recheck after Operation); baseline/reference_checks.py:49 and :52. Shipped PDF pages 2 and 4.',
setup='Bot card 09; Britain first. All three boxes are free; current J31 has no useful Event because Resources = 0. Kedah, Perak and Negri Sembilan each have one Force 136 and exactly one underground red guerrilla. No other guerrilla and no cache is on the map. All relevant Intel is concealed and three distinct legal railway attacks exist. J31 Mobilize has already placed Opposition in Perak.',
steps=['Evaluate the current board: GATHER, first in the card\'s Special Activity order, has legal concealed Intel opportunities.',
'The current-board call to the shipped helper selects Op & SA. Perform all three Sabotage attacks, activating all three guerrillas.',
'Recheck Gather as page 4 instructs: no underground guerrilla remains. Raid is also unavailable. Omit the Special Activity.',
'Repeat the same three attacks under Limited: Britain retains first eligibility. As a nearby positive control, add one underground guerrilla in Kelantan; it can survive the attacks and Gather via Perak, making Op & SA useful.'],
expected='Specify whether usefulness is evaluated before or after the selected Operation. A deterministic paper bot should not require the player to infer a forecast rule that is explicitly stated only for primary Special Activity tasks.',
observed='The reproducible current-board branch chooses Op & SA and performs no Special Activity. The forecast branch chooses Limited and gets identical Sabotage with better next eligibility. Both readings fit portions of the present prose.',
fix='Replace the box test with: choose Op & SA only if a compatible useful Special Activity remains possible after the planned Operation and its compulsory activations. Otherwise prefer Limited. This preserves the existing Operation-first timing.',
evidence='reproduce_audit.py: initiative_trap(); fixtures/F3.json. This is a confirmed specification gap and bad allowed branch, not an assertion that every reader or a non-existent app always chooses it.'),
dict(id='F4',severity='Medium',category='Decision procedure / unresolved actor choice',title='Ambush and Gather lack the guerrilla-color tie-break supplied for Sabotage',
impact='Two players following the paper bot can produce different board states from the same position. The difference changes which color is exposed, lost or remains recruitable; it is not merely cosmetic.',
reference='Published rules 3.1, 3.2.4, 4.2.2 and 5.4; physical J6. The executing faction chooses the friendly piece used, so a solo procedure needs to supply that choice.',
source='baseline/build_force136.py:132 (STRIKE), :125 (Gather), :127 (red-before-blue exists only for RAIL); shipped PDF pages 4 and 5. The forced-loss preference at :112 does not select an actor for an action.',
setup='Negri Sembilan: one Troop, one Police, one underground red and one underground blue guerrilla, Force 136, Camp and cache. No Kempeitai. Bot card 13; Japan has already taken Op & SA, so the bot uses Limited Ambush. Current J17 Seize has no eligible target because the cache already shares a space with a Camp. All other pieces are in fixtures/F4.json.',
steps=['Follow STRIKE: remove the Police. An underground guerrilla must be activated, but STRIKE supplies no red/blue choice.',
'Branch A activates red; branch B activates blue. Space tie-breaks cannot distinguish two pieces in the same space.',
'For a prescribed referee continuation, reveal J6 next. Food Shortage has no target: the only red guerrilla is cache-protected. Roll 1 for Negri Sembilan. Under the bot\'s loss priority, remove the Active guerrilla before the underground one. Japan also resolves its own loss; that does not change the British color comparison.'],
expected='One deterministic actor choice, expressed in the paper rules, without borrowing a priority explicitly limited to a different action.',
observed='Both Ambush branches are legal, but after the same attrition one leaves blue and the other leaves red. Gather has the same missing actor tie when both underground colors occupy one eligible Intel space. A single-color position is the nearby unambiguous control.',
fix='Add a global activation rule, for example: when either color is equally legal, activate an underground red guerrilla before blue, unless the effect specifically requires one color or a moved Raid participant. Apply it explicitly to Ambush and Gather.',
evidence='reproduce_audit.py: actor_gap(); fixtures/F4.json. Both branches and the correctly ordered MPAJA icon/mandatory effect are recorded in results/audit_results.json.'),
dict(id='F5',severity='Medium',category='Verification / printable integrity',title='The print checker accepts a card with its Special Activity order deleted',
impact='The current shipped card is intact. The defect is in the release guard: a future card can lose required instructions while the checker still claims all 18 cards match.',
reference='Expected release behavior: each field on each individual bot card must match its own source row. Text on a different card cannot satisfy the check.',
source='baseline/verify_printables.py:40 (page-wide text), :46 (membership check). Witness: card 09, combined PDF page 15, top-right cell; separate card PDF page 2.',
setup='Make an isolated copy of the unmodified shipped ZIP contents. Leave bot_data.json unchanged. Card 09 and card 11 share the text GATHER > RAID on the same sheet.',
steps=['In the copy only, remove the GATHER > RAID field from card 09 in both the combined and separate PDFs.',
'Run the unmodified shipped verify_printables.py. The two mutated PDFs still match each other, and card 11 still supplies the missing phrase to the page-wide search.',
'Independently read only card 09\'s rectangle: x 396-576, y 167-419 PDF points. Its required field is missing.'],
expected='The original checker must fail the mutant while continuing to pass the intact release.',
observed='The shipped checker exits 0 and reports cards_matched = 18. The independent card-09 clip check fails. The untouched baseline passes an independent per-card check for every field across all three columns.',
fix='Find the six card rectangles on each sheet and validate every card\'s ID, title, primary text, preparation order, Special Activity order, region and Event flag inside its own rectangle. Keep the separate-versus-combined pixel comparison as an additional check.',
evidence='reproduce_audit.py: mutation_test(); results/mutant_verifier_stdout.txt and results/strict_card_cells.json. The mutant is created under mutated_card09; no delivered v0.1 file is changed.'),
]

QUESTIONS=[
('Q1 - Event completion and card aging (internal bot design)',
'A fresh SUPPLY card takes J25 U and completes Contact/Supply inside the Event. Page 1 says discard when the primary task was attempted, but also retain a card when an Event used the turn instead. The helper treats EVENT as different from SUPPLY. Source: baseline/build_force136.py:103 and :85; baseline/reference_checks.py:71 and :219. Decide which branch governs. Smallest wording consistent with the existing helper: an Event ages the active card once and never completes its printed primary task, even if it includes a matching free action. This is a design decision, not an unresolved GMT ruling.'),
('Q2 - Contact hold versus expansion (internal bot design)',
'INTEL says Contact may hold when current positions already allow a useful Gather; generic Contact prefers placing an Available marker and then moving. With two productive on-map markers and a third Available, one reader holds and another expands. Source: baseline/build_force136.py:115 and :125, PDF pages 3-4. Smallest proposed resolution: INTEL holds if current anchors already yield useful Gather; otherwise use normal placement/movement priorities. The six-Event hunting desk trace states and uses the hold interpretation. Neither interpretation is a publisher-rule violation.'),
]

OPTIONAL=[
('U1 - Put regional priorities in one comparison table',
'Replace the three long rail-name chains with eight rows and N/C/S rank columns. Include the live-route preference once above it. This changes no target priority and reduces repeated visual searching. All eight rails and four starred exits were checked against the map.'),
('U2 - Add global reminders on the bot cards',
'A short line saying check Event and urgent needs first, plus the relevant procedure page, would reduce dependence on remembering page 1. Keep the existing upright/sideways two-turn state; do not add a recurring track.'),
('U3 - Treat declined B Events and D denial as a focused experiment',
'J14 can qualify only as B on a B-NO card; its current otherwise-D condition is then not reconsidered, leaving Japan the permanent-cache-removal option. Re-evaluate D after the B-card filter if defense is intended. This is an optional strategy change, not a proven always-better fix: denying an Event spends a turn and can forgo a stronger Operation. Compare the actual board trade-off before making D universal.'),
('U4 - Target the next usability test at cache defense and live-rail tracing',
'The hunting pilot ends its first Propaganda with two caches under Japanese Troops and no guerrillas after the Japanese free Reprisal. That exposes a useful playtest target, not a demonstrated dominant strategy. Test whether guard commitments survive the known nonfinal Propaganda response. Separately time the live-route lookup on real pieces; do not turn it into a second network-management game.'),
]

def report_markdown():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    L=['# Force 136 v0.1 - Comprehensive audit','',
       '20 November 2026 | Human Japan, paper Force 136 bot | Audit only; the baseline was not changed','',
       '**Finding count: 5 confirmed items - 1 High and 4 Medium.** They comprise two forced strategic blunders, two incomplete decision procedures, and one printable-verifier defect. There are also two internal design ambiguities and four optional usability/strategy recommendations.','',
       '## Exact target and rules','',
       'The reviewed release is the original 18-card Force 136 v0.1, dated 20 November 2026: the 16-page combined PDF, three card sheets, two reference pages, all 32 Event decision entries, editable rules and JSON, PDF builder, 52 reference checks and the printable checker. It is a standard standalone Japanese Occupation opponent; linked campaigns, Personas and Pre-War Options are excluded. No app exists, so UI previews, Undo, reload and application-save recovery are not applicable. JSON fixtures in this audit are runnable audit positions, not Vassal or web-app saves.','',
       'The current GMT-hosted 28-page Japanese Occupation rulebook was checked against the original retailer mirror. Its bytes differ but its extracted text is identical on all 28 pages. Both columns of the rules and player aids were checked in the original layouts. I also read all 35 Event/Propaganda card faces and all four Japanese Occupation player aids from the current public Vassal module v3.1.1; the module graphics are supporting component reproductions, while GMT rules govern. Aid 4 contains transition/options/Personas: its layout was checked and its out-of-scope procedures were not applied to this standalone bot.','',
       'GMT product resources and targeted searches were checked for corrections. No separate Japanese Occupation errata sheet was located. Vassal changelog corrections are module implementation fixes and were not treated as changes to the board-game rules.','',
       f'Rules: {RULE_URL}','',f'Component-source module: {MODULE_URL}','',
       'Archive identity:','',f'- ZIP SHA-256: {manifest["zip_sha256"]}',f'- Archived combined PDF SHA-256: {manifest["zip_pdf_sha256"]}',
       f'- Standalone PDF SHA-256: {manifest["standalone_pdf_sha256"]}','',
       'The standalone and archived PDFs have different container hashes but identical extracted text and matching rendered page pixels in the transport comparison. This is not a gameplay or printing finding. The evidence ZIP contains the exact frozen source under baseline/. All source-and-line references below are relative to that ZIP.','',
       '## Checks and normal-play evidence','',
       '| Check | Direct result | Limit |','|---|---|---|',
       '| Original reference suite | 52/52 pass; original seed 136001 retained | Helpers do not execute a complete game |',
       '| Original printable checker | Passes the intact release | F5 proves a missing-field blind spot |',
       '| Independent card-cell scan | All 18 cards pass in their own rectangles, all three columns | Does not validate strategic quality |',
       '| Clean rebuild | All three PDFs match shipped ZIP bytes exactly | Reproducible output is not a rules proof |',
       '| Published example | Six Events, setup through first Propaganda/reset; Resistance 6 matches the book | Uses published human decisions, not the bot |',
       '| Bot desk pilot | Six normal bot turns against stated Japanese hunting; first Propaganda Resistance 6 | One disclosed Contact interpretation; not a complete game |',
       '| Focused reproductions | F1-F4 board/dice fixtures, F5 PDF mutation; 20 independent winner boundaries | Deterministic cases, not sampled win rates |','',
       'The published example reconstruction independently checks the two-column sequence: Reprisal before Sweep, Supply before Train, stock exhaustion and same-space refresh, protected caches during Assault, multiple-marker Limited Contact, Gather before Ambush, Intel concealment, automatic recruitment and net Resistance. Its first score is 3 + 4 Intel + 1 cache + 3 majorities - 2 Resources - 2 Neutral Population - 1 Police = 6. One damaged central railway survives Reset. These interleavings are legal even though the bot deliberately uses a simpler Operation-first policy.','',
       'The normal bot pilot uses the physical example Event order J14, J27, J2, J17, J8, J21, then J33, and an exact recorded bot-deck order. Japanese play strips the Perak Camp, removes its Force 136, concentrates Troops, and uses nonfinal Propaganda Reprisal to threaten cache defense. Four of six bot turns are Events; Supply and Intel are the two primary normal-operation turns. The pilot ends the first nonfinal Propaganda at Resistance 6, two Force 136, two caches and no Camps. It is not a win, and its result is not an A/B comparison with the published example because Japanese decisions differ.','',
       'Printed navigation was counted as locations used during this desk reconstruction, not as trained-player physical timing: the Supply and Intel turns each referenced six printed locations including their card sheet, while the Event turns referenced three to five. Recurring added bookkeeping is one active card, its upright/sideways state and two bot piles. The around-one-minute ordinary-turn design target has not been measured at a physical table. Full stage-by-stage boards and reference locations are in results/desk_traces.json.','',
       'No complete three-campaign bot game, physical playtest, general automated board executor, broad exploit search or matched-seed balance comparison was completed. No win-rate percentage is reported. The evidence establishes the specific failures below and validates the scoped walkthroughs; it does not establish competitive strength.','',
       '## Confirmed findings','']
    for f in FINDINGS:
        L += [f'### {f["id"]} - {f["severity"]}: {f["title"]}','',f'**Category:** {f["category"]}','',f'**Player impact:** {f["impact"]}','',f'**Rule / expected behavior:** {f["reference"]}','',f'**Source:** {f["source"]}','',f'**Smallest useful setup:** {f["setup"]}','', '**Exact reproduction:**','']
        L += [f'{i+1}. {s}' for i,s in enumerate(f['steps'])]
        L += ['',f'**Expected result:** {f["expected"]}','',f'**Observed result:** {f["observed"]}','',f'**Smallest proposed fix:** {f["fix"]}','',f'**Runnable evidence:** {f["evidence"]}','']
    L+=['## Ambiguous rulings / design choices','', 'These are internal bot design decisions, not claims that GMT rules are wrong.','']
    for h,t in QUESTIONS:L += ['### '+h,'',t,'']
    L+=['## Optional usability and strategy improvements','']
    for h,t in OPTIONAL:L += ['### '+h,'',t,'']
    L+=['## Strategy challenges and information limits','',
        '| Challenge | Reproduced result | What it does not establish |','|---|---|---|',
        '| Neutral-Population defense at the end | F1: an A Event gives MPAJA the win; legal Supply guarantees Britain the win | Frequency in natural games |',
        '| Hunting exposed resistance | F2 and the six-Event pilot: a capped Event exposes a guerrilla; Camp stripping and removal reduce the network | A dominant hunting strategy |',
        '| Initiative and extraction opportunities | F3: ordinary Sabotage can needlessly hand Japan first eligibility | A perpetual denial loop or quantified score margin |',
        '| Mixed-group attrition | F4: identical dice can leave different colored survivors under the incomplete actor rule | Which color priority is strongest in every position |','',
        'The final-turn fixture uses a publicly certain last Propaganda, not knowledge of an unseen card. Concealed Intel values are absent from bot selection. In the desk traces the referee uses the published example Intel assignment, while the bot targets only concealed/revealed status and legal public geometry. The F4 next-card continuation is a prescribed referee test, not information the bot uses. Stock accounting includes all 15 Troops, six Police or their Available balance, ten red and four blue guerrillas, all three Kempeitai, all three Force 136, four Camps, and five caches including any on Zipper.','',
        'Correct boundaries rechecked include strict camp-count ties at Resistance 18-19, no normal early victory, J9 final scoring before either normal turn, Mandatory Event box closure even when its effect is empty, marker-versus-force distinction, compatible Special Activities, ordinary Sabotage versus Event stacking, cache protection by underground guerrillas, nonfinal Supply after scoring, and persistent Sabotage on Reset. Not all of these have a full general executor; the report distinguishes the original checks, independent score assertions and desk reconstructions.','',
        '## Reproducing the audit','',
        'Extract the evidence ZIP. With Python and PyMuPDF, run:','',
        '```text\npython3 reproduce_audit.py\npython3 desk_traces.py\npython3 baseline/reference_checks.py\npython3 baseline/verify_printables.py\n```','',
        'Without PyMuPDF, the four board cases and independent score checks can run with python3 reproduce_audit.py --skip-pdf-mutation. The PDF mutation requires PyMuPDF. Rebuilding the original PDFs additionally requires ReportLab and DejaVu Sans. The frozen baseline is preserved; the mutation script creates a disposable mutated_card09 copy. Do not print the deliberate mutant as a game component.','',
        'Evidence includes full F1-F4 JSON positions, the independent score oracle, the mutant detector, original and independent check receipts, clean-rebuild hashes, strict card-cell results, source/component hashes and both desk reconstructions. Official rulebook pages, player-aid art and Event art are linked and hashed rather than redistributed.','',
        '## Fix order and release verdict','',
        '1. Correct the final-scoring Event choice in F1 and capped J26 reward in F2.\n2. Make post-Operation Special Activity usefulness and colored-actor selection explicit (F3-F4); settle Q1-Q2 at the same time.\n3. Validate every card field inside its own rectangle (F5), with the deletion mutant as a regression test.\n4. Run complete three-campaign games using extraction, hunting, adaptive repair and mixed strategies. Add adversarial repeated play only after the rules and paper decisions are settled. Measure physical administration before adding more bot machinery.','',
        '**Release verdict: HOLD v0.1 for a competitive public release.** The package is reproducible and the shipped print content is intact: 52 checks pass, all 18 cards match independently, and all three PDFs rebuild exactly. However, F1 proves a forced choice that throws away a guaranteed British win, F2 proves a no-reward action that exposes a guerrilla, F3-F4 leave material decisions to interpretation, and F5 weakens the print gate. Keep v0.1 as a development prototype until those items are corrected and complete-game validation supports a stronger claim.','']
    return '\n'.join(L)

FONT=Path('/usr/share/fonts/truetype/dejavu')
for n,f in [('Audit','DejaVuSans.ttf'),('AuditBold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(n,str(FONT/f)))
pdfmetrics.registerFontFamily('Audit',normal='Audit',bold='AuditBold',italic='Audit',boldItalic='AuditBold')
INK=colors.HexColor('#18352F');GOLD=colors.HexColor('#C69C48')
BODY=ParagraphStyle('body',fontName='Audit',fontSize=9.1,leading=12.4,spaceAfter=6,textColor=INK,allowWidows=0,allowOrphans=0)
SMALL=ParagraphStyle('small',parent=BODY,fontSize=8.0,leading=10.5,spaceAfter=4)
H1=ParagraphStyle('h1',parent=BODY,fontName='AuditBold',fontSize=21,leading=25,spaceAfter=16)
H2=ParagraphStyle('h2',parent=BODY,fontName='AuditBold',fontSize=14,leading=18,spaceBefore=13,spaceAfter=9,keepWithNext=True)
H3=ParagraphStyle('h3',parent=BODY,fontName='AuditBold',fontSize=11.2,leading=15,spaceBefore=9,spaceAfter=7,keepWithNext=True)

def markup(s):
    s=escape(s)
    import re
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    return s

def header(c,d):
    c.saveState();c.setFillColor(INK);c.rect(0,748,612,44,fill=1,stroke=0)
    c.setFillColor(colors.white);c.setFont('AuditBold',9.4);c.drawString(36,766,'FORCE 136 v0.1 - COMPREHENSIVE AUDIT')
    c.setFont('Audit',7.5);c.drawRightString(576,766,'20 NOVEMBER 2026')
    c.setFillColor(INK);c.setFont('Audit',7);c.drawString(36,23,'Human Japan / paper Force 136  |  Baseline preserved  |  No complete-game win rate claimed')
    c.drawRightString(576,23,str(d.page));c.restoreState()

def render(md):
    story=[];lines=md.splitlines();i=0;code=False
    while i<len(lines):
        line=lines[i]
        if not line.strip():i+=1;continue
        if line.startswith('```'):
            code=not code;i+=1;continue
        if line.startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].startswith('|'):
                cells=[s.strip() for s in lines[i].strip('|').split('|')]
                if not all(set(x)<={'-',':',' '} for x in cells):rows.append([Paragraph(markup(x),SMALL) for x in cells])
                i+=1
            widths=[122,213,205] if len(rows[0])==3 else [540/len(rows[0])]*len(rows[0])
            t=Table(rows,colWidths=widths,repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E3ECE5')),
                                   ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),
                                   ('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),
                                   ('BOTTOMPADDING',(0,0),(-1,-1),5),('LINEBELOW',(0,0),(-1,0),.7,GOLD),
                                   ('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#CBD6CE'))]))
            story += [t,Spacer(1,10)];continue
        if line.startswith('# '):story.append(Paragraph(markup(line[2:]),H1))
        elif line.startswith('## '):
            if line!='## Confirmed findings':story.append(Paragraph(markup(line[3:]),H2))
        elif line.startswith('### '):
            if line.startswith('### F'):story.append(PageBreak())
            if line.startswith('### F1 '):story.append(Paragraph('Confirmed findings',H2))
            story.append(Paragraph(markup(line[4:]),H3))
        else:
            if line.startswith('http'):
                text=f'<link href="{line}" color="#304B70">{escape(line)}</link>'
            else:text=markup(line)
            story.append(Paragraph(text,SMALL if code else BODY))
        i+=1
    doc=SimpleDocTemplate(str(OUT),pagesize=(612,792),leftMargin=36,rightMargin=36,topMargin=61,bottomMargin=42,title='Force 136 v0.1 Comprehensive Audit',author='Independent release audit')
    doc.build(story,onFirstPage=header,onLaterPages=header)

def main():
    md=report_markdown();(WORK/'Force_136_v0.1_Comprehensive_Audit.md').write_text(md)
    (ROOT/'findings.json').write_text(json.dumps(FINDINGS,indent=2)+'\n')
    render(md)
    f=json.loads((ROOT/'fixtures/F1.json').read_text())
    with (ROOT/'fixtures/F1_board.csv').open('w',newline='') as stream:
        fields=['space']+list(next(iter(f['board'].values())))
        w=csv.DictWriter(stream,fieldnames=fields);w.writeheader()
        for s,v in f['board'].items():w.writerow({'space':s,**v})
    print(OUT,OUT.stat().st_size)

if __name__=='__main__':main()
