# Reproduce the Force 136 v1.0 review

Reviewed repository: https://github.com/ramyahoo88/the_british_way_solo

Reviewed commit: `615c870cf018a5122b3991b00dfbbd4224d04e42`, branch `claude-force136`.

The ZIP expands to a folder named `review_claude_v1`. Clone the reviewed source as its sibling, named `claude_force136_review`:

```sh
git clone --branch claude-force136 https://github.com/ramyahoo88/the_british_way_solo.git claude_force136_review
git -C claude_force136_review checkout 615c870cf018a5122b3991b00dfbbd4224d04e42
cd review_claude_v1
python3 probe_findings.py
python3 compare_mutation.py
python3 regression_checks.py
python3 method_checks.py
python3 scoring_checks.py
python3 analyze_results.py
```

Python 3.11+ with the standard library is sufficient. `check_printables.py` additionally needs PyMuPDF. `build_report.py` needs ReportLab and a system DejaVu font set.

`probe_findings.py` asserts known discrepancies in the reviewed version, so a successful run means it reproduced them. `compare_mutation.py` deliberately injects an incorrect scoring rule to verify the comparator's ability to reject it; the reviewed primary implementation does not contain that scoring error. It deterministically searches the stated seeds and records the first wrong-winner witness (20007/counter/Agent).

## Larger runs

Run these from `review_claude_v1/evidence`, preserving the source checkout:

```sh
python3 ../../claude_force136_review/force136_v1/code/equiv.py 32 recruit,agent,veteran,legend,mastermind
python3 ../../claude_force136_review/force136_v1/code/cleancmp.py 32 recruit,agent,veteran,legend,mastermind
python3 ../../claude_force136_review/force136_v1/code/holdout_v1.py 20000 128 reproduce_old agent
python3 ../../claude_force136_review/force136_v1/code/holdout_v1.py 50000 16 gpt_fresh
python3 ../../claude_force136_review/force136_v1/code/holdout_v1.py 50000 64 gpt_fresh64 agent
python3 ../../claude_force136_review/force136_v1/code/holdout_v1.py 60000 128 gpt_confirmation128 agent
python3 ../../claude_force136_review/force136_v1/code/look_deep.py 52000 32 agent,mastermind lookc 16 4
python3 ../../claude_force136_review/force136_v1/code/sample_game.py 20005 adaptive
```

The last wide-search command only prints aggregated results; it does not retain per-game rows. Its exact stdout is supplied. The other fresh and replay runs retain full result rows. Games on the same seed are paired across Japan policies and difficulty variants. The first 16 fresh Agent seeds recur in the 64-seed Agent run and are counted only once in the report's totals.

From `review_claude_v1`, run `python3 refresh_experiment.py` to reproduce the 384-execution optional local-refresh comparison, then `python3 analyze_results.py` to recompute all reported regular-policy statistics and seed-cluster bootstrap intervals. That refresh experiment is exploratory and does not justify a release change.

## Evidence map

- `Force_136_v1_Claude_Review.md`: findings, sources and release verdict.
- `evidence/findings.json`: full board/state witnesses for exhausted pools, J22, J27, and stale manifest.
- `evidence/comparator_mutation.json`: actual game whose winner changes while the comparator reports agreement.
- `evidence/regression_checks.json`: previous-fix checks, public-information checks, deck/bonus boundaries, and the unresolved J27 priority witness.
- `evidence/scoring_checks.json`: all three independently recomputed scoring calculations for seed 20007/counter.
- `evidence/method_checks.json`: search-template and discarded-Directive sampling witnesses.
- `evidence/printable_checks.json`, `pdf_inventory.json`: nine-card and complete printed package checks.
- `evidence/independent_statistics.json`: recounts, clustered uncertainty, fresh windows and policy results.
- `evidence/results_*.json`: complete rows from regular-policy replay and fresh runs.
- `evidence/refresh_experiment.json`: matched baseline and refresh rows plus differences.
- `evidence/source_hashes.json`: hashes of reviewed code, printed materials and the official rules PDF.
- Other `.txt` files: exact run output.

The ZIP contains no publisher rulebook or card artwork. The official rulebook URL and hash appear in the report. The shared executor remains a research model, and these materials are not an independent certification of every base-game rule.
