from pathlib import Path
import sys,json,random,statistics
from multiprocessing import Pool
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_review/force136_v1/code'
sys.path.insert(0,str(CODE))
import force136_v1 as F
POLS=['extraction','hunting','repair','adaptive','counter','mixed']
class LocalRefresh(F.Force136):
 def place_one(self,s,c):
  if not self.available(c) and self.board[s][c+'_a']:
   self.board[s][c+'_a']-=1;self.board[s][c+'_u']+=1;return True
  return super().place_one(s,c)
def one(args):
 seed,p,variant=args;cls=F.Force136 if variant=='v1' else LocalRefresh;g=cls(seed);g.policy=p;r=g.run()
 return dict(seed=seed,policy=p,variant=variant,winner=r['winner'],resistance=r['final_resistance'])
if __name__=='__main__':
 with Pool(2) as pool:rows=pool.map(one,[(s,p,v) for s in range(51000,51032) for p in POLS for v in ['v1','refresh']],chunksize=4)
 table={(r['seed'],r['policy'],r['variant']):r for r in rows}
 diffs=[]
 for s in range(51000,51032):diffs.append(statistics.mean(int(table[s,p,'refresh']['winner']=='Force 136')-int(table[s,p,'v1']['winner']=='Force 136') for p in POLS))
 rng=random.Random(139999);boot=sorted(statistics.mean(rng.choices(diffs,k=len(diffs))) for _ in range(10000))
 summary={v:dict(n=192,wins=sum(r['winner']=='Force 136' for r in rows if r['variant']==v),mean_R=statistics.mean(r['resistance'] for r in rows if r['variant']==v)) for v in ['v1','refresh']}
 out=dict(summary=summary,win_delta=statistics.mean(diffs),seed_cluster_95CI=[boot[250],boot[9750]],rows=rows)
 (ROOT/'evidence/refresh_experiment.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
