"""Check the shipped nine-card layout and combined-PDF contents, using PyMuPDF."""
from pathlib import Path
import sys,json,re,hashlib
import fitz
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'claude_force136_review/force136_v1'
sys.path.insert(0,str(SRC/'code'))
import force136_v1 as F
cards=json.loads((SRC/'print/cards.json').read_text())
assert cards==F.DECK
assert cards==json.loads((SRC/'code/cleanroom/cards.json').read_text())
pdf=fitz.open(SRC/'print/Force_136_v1_Cards.pdf')
assert len(pdf)==2
out=[];backs=[]
for i,c in enumerate(cards):
    col,row=i%3,i//3
    rect=fitz.Rect(36+180*col,18+252*row,216+180*col,270+252*row)
    t=pdf[0].get_text(clip=rect)
    assert f"DIRECTIVE {c['id']}/9" in t and c['name'] in t
    full,limited=t.split('LIMITED OPERATION')
    printed=re.findall(r'PLACE|AMBUSH|INTEL|SUPPLY|TRAIN|CONTACT',full)
    assert printed==['PLACE']+c['goals']+['CONTACT'],(c,printed)
    second='TRAIN' if c['limited_first']=='AMBUSH' else 'AMBUSH'
    assert re.findall(r'\b(?:PLACE|AMBUSH|TRAIN|CONTACT)\b',limited)==['PLACE',c['limited_first'],second,'CONTACT']
    assert 'Nothing qualifies: Pass.' in limited and 'Discard after the turn.' in limited
    out.append(dict(id=c['id'],rect=list(rect),goals=printed,limited_first=c['limited_first']))
    back=pdf[1].get_text(clip=rect)
    assert '136' in back and 'DIRECTIVE' in ''.join(back.split())
    backs.append(' '.join(back.split()))
assert len(set(backs))==1
combined=fitz.open(SRC/'print/Force_136_v1_Print_and_Play.pdf')
expected=[]
for stem in ['Rules','Reference','Cards','Record_Sheet']:
    d=fitz.open(SRC/f'print/Force_136_v1_{stem}.pdf')
    expected.extend(p.get_text() for p in d)
assert [p.get_text() for p in combined]==expected
reference=fitz.open(SRC/'print/Force_136_v1_Reference.pdf')
reftext=' '.join(reference[1].get_text().split())
assert 'British J8: +1 Province without F136.' in reftext
result=dict(cards=out,all_nine_identical_back_texts=True,combined_pages=len(combined),
            combined_matches_components_text=True,j8_ambiguous_reference_text_present=True)
(ROOT/'evidence/printable_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print('Nine card rectangles, goal/limited order, identical back text, combined 10-page package: pass.')
