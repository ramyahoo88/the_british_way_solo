"""Focused nearby cases for Claude's documented fixes and card/public-info rules."""
from pathlib import Path
import sys, json, copy
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_review/force136_v1/code'
sys.path[:0]=[str(CODE), str(CODE/'cleanroom')]
import force136_v1 as F, cleanroom as C
from engine import new_board, clamp, BOXES
out={}

# Deck boundary: nine different cards, then a reshuffle of all nine.
g=F.Force136(139010);ids=[]
for _ in range(18):g.draw_directive();ids.append(g.directive['id'])
assert sorted(ids[:9])==sorted(ids[9:])==list(range(1,10))
out['directive_deck_two_cycles']=ids

# Decisions must not depend on concealed Intel values. All nine cards, two positions.
choices=0
for seed in [139011,139012]:
    g=F.Force136(seed);g.bot_turn(BOXES)
    for card in F.DECK:
        g.directive=card;before=copy.deepcopy(g.__dict__)
        a=g.choose(BOXES)
        assert g.__dict__==before, 'Preview mutated the live state'
        g.secret={s:2-v for s,v in g.secret.items()}
        b=g.choose(BOXES)
        assert a==b
        choices+=1
out['public_information_and_preview_cases']=choices

# J8 chooses the complete set first. A failed roll never buys another slot.
class FixedDie(F.Force136):
    def die(self,tag,space=''):
        self.calls.append((tag,space));return 1 if space=='Kedah' else 6
g=FixedDie(139013);g.board=new_board();g.calls=[];g.cap[8]='S'
for s,n in [('Kedah',3),('Perak',2),('Kelantan',1)]:g.board[s].update(force136=1,camp=True,red_u=n)
assert g.supply()==1 and len(g.calls)==2
assert g.board['Kelantan']['camp'] and not g.board['Kelantan']['cache']
out['j8_failed_roll_selected_first']=dict(calls=g.calls,caches=g.count('cache'))

# British J8 changes eligibility, never the overall Supply limit.
g=F.Force136(139014);g.board=new_board();g.track_cache=1;g.zipper=6;g.cap[8]='U'
for s in ['Kedah','Perak','Kelantan']:g.board[s].update(camp=True,red_u=1)
for s in ['Kedah','Perak']:g.board[s]['force136']=1
assert g.supply()==2 and not g.board['Kelantan']['cache']
out['j8_british_total_limit']=g.count('cache')

# The Japanese J27 choice uses lowest Population among selected Opposition.
g=F.Force136(139015);g.board=new_board();g.track_cache=1;g.zipper=6;g.cap[27]='S'
for s in ['Perak','Negri Sembilan']:g.board[s].update(force136=1,camp=True,red_u=1,opposition=True)
g.supply()
assert g.board['Perak']['opposition'] and not g.board['Negri Sembilan']['opposition']
out['j27_japanese_lowest_population']=True

# Removing the last cube clears a New Village immediately; a remaining cube preserves it.
for police,expected in [(1,False),(2,True)]:
    g=F.Force136(139016);g.board['Kedah'].update(force136=1,police=police,new_village=True)
    g.strike(['Kedah'])
    assert g.board['Kedah']['new_village']==expected
out['immediate_new_village_removal_and_nearby_case']=True

# Ambush rolls resolve before the optional Special Activity is chosen.
class AfterRoll(F.Force136):
    def strike(self,*args,**kwargs):
        self.roll_finished=True;return ['test']
    def first_sa(self,after,order):
        assert self.roll_finished;return 'GATHER'
    def special(self,x):return []
g=AfterRoll(139017);g.roll_finished=False
g.execute(dict(op='AMBUSH',sa_list=('GATHER',)))
out['special_activity_chosen_after_operation']=True

# Difficulty bonus is after Zipper calculation and never applied at final scoring.
out['level_bonus']={}
for final in [False,True]:
    states={}
    for level in F.LEVELS:
        g=F.Force136(139018,level=level);g.resistance=7;g.score_only(final)
        states[level]=(g.resistance,g.zipper)
    base=states['agent'][0]
    for level,bonus in [('recruit',0),('agent',0),('veteran',0),('legend',1),('mastermind',2)]:
        assert states[level][0]==clamp(base+(0 if final else bonus))
        assert states[level][1]==states['agent'][1]
    out['level_bonus']['final' if final else 'nonfinal']=states

# Full narrated game shipped to players reproduces, including all scoring summaries.
old=json.loads((CODE/'results/sample_20005_adaptive.json').read_text())
new=json.loads((ROOT/'evidence/sample_20005_adaptive.json').read_text())
assert old==new
out['shipped_full_sample_reproduces']=dict(seed=20005,policy='adaptive',winner=new['winner'],R=new['R'],entries=len(new['narr']))

# The primary Sabotage bonus under J27 uses an inherited remote target ranking.
# Recorded as a paper-priority question, rather than a new illegality finding.
g=F.Force136(139004);g.cap[27]='U';before=copy.deepcopy(g.board)
hits=g.rail()
out['j27_extra_sabotage_priority_question']=dict(seed=139004,
    instruction='Standard setup, set British J27, then Sabotage.',
    hits=hits,first_map_order_remote='Kedah',
    observed_remote='Pahang',before=before,after=g.board)
(ROOT/'evidence/regression_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='j27_extra_sabotage_priority_question'},indent=2))
