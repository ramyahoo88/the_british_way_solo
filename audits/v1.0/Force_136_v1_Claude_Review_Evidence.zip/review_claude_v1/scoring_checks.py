"""Independent score arithmetic on a complete game; no engine score_terms helper."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'claude_force136_review/force136_v1/code'))
import force136_v1 as F

class ScoringReview(F.Force136):
    def score_only(self,final=False):
        r=super().score_only(final)
        b=r['score_board']
        terms=dict(
            intel=sum(0 if x['intel'] is None else x['intel'] for x in b.values()),
            caches=sum(bool(x['cache']) for x in b.values()),
            majorities=sum(x['red_u']+x['red_a']+x['blue_u']+x['blue_a']>x['troops']+x['police'] for x in b.values()),
            resource_penalty=r['resources_used']//4,
            neutral_penalty=sum(x['population'] for x in b.values() if not x['opposition'])//5,
            police_penalty=sum(x['police']>0 for x in b.values())//3)
        assert all(r[k]==v for k,v in terms.items())
        delta=terms['intel']+terms['caches']+terms['majorities']-terms['resource_penalty']-terms['neutral_penalty']-terms['police_penalty']
        expected=max(0,min(20,r['resistance_before']+delta))
        assert r['net_change']==delta and r['resistance_after']==expected
        assert self.zipper==max(x for x in [0,6,12,18,20] if x<=expected)
        expected=max(0,min(20,expected+(self.L['bonus'] if not final else 0)))
        assert self.resistance==expected
        if final:
            camps=sum(bool(x['camp']) for x in self.board.values())
            f=sum(x['force136'] for x in self.board.values())
            winner='Japan' if expected<18 else 'Force 136' if expected==20 or camps<f else 'MPAJA'
            assert self.winner==winner
        if not self.preview:
            self.review_scores.append(dict(draw=self.draw,campaign=self.campaign,final=final,
                terms=terms,before=r['resistance_before'],delta=delta,after=self.resistance,
                zipper=self.zipper,winner=self.winner,score_board=b))
        return r

g=ScoringReview(20007);g.policy='counter';g.review_scores=[]
r=g.run()
assert len(g.review_scores)==3 and g.review_scores[-1]['final']
out=dict(seed=20007,policy='counter',level='agent',winner=r['winner'],R=r['final_resistance'],
         event_order=r['event_order'],scores=g.review_scores,
         limit='Independently checks score arithmetic and victory on engine-provided post-Mobilize/Clashes boards; not a second game engine.')
(ROOT/'evidence/scoring_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='scores'},indent=2))
