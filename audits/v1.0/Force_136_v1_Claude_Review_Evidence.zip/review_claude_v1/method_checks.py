"""Focused witnesses for benchmark search scope and sampled Directive assumptions."""
from pathlib import Path
import sys,random,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'claude_force136_review/force136_v1/code'))
import force136_v1 as F
from engine import stable,BOXES
from expert import british_candidates
g=F.Force136(139020)
plans=british_candidates(g,BOXES)
training=[p for p in plans if p.get('op')=='TRAIN']
assert len(training)==4  # One Limited plan plus full-turn None/Supply/Raid; no target allocations.
g.ddisc=list(F.DECK[:8]);g.dqueue=[F.DECK[8]];g.draw=1
rng=random.Random(stable(g.seed,'look',g.draw))
sampled=[rng.choice(F.DECK)['id'] for _ in range(4)]
assert any(i!=9 for i in sampled)
out=dict(seed=139020,training_templates=training,
         remaining_actual_directive_ids=[9],public_discard_ids=list(range(1,9)),
         first_candidate_sampled_ids=sampled,
         observation='lookahead.py samples uniformly from all nine cards, including known discards; this is an approximate reply distribution, not knowledge of the next hidden card.')
(ROOT/'evidence/method_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
