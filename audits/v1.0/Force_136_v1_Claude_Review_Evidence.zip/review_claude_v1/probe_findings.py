from pathlib import Path
import sys,json,copy,hashlib
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_review/force136_v1/code'
sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import force136_v1 as F,cleanroom as C,cleancmp
from engine import ORDER,new_board,BOXES
out={}
# R1: all pools exhausted, only own Active pieces exist; legal refresh is omitted.
def exhausted(cls):
 g=cls(139001);g.board=new_board()
 g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
 g.board['Perak'].update(red_a=10,force136=1,camp=True,cache=True)
 g.board['Kedah'].update(blue_a=2,force136=1,camp=True)
 g.board['Negri Sembilan'].update(blue_a=2,force136=1,camp=True)
 g.resistance=6;g.zipper=6;g.track_cache=1;g.directive=F.DECK[0];g.invariants();return g
class LocalRefresh(F.Force136):
 def place_one(self,s,c):
  if not self.available(c) and self.board[s][c+'_a']:
   self.board[s][c+'_a']-=1;self.board[s][c+'_u']+=1;return True
  return super().place_one(s,c)
g=exhausted(F.Force136);choice=g.choose(BOXES)
r=exhausted(LocalRefresh);alternate=r.choose(BOXES);r.execute(alternate);r.invariants()
assert choice['op']=='PASS' and alternate['op']=='TRAIN'
assert sum(v['cache'] for v in r.board.values())==3
allcards=[]
for card in F.DECK:
 g.directive=card;allcards.append(g.choose(BOXES)['op'])
assert all(x=='PASS' for x in allcards)
out['R1']=dict(seed=139001,board=g.board,resistance=6,zipper=6,boxes=BOXES,
             available={k:g.available(k) for k in ['red','blue','cache','camp','force136','police']},
             choices_all_nine_cards=allcards,counterplan=alternate,counter_board=r.board)
# R2: cleanroom fails U-side J22's no-activation instruction.
a=F.Force136(139002);b=C.CleanForce136(139002)
for h in [a,b]:h.cap[22]='U'
ra=a.gather();rb=b.gather()
assert ra==rb
au=sum(v['red_u']+v['blue_u'] for v in a.board.values());bu=sum(v['red_u']+v['blue_u'] for v in b.board.values())
assert au==8 and bu==2
out['R2']=dict(seed=139002,capabilities={'22':'U'},reveals=ra,primary_underground=au,cleanroom_underground=bu,
              primary_board=a.board,cleanroom_board=b.board)
# R3: under U-side J27 the primary adds a non-F Ambush; cleanroom drops it.
a=F.Force136(139003);b=C.CleanForce136(139003)
for h in [a,b]:
 h.board['Pahang']['red_u']+=1;h.board['Pahang']['police']=1;h.board['Johore']['red_u']-=1
 h.cap[27]='U';h.invariants()
a.strike();b.strike()
assert a.board['Pahang']['police']==0 and b.board['Pahang']['police']==1
out['R3']=dict(seed=139003,capabilities={'27':'U'},added_setup='Move one red Underground from Johore to Pahang; add one Available Police there.',
              primary_pahang=a.board['Pahang'],cleanroom_pahang=b.board['Pahang'])
# R4: the comparison itself ignores tracks and trace length.
left=[dict(plan=('Limited','TRAIN',None),after={},sab={},R=18)]
right=[dict(plan=('Limited','TRAIN',None),after={},sab={},R=20)]
assert cleancmp.first_div(left,right) is None
assert cleancmp.first_div(left,left+left) is None
out['R4']=dict(resistance_mismatch_accepted=True,missing_or_extra_turn_accepted=True)
# R5: root file manifest has a stale README checksum.
repo=CODE.parents[1];manifest=json.loads((repo/'FILE_MANIFEST_SHA256.json').read_text())
expected=manifest['README.md'];actual=hashlib.sha256((repo/'README.md').read_bytes()).hexdigest()
assert actual!=expected
out['R5']=dict(path='README.md',expected=expected,observed=actual)
(ROOT/'evidence/findings.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{a:b for a,b in v.items() if 'board' not in a} for k,v in out.items()},indent=2))
