"""A real scoring mutant that the shipped clean-room comparator accepts."""
from pathlib import Path
import sys, json
ROOT = Path(__file__).resolve().parent
CODE = ROOT.parent / 'claude_force136_review/force136_v1/code'
sys.path[:0] = [str(CODE), str(CODE/'cleanroom')]
import force136_v1 as F, cleanroom as C, cleancmp
from engine import clamp

class FinalScoreMutation(C.CleanForce136):
    def score_only(self, final=False):
        # Deliberately wrong rule, injected to test the verifier, not a proposed fix.
        if final:
            self.resistance = clamp(self.resistance + 1)
        return super().score_only(final)

for seed in range(20000, 20128):
    for pol in ['extraction', 'hunting', 'repair', 'adaptive', 'counter', 'mixed']:
        a, ta = cleancmp.run(F.Force136, seed, pol, 'agent')
        b, tb = cleancmp.run(FinalScoreMutation, seed, pol, 'agent')
        if a['winner'] != b['winner']:
            assert cleancmp.first_div(ta, tb) is None
            witness = dict(seed=seed, policy=pol, level='agent',
                           primary_result=a, deliberately_wrong_result=b,
                           primary_turns=len(ta), mutant_turns=len(tb),
                           comparator_result=None,
                           mutation='Add 1 Resistance just before final scoring')
            (ROOT/'evidence/comparator_mutation.json').write_text(json.dumps(witness, indent=2)+'\n')
            print(json.dumps(witness, indent=2))
            sys.exit(0)
raise AssertionError('No witness found in the specified deterministic search')
