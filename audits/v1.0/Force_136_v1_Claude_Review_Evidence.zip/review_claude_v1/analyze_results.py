"""Independently recount stored and fresh results, clustering uncertainty by seed."""
from pathlib import Path
import json, collections, random
ROOT = Path(__file__).resolve().parent
SRC = ROOT.parent/'claude_force136_review/force136_v1/code/results'
OUT = ROOT/'evidence'
POLS = ['extraction','hunting','repair','adaptive','counter','mixed']
def load(p): return json.loads(p.read_text())
def stats(rows):
    keys = [(r['seed'],r['pol'],r['level']) for r in rows]
    assert len(keys) == len(set(keys)), 'Duplicate game key'
    out = {}
    for level in ['recruit','agent','veteran','legend','mastermind']:
        rr = [r for r in rows if r['level']==level]
        if not rr: continue
        byseed=collections.defaultdict(list)
        for r in rr: byseed[r['seed']].append(r['winner']=='Force 136')
        assert all(len(v)==6 for v in byseed.values())
        rates=[sum(v)/len(v) for v in byseed.values()]
        rng=random.Random(98173);boots=[]
        for _ in range(20000):
            boots.append(sum(rng.choices(rates,k=len(rates)))/len(rates))
        boots.sort()
        out[level] = dict(n=len(rr),seeds=len(rates),wins=sum(r['winner']=='Force 136' for r in rr),
                         win_rate=sum(rates)/len(rates),seed_cluster_95CI=[boots[500],boots[19500]],
                         mpaja=sum(r['winner']=='MPAJA' for r in rr),
                         mean_R=sum(r['R'] for r in rr)/len(rr),
                         by_policy={p:dict(n=sum(r['pol']==p for r in rr),
                             wins=sum(r['pol']==p and r['winner']=='Force 136' for r in rr)) for p in POLS})
    return out
hold=load(SRC/'results_holdout.json');confirm=load(SRC/'results_confirm.json')
original_agent=[r for r in hold if r['level']=='agent']
rerun=load(OUT/'results_reproduce_old.json')
assert original_agent==rerun, 'Rerun differs from stored original Agent rows'
result=dict(original_agent_rerun_exact_rows=len(rerun),
            holdout=stats(hold),confirmation=stats(confirm),pooled=stats(hold+confirm),
            fresh_all_levels_16_seeds=stats(load(OUT/'results_gpt_fresh.json')),
            fresh_agent_64_seeds=stats(load(OUT/'results_gpt_fresh64.json')))
# Old and fresh seed windows are disjoint; independent cluster bootstrap of their difference.
old=hold+confirm;new=load(OUT/'results_gpt_fresh64.json')
def seed_rates(rows):
    d=collections.defaultdict(list)
    for r in rows:
        if r['level']=='agent':d[r['seed']].append(r['winner']=='Force 136')
    return [sum(v)/len(v) for v in d.values()]
a,b=seed_rates(old),seed_rates(new);rng=random.Random(98174);d=[]
for _ in range(20000):d.append(sum(rng.choices(b,k=len(b)))/len(b)-sum(rng.choices(a,k=len(a)))/len(a))
d.sort();result['fresh_minus_pooled_agent']=dict(delta=sum(b)/len(b)-sum(a)/len(a),seed_cluster_95CI=[d[500],d[19500]])
if (OUT/'results_gpt_confirmation128.json').exists():
    fresh2=load(OUT/'results_gpt_confirmation128.json')
    result['fresh_agent_confirmation_128_seeds']=stats(fresh2)
    result['fresh_agent_combined_192_seeds']=stats(new+fresh2)
    b=seed_rates(new+fresh2);rng=random.Random(98175);d=[]
    for _ in range(20000):d.append(sum(rng.choices(b,k=len(b)))/len(b)-sum(rng.choices(a,k=len(a)))/len(a))
    d.sort();result['fresh_combined_minus_pooled_agent']=dict(delta=sum(b)/len(b)-sum(a)/len(a),seed_cluster_95CI=[d[500],d[19500]])
(OUT/'independent_statistics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
