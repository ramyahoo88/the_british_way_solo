# Force 136 v1.0.3 independent audit — 595f409

Read `Force_136_v1.0.3_Independent_Audit_595f409.pdf` or the matching Markdown report.

Audited repository: https://github.com/ramyahoo88/the_british_way_solo

- Branch: `claude-force136`
- Audited commit: `595f409ccae43f795f7fbdc38878f07f7967682a`
- Paired control: v1.0.2, `338cb0d7bc87ce3c690a88c212aa6878bea8952d`
- Date: 21 November 2026
- Production files changed: none.

## Findings

- P1 (Low): stale flowchart footer still says “Never the Event box”; rule 4.5 correctly permits an ordinary Event-box Pass.
- V1 (Medium, verification): legality checker misses J8 failed-roll conversion, omitted J27 Opposition removal, and Mandatory Event-box Pass.
- V2 (Low, verification): random-position comparator omits capabilities and other public state.
- D1 (Low): rulebook says lookahead before every move; the opponent previews replies only when Japan acts first.

Verdict: pass for playing the bot; patch print wording and verification before calling the package final. No new normal-play bot legality or scoring defect confirmed.

## Reproduce

Clone the repository, checkout the pinned commit, and pass its absolute path as the argument below. Standard simulation scripts need Python 3.11+; `paper_probes.py` and `check_package.py` additionally need PyMuPDF (`fitz`), and `analyze_fresh.py` needs NumPy. The report renderer additionally needs ReportLab and DejaVu fonts.

```
python checker_probes.py /path/to/repository
python paper_probes.py /path/to/repository
python boundary_checks.py /path/to/repository
python raid_witness.py /path/to/repository
python fuzz_complete_state.py /path/to/repository
python japan_information.py /path/to/repository
python table_effort.py /path/to/repository
python check_package.py /path/to/repository
python run_suite.py /path/to/repository
```

`checker_probes.py` and `paper_probes.py` assert the observed current defects. Their successful exit means the defect reproduces, not that the product passes those rules. The other scripts assert the expected correct behavior. After implementing fixes, invert the applicable observation assertions or make them rejection/corrected-text tests.

`run_suite.py` preserves the ten original suite commands and writes a log per command. Its legacy `legality_v1.py games 8` search took about 17 minutes in this environment and left 11 Raids unconfirmed; the author's stored run left seven. `raid_witness.py` covers the same 240 games using actual intermediate-state witnesses and resolves all 537 Raids, retaining the other authored legality checks. A control game confirms instrumentation does not alter outcomes. The witness file contains the complete minimal step evidence, including 73 three-destination Raids.

To recreate the sample before `extended_checks.py`, make `evidence/sample`, run the repository's `code/sample_game.py 20005 adaptive` with that folder as the working directory, then run:

```
python extended_checks.py /path/to/repository
```

Fresh matched comparison requires separate checkouts of the control and audited version:

```
python fresh_games.py /path/to/v1.0.2 v102
python fresh_games.py /path/to/v1.0.3 v103
python analyze_fresh.py
```

This executes 3,072 standard-policy games per version plus 128 wide-lookahead games on v1.0.3. Agent uses seeds 220000–220127 and 230000–230127 against six policies. Other levels and wide lookahead use the first 32 seeds in each block. `fresh_summary.json` includes whole-seed bootstrap intervals and per-policy/block outcomes. Neither block was used to tune a change in this audit.

## Evidence map

- `SOURCE_PIN.json`: source versions, scope and SHA-256 values.
- `AUDIT_MANIFEST_SHA256.json`: hashes of all other files inside this archive.
- `evidence/checker_probes.json`: illegal-result mutations accepted by the checker, with complete Supply board snapshots.
- `evidence/paper_probes.json`: exact PDF page and Pass reproduction for P1; wording proof for D1.
- `evidence/boundary_checks.json`: 18 independent boundary groups.
- `evidence/suite.json` and suite subfolders: exit statuses and outputs for all ten existing checks.
- `evidence/fuzz_complete_state.json`: 12,000 new positions, 132,000 actions with expanded state comparison.
- `evidence/raid_witnesses.json.gz`: all 537 before/after Raid traces, dice and legal step descriptions.
- `evidence/raid_witness_summary.json`: 240 games, 3,810 turns, 965 Raid steps, zero violations.
- `evidence/fresh_v102.json.gz`, `fresh_v103.json.gz`, `fresh_summary.json`: raw new results and paired analysis.
- `evidence/sample_full_trace.json.gz`: complete sample, actual dice and independent score sums.
- `evidence/extended_checks.json`, `event_smoke.json`, `japan_information.json`: preview, hidden-information, railway and Event checks.
- `evidence/table_effort.json`: procedure counts, explicitly not physical time or lookup counts.
- `evidence/package_checks.json`: card, component-PDF and 210-entry repository manifest checks. This proves packaging consistency, not textual correctness; P1 is recorded separately.

No publisher rules, card artwork or maps are redistributed. The inspected bot's existing JSON Pass fixture is referenced from the pinned repository. The runtime and random-seed assumptions are in the scripts and report; reproduce at the exact commits before comparing results.
