"""Independent fixtures for commit 595f409. No production files are changed.

Run: python focused_checks.py /path/to/the_british_way_solo
Observed defects are asserted as observations, not represented as passing rules tests.
JSON positions can be loaded with restore() below.
"""
from pathlib import Path
from copy import deepcopy
import sys,json,random,hashlib
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
CODE=REPO/'force136_v1/code';sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import engine as E,force136_v1 as F,cleanroom as C,expert
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
rows=[]
def record(name,**kw):
    rows.append(dict(name=name,**kw));print(name, json.dumps(kw),flush=True)
def empty(cls=F.Force136,seed=3374501,**kw):
    g=cls(seed,**kw);g.board=E.new_board()
    g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
    return g
def snapshot(g):
    return {k:deepcopy(getattr(g,k)) for k in ('seed','level','board','sabotage','cap','resistance','resources','zipper','track_cache','lost_cache','lost_k','away_troops','away_f','removed_intel','secret','campaign','draw','event','first','chosen')}
def save(g,name):
    d=snapshot(g);d['removed_intel']=sorted(d['removed_intel'])
    (OUT/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
def restore(path,cls=F.Force136):
    d=json.loads(Path(path).read_text());g=cls(d['seed'],level=d['level'])
    for k,v in d.items():setattr(g,k,({int(a):b for a,b in v.items()} if k=='cap' else set(v) if k=='removed_intel' else v))
    g.invariants();return g

# Setup expectations transcribed independently from official p27, both columns.
g=F.Force136(3374500)
assert (g.count('troops'),g.count('police'),g.count('kempeitai'),g.count('force136'),g.count('camp'),g.count('cache'))==(15,3,3,2,3,1)
assert [g.available(k) for k in ('red','blue','cache','camp','force136','police')]==[4,2,2,1,1,3]
assert (g.resistance,g.resources,g.zipper,g.first)==(2,0,0,'B')
assert sorted(g.secret.values())==[0,0,0,1,1,1,2,2,2]
for seed in range(3374500,3374600):
    q=F.Force136(seed);assert len(q.deck)==21 and len(set(q.deck))==21
    for start in (0,7,14):
        pile=q.deck[start:start+7]
        assert sum(j>=33 for j in pile)==1 and all(j<33 for j in pile[:4])
record('setup_and_100_deck_deals',status='pass')

# Train last-resort fallback and donor boundary.
g=empty();g.board['Perak'].update(force136=1,cache=True,red_a=10)
assert g.train()==2 and g.board['Perak']['red_u']==2
g=empty();g.board['Perak'].update(force136=1,cache=True,red_a=8)
g.board['Pahang'].update(red_a=2,cache=True)
assert g.train()==2 and g.board['Pahang']['red_a']==1 and g.board['Perak']['red_u']==2
g=empty();g.board['Perak'].update(force136=1,cache=True,red_u=10)
assert g.train()==0
record('Train_remote_then_local_guard_and_underground_control',status='pass')

# Strict roll threshold; Police removal is automatic; adjacent Cache adds one.
for roll,want in ((2,False),(3,True)):
    g=empty();g.board['Perak'].update(force136=1,red_u=1,troops=3,cache=True)
    g.board['Kuala Lumpur']['troops']-=3;g.die=lambda *a:roll
    g.strike();assert g.resistance==(3 if want else 2)
g=empty();g.board['Perak'].update(force136=1,red_u=1,police=1)
g.board['Kuala Lumpur']['police']-=1;g.die=lambda *a:(_ for _ in ()).throw(AssertionError('Police must not roll'))
g.strike();assert not g.board['Perak']['police'] and g.resistance==2
record('Ambush_strict_threshold_cache_bonus_and_automatic_Police',status='pass')

# J8 failed conversions do not cause re-selection. J27 still removes Opposition
# from a selected opposed Province even if the conversion roll failed.
g=empty();g.cap={8:'S',27:'S'};g.track_cache=1;g.zipper=6
for s in ('Kedah','Perak','Kelantan'):g.board[s].update(force136=1,camp=True,red_u=1,opposition=True)
rolls=[]
def fail(*a):rolls.append(a);return 1
g.die=fail;assert g.supply()==0 and len(rolls)==2
assert g.count('camp')==3 and g.count('cache')==0 and not g.board['Kedah']['opposition']
record('J8_failures_no_reselection_and_J27_selected_space',status='pass',rolls=rolls)

# Sweep simultaneous movement and terrain.
for s,k,n in (('Kedah',0,1),('Kedah',1,3),('Perak',0,3)):
    g=empty();g.board[s].update(troops=3,red_u=4,kempeitai=k)
    g.board['Kuala Lumpur']['troops']-=3;g.board['Kuala Lumpur']['kempeitai']-=k
    g.sweep_plan(targets=[s],strength=3);assert g.board[s]['red_a']==n
g=empty();g.board['Perak']['troops']=5;g.board['Kuala Lumpur']['troops']-=5
g.sweep_plan(targets=['Kedah','Kelantan'],limit=2,strength=3)
assert g.board['Kedah']['troops']+g.board['Kelantan']['troops']==4 and g.count('troops')==15
record('Sweep_terrain_and_simultaneous_conservation',status='pass')

# Construct requires strictly more cubes. Assault protects a Cache with any UG.
g=empty();g.board['Perak'].update(troops=1,red_u=1);g.board['Kuala Lumpur']['troops']-=1
g.sabotage['Perak-Kelantan']=1;assert not g.construct() and g.sabotage['Perak-Kelantan']==1
for k,ug,n in ((0,1,1),(0,0,1),(1,0,2)):
    g=empty();g.board['Perak'].update(troops=3,red_a=1,red_u=ug,cache=True,kempeitai=k)
    g.board['Kuala Lumpur']['troops']-=3;g.board['Kuala Lumpur']['kempeitai']-=k
    assert g.assault()==n and bool(g.board['Perak']['cache'])==(n==1)
record('Construct_strict_superiority_and_Assault_Cache_protection',status='pass')

# Eliminate ordering and strict die test, then the capability exception.
for cap,roll,want in ((None,1,'none'),(None,2,'camp'),('S',2,'force136')):
    g=empty();g.board['Perak'].update(red_u=1,camp=True,force136=1,kempeitai=1)
    g.board['Kuala Lumpur']['kempeitai']-=1;g.cap={22:cap};g.die=lambda *a,r=roll:r
    g.eliminate(['Perak'],1)
    assert g.board['Perak']['camp']==(want!='camp')
    assert g.board['Perak']['force136']==(want!='force136')
    assert g.resistance==(1 if want=='force136' else 2)
record('Eliminate_order_threshold_and_J22_exception',status='pass')

# J6 targets forces, not markers; only Jungle, one shared die per Province.
g=empty();g.board['Kedah'].update(red_a=1,blue_u=1,troops=1,force136=1,camp=True,kempeitai=1)
g.board['Kuala Lumpur']['troops']-=1;g.board['Kuala Lumpur']['kempeitai']-=1
g.board['Perak'].update(red_a=1,troops=1);g.board['Kuala Lumpur']['troops']-=1
rolls=[]
def low(*a):rolls.append(a);return 1
g.die=low;g.mandatory(6)
assert len(rolls)==6 and g.board['Kedah']['red_a']==0 and g.board['Kedah']['blue_u']==1
assert g.board['Kedah']['troops']==0 and g.board['Kedah']['camp'] and g.board['Kedah']['force136']==1
assert g.board['Kedah']['kempeitai']==1 and g.board['Perak']['troops']==1 and g.board['Perak']['red_a']==1
record('J6_shared_die_forces_only_Jungle_only',status='pass')

# Every Zipper threshold, release and return; all map Caches have equal guerrillas.
for target,track in ((0,2),(6,1),(12,1),(18,0),(20,0)):
    g=empty();g.move_zipper(target=target);assert g.track_cache==track and g.available('cache')==5-track
g=empty();g.zipper=20;g.track_cache=0
for s in E.PROV[:5]:g.board[s]['cache']=True
g.move_zipper(target=0)
assert g.track_cache==2 and not g.board['Pahang']['cache'] and not g.board['Trengganu']['cache'] and g.available('cache')==0
record('Zipper_all_boxes_and_two_map_Cache_returns',status='pass')

# Victory ties and bonus timing. Zero net score fixtures: no guerrillas or
# Caches, all Population opposed; no red Available after placing all 10 on EC
# blocked by ten cubes (so Mobilize cannot change anything).
def zero_score(level='agent'):
    g=empty(level=level);g.board['Northern EC'].update(red_u=10,troops=10)
    g.board['Kuala Lumpur']['troops']-=10
    for s in E.ORDER[:9]:g.board[s]['opposition']=True
    return g
for r,camps,f,w in ((17,0,0,'Japan'),(18,2,2,'MPAJA'),(19,1,2,'Force 136'),(20,4,0,'Force 136')):
    g=zero_score();g.resistance=r
    for s in E.PROV[:camps]:g.board[s]['camp']=True
    g.board['Perak']['force136']=f;g.score_only(True)
    assert g.resistance==r and g.winner==w
for level,bonus in (('agent',0),('legend',1),('mastermind',2)):
    g=zero_score(level);g.resistance=17;g.score_only(False)
    assert g.resistance==17+bonus and g.zipper==12
    g=zero_score(level);g.resistance=17;g.score_only(True);assert g.resistance==17 and g.winner=='Japan'
record('Victory_ties_final_bonus_omission_and_Zipper_before_bonus',status='pass')

# J9 resolves Seize Supplies before final score and never takes a player turn.
for campaign in (1,2):
    g=F.Force136(3374509);g.campaign=campaign;g.mandatory(9);assert not g.ended
g=empty();g.campaign=3;g.deck=[9];g.board['Perak']['cache']=True
g.bot_turn=lambda *_:(_ for _ in ()).throw(AssertionError('turn after J9'))
g.japan_turn=g.bot_turn;r=g.run()
assert r['ending']=='J9' and g.ended and g.board['Perak']['camp'] and not g.board['Perak']['cache'] and g.campaign==3
record('J9_icon_before_final_no_player_turns_no_nonfinal_phases',status='pass')

# J15 shaded: Mobilize and scoring treat New Villages as Neutral, without
# deleting their Opposition marker; J12 unshaded can put Opposition despite Terror.
g=empty();g.cap[15]='S';g.board['Kedah'].update(opposition=True,new_village=True,troops=1)
g.board['Kuala Lumpur']['troops']-=1;r=g.score_only()
assert g.board['Kedah']['red_u']==0 and g.board['Kedah']['opposition'] and r['neutral_population']==16
g=empty();g.cap[12]='U';g.board['Perak'].update(troops=1,terror=1)
g.board['Kuala Lumpur']['troops']-=1;g.sabotage['Thailand-Perak']=1;g.repair('Thailand-Perak',True)
assert g.board['Perak']['opposition']
record('J15_propaganda_neutral_and_J12_Event_terror_override',status='pass')

# New Village removal by British forces with no Japanese forces (markers do not count).
g=empty();g.board['Perak'].update(new_village=True,red_u=1,kempeitai=1)
g.board['Kuala Lumpur']['kempeitai']-=1;g.cleanup();assert not g.board['Perak']['new_village']
record('New_Village_cleanup_markers_not_forces',status='pass')

# New choices and nearby cases, independent of Claude's own fixtures.
for british,active,field in ((False,False,'red_u'),(True,False,'red_a'),(False,True,'red_a')):
 g=empty(seed=5954101);g.board['Perak'].update(red_u=1,red_a=1)
 assert g.lose_guerrilla('Perak',british=british,active_only=active)==field
record('Japan_Underground_British_Active_Assault_Active_control',status='pass')

# Japanese Redeploy may retain an ineligible stack origin, but moving extra pieces requires an eligible destination.
g=empty(seed=5954102);b=g.board
b['Perak'].update(force136=1,red_u=2,kempeitai=2,police=2)
b['Kuala Lumpur'].update(kempeitai=1,police=4)
g.japan_redeploy();g.invariants()
assert (b['Perak']['kempeitai'],b['Perak']['police'])==(1,1)
assert (b['Kuala Lumpur']['kempeitai'],b['Kuala Lumpur']['police'])==(2,5)
record('Redeploy_keep_one_K_and_P_extra_pieces_to_eligible_KL',status='pass')

for camp,final in ((False,False),(True,False),(True,True)):
 g=empty(seed=5954103);g.away_f=1;g.board['Perak']['camp']=camp
 if final:g.propaganda(True);assert g.away_f==1 and g.count('force136')==0
 else:
  g.j25_return();assert g.away_f==0 and g.count('force136')==int(camp)
  assert g.available('force136')==3-int(camp)
record('J25_no_Camp_Available_Camp_return_final_no_Reset',status='pass')

# J15 respects colour/Available and cannot take pieces from the map to resolve an Event.
g=empty(seed=5954104);b=g.board;g.cap[15]='U'
b['Kedah'].update(new_village=True,blue_u=1,troops=1)
b['Perak'].update(new_village=True,red_u=1,troops=1)
b['Johore'].update(blue_u=3,red_u=9);b['Kuala Lumpur']['troops']-=2
before=deepcopy(b);g.extract()
assert b['Kedah']['blue_u']==1 and b['Perak']['red_u']==1 and b['Johore']==before['Johore']
b['Johore']['blue_u']-=1;g.extract();assert b['Kedah']['blue_u']==2 and b['Perak']['red_u']==1
record('J15_exhausted_pool_no_map_relocation_blue_majority_control',status='pass')

# J12 lower-population Terror-free space does not outrank higher Population with Terror.
g=empty(seed=5954105);g.cap[12]='U';g.board['Perak']['terror']=1
g.british_j12('Perak-Kelantan');assert g.board['Perak']['opposition'] and not g.board['Kelantan']['opposition']
g.british_j12('Perak-Kelantan');assert g.board['Kelantan']['opposition']
record('J12_priority_population_before_Terror_then_next_eligible',status='pass')
(OUT/'boundary_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Completed',len(rows),'independent boundary groups')
