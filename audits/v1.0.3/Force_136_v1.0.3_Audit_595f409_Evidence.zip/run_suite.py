from pathlib import Path
import sys,subprocess,concurrent.futures,json,time
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
CODE=REPO/'force136_v1/code'
JOBS={'verify':['verify_v1.py','32'],'mutants':['verify_v1.py','--mutants','16'],'fuzz':['fuzz_v1.py','12000','700000'],'legality_games':['legality_v1.py','games','8'],'legality_fuzz':['legality_v1.py','fuzz','2000'],'legality_selftest':['legality_v1.py','selftest'],'fixtures':['review_fixtures.py'],'equiv':['equiv.py','32','recruit,agent,veteran,legend,mastermind'],'exit_status':['check_exit_status.py'],'report':['report_check.py']}
def job(item):
 name,args=item;d=ROOT/'evidence'/name;d.mkdir(exist_ok=True)
 t=time.time();p=subprocess.run([sys.executable,str(CODE/args[0])]+args[1:],cwd=d,capture_output=True,text=True)
 (d/'stdout.txt').write_text(p.stdout);(d/'stderr.txt').write_text(p.stderr)
 row=dict(name=name,command=args,returncode=p.returncode,seconds=round(time.time()-t,2))
 (d/'run.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(job,JOBS.items()))
(ROOT/'evidence/suite.json').write_text(json.dumps(rows,indent=2)+'\n')
