"""Change hidden information only; compare Japanese decisions at visible states."""
from pathlib import Path
from copy import deepcopy
import sys,json
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import force136_v1 as F,lookahead

def state(g):
    return {k:deepcopy(v) for k,v in vars(g).items() if k not in ('log','metrics','decisions','audit_states','last_jp')}
class Capture(F.Force136):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.audit_states=[]
    def japan_turn(self,free):
        if not self.preview:self.audit_states.append((state(self),list(free)))
        return super().japan_turn(free)
    def jp_apply(self,p):
        if not self.preview:self.last_jp=deepcopy(p)
        return super().jp_apply(p)
class Wide(lookahead.LookMixin,Capture):K=16;SAMPLES=4

states=[]
for seed in (20005,5954600,5954601):
    g=Capture(seed);g.policy='counter';g.run();states.extend(g.audit_states)
sample=[states[i*len(states)//32] for i in range(32)]
policies=('extraction','hunting','repair','adaptive','counter','mixed','brute','tempo','econ','eventhog','lookc')
checks=[]
for st,free in sample:
    for policy in policies:
        cls=Wide if policy=='lookc' else Capture
        pair=[]
        for altered in (False,True):
            q=cls(st['seed'],level=st['level'])
            for k,v in st.items():setattr(q,k,deepcopy(v))
            q.policy=policy
            if altered:
                q.secret={s:2-v for s,v in q.secret.items()}
                q.deck=q.deck[:q.deck_pos]+list(reversed(q.deck[q.deck_pos:]))
                q.dqueue=list(reversed(q.dqueue))
            assert q.clone().secret=={}
            q.japan_turn(free);q.invariants()
            pair.append((q.chosen['J'],q.last_jp))
        assert pair[0]==pair[1],(st['seed'],st['draw'],policy,pair)
        checks.append(dict(seed=st['seed'],draw=st['draw'],policy=policy,box=pair[0][0]))
out=dict(captured_positions=len(states),sampled_positions=32,policies=list(policies),comparisons=len(checks),mismatches=0,
         scope='Same public state and random seed; alter secret Intel and future Event/Directive order. Not a complete action-legality oracle.',checks=checks)
(ROOT/'evidence/japan_information.json').write_text(json.dumps(out,indent=2)+'\n')
print('Japanese hidden-information comparisons:',len(checks),'mismatches: 0')
