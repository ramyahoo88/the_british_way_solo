"""Negative controls for the new legality checker; no production edits."""
from pathlib import Path
from copy import deepcopy
import sys,json
ROOT=Path(__file__).resolve().parent;REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import engine as E,force136_v1 as V,legality_v1 as L,fuzz_v1 as Z
out=[]
def empty(cls,seed):
 g=cls(seed);g.board=E.new_board();g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
 g.board['Perak'].update(force136=1,camp=True,red_u=1);return g
class SupplyOnFail(L.Checked):
 def die(self,tag,space=''):return 1
 def supply(self):
  def wrong(g):
   n=V.Force136.supply(g)  # real J8 roll is 1, so this does not convert
   assert n==0 and g.board['Perak']['camp']
   g.board['Perak']['camp']=False;g.board['Perak']['cache']=True
   return 1
  return self._run('SUPPLY',wrong,self)
g=empty(SupplyOnFail,5954001);g.cap[8]='S';g.invariants();before=L.snap(g);g.supply();g.invariants()
assert g.board['Perak']['cache'] and not g.viol.items
out.append(dict(name='J8 failed roll accepted',seed=g.seed,die=1,expected='no conversion; mutant rejected',observed='one Cache placed; zero violations',counts=dict(g.viol.n),before=before))
# Neighbor: the real implementation honors J8's failure.
g=empty(L.Checked,5954001);g.cap[8]='S';g.die=lambda *a:1;assert g.supply()==0 and not g.viol.items
class KeepOpp(L.Checked):
 def supply(self):
  def wrong(g):
   n=V.Force136.supply(g);g.board['Perak']['opposition']=True;return n
  return self._run('SUPPLY',wrong,self)
g=empty(KeepOpp,5954002);g.cap[27]='S';g.board['Perak']['opposition']=True;g.invariants();before=L.snap(g);g.supply();g.invariants()
assert g.board['Perak']['cache'] and g.board['Perak']['opposition'] and not g.viol.items
out.append(dict(name='J27 mandatory removal omitted and accepted',seed=g.seed,expected='remove Opposition; mutant rejected',observed='Opposition retained; zero violations',counts=dict(g.viol.n),before=before))
g=empty(L.Checked,5954002);g.cap[27]='S';g.board['Perak']['opposition']=True;g.supply();assert not g.board['Perak']['opposition'] and not g.viol.items
# A mutation limited to the off-map scalar passes the fuzzer's advertised full state comparison.
a=V.Force136(5954003);b=V.Force136(5954003);b.resources+=1
assert Z.public(a)!=Z.public(b) # nearby tracked-field control
b=V.Force136(5954003);b.cap[22]='S';b.invariants()
assert Z.public(a)==Z.public(b)
out.append(dict(name='fuzzer public state omits capability',seed=5954003,expected='different capability state detected',observed='public(a)==public(b) despite shaded J22 only in b'))
(ROOT/'evidence/checker_probes.json').write_text(json.dumps(out,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n')
for r in out:print(r['name'],r['observed'])
# Mandatory cards close the Event box even for Pass. The fuzz harness itself offers this invalid set.
fx=json.loads((REPO/'force136_v1/code/fixtures/audit_33745a6/F5_event_box_pass.json').read_text())
def pass_position(event):
 g=L.Checked(fx['seed'],level=fx['level'])
 for k,v in fx.items():setattr(g,k,{int(a):b for a,b in v.items()} if k=='cap' else set(v) if k=='removed_intel' else deepcopy(v))
 g.event=event;g.dqueue=[V.DECK[0]];g.invariants();return g
for event in (6,9):
 g=pass_position(event);g.bot_turn(['Event','Op & SA'])
 assert g.last_plan['op']=='PASS' and g.last_plan['box']=='Event' and not g.viol.items
 control=pass_position(event);control.bot_turn(['Op & SA'])
 assert control.last_plan['box']=='Op & SA' and not control.viol.items
 out.append(dict(name=f'J{event} closed Event-box Pass accepted',seed=fx['seed'],expected='reject Pass in the closed Event box',observed='PASS / Event and zero violations',normal_caller_control='PASS / Op & SA, legal'))
(ROOT/'evidence/checker_probes.json').write_text(json.dumps(out,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n')
print(json.dumps([dict(name=x['name'],observed=x['observed']) for x in out],indent=2))
