from pathlib import Path
import json,gzip,collections,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
rows={v:json.load(gzip.open(ROOT/f'evidence/fresh_{v}.json.gz','rt')) for v in ('v102','v103')}
key=lambda r:(r['level'],r['seed'],r['policy'])
old={key(r):r for r in rows['v102']}
new={key(r):r for r in rows['v103'] if not r['wide']}
assert set(old)==set(new)
def report(keys):
 pairs=[(old[k],new[k]) for k in sorted(keys)];seed=collections.defaultdict(list)
 for a,b in pairs:seed[a['seed']].append((int(a['winner']=='Force 136'),int(b['winner']=='Force 136')))
 vals=np.array([np.mean(seed[s],axis=0) for s in sorted(seed)])
 rng=np.random.default_rng(595409);sample=vals[rng.integers(0,len(vals),(10000,len(vals)))].mean(axis=1)
 return dict(games_per_version=len(pairs),seeds=len(vals),v102_wins=sum(a['winner']=='Force 136' for a,b in pairs),v103_wins=sum(b['winner']=='Force 136' for a,b in pairs),v102_pct=round(vals[:,0].mean()*100,3),v103_pct=round(vals[:,1].mean()*100,3),delta_pp=round((vals[:,1]-vals[:,0]).mean()*100,3),delta_95=[round(float(x)*100,3) for x in np.quantile(sample[:,1]-sample[:,0],[.025,.975])],v103_95=[round(float(x)*100,3) for x in np.quantile(sample[:,1],[.025,.975])])
out={'paired_total':len(old),'levels':{},'agent_by_policy':{},'agent_blocks':{},'wide':{}}
for level in ('recruit','agent','veteran','legend','mastermind'):out['levels'][level]=report([k for k in new if k[0]==level])
for pol in ('extraction','hunting','repair','adaptive','counter','mixed'):out['agent_by_policy'][pol]=report([k for k in new if k[0]=='agent' and k[2]==pol])
for start in (220000,230000):out['agent_blocks'][str(start)]=report([k for k in new if k[0]=='agent' and start<=k[1]<start+128])
for level in ('agent','mastermind'):
 w=[r for r in rows['v103'] if r['wide'] and r['level']==level];wins=sum(r['winner']=='Force 136' for r in w)
 out['wide'][level]=dict(games=len(w),wins=wins,pct=100*wins/len(w))
(ROOT/'evidence/fresh_summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
