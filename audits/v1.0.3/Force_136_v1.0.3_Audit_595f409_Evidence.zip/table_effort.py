"""Count procedure tests, not physical lookups or elapsed tabletop time."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import force136_v1 as F
class Count(F.Force136):
 def __init__(self,*a,**k):super().__init__(*a,**k);self.counts=[];self.n_goal=self.n_sa=0
 def goal(self,*a,**k):
  if not self.preview:self.n_goal+=1
  return super().goal(*a,**k)
 def sa_does(self,*a,**k):
  if not self.preview:self.n_sa+=1
  return super().sa_does(*a,**k)
 def bot_turn(self,free):
  if not self.preview:self.n_goal=self.n_sa=0
  super().bot_turn(free)
  if not self.preview:self.counts.append(dict(draw=self.draw,event=self.event,goals=self.n_goal,sa=self.n_sa,plan=self.last_plan,card=self.directive['id']))
allturns=[]
for seed in range(220000,220032):
 for pol in ('extraction','hunting','repair','adaptive','counter','mixed'):
  g=Count(seed);g.policy=pol;g.run();allturns+=g.counts
sample=Count(20005);sample.policy='adaptive';sample.run()
out=dict(games=192,turns=len(allturns),turns_per_game=len(allturns)/192,goal_tests_per_turn=sum(t['goals'] for t in allturns)/len(allturns),sa_tests_per_turn=sum(t['sa'] for t in allturns)/len(allturns),sample_first_three=sample.counts[:3],scope='Procedure calls only; INTEL contains additional board probes; no physical lookup/time measurement.')
(ROOT/'evidence/table_effort.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
