"""Fresh matched v1.0.2/v1.0.3 checks, isolated per-version worker processes."""
from pathlib import Path
import sys,json,gzip,time,random,collections
from multiprocessing import Pool
ROOT=Path(__file__).resolve().parent
POLS=('extraction','hunting','repair','adaptive','counter','mixed')
def one(job):
 seed,pol,level,wide=job
 import force136_v1 as F,lookahead
 class Wide(lookahead.LookMixin,F.Force136):K=16;SAMPLES=4
 g=(Wide if wide else F.Force136)(seed,level=level);g.policy=pol;r=g.run()
 return dict(seed=seed,policy=pol,level=level,wide=wide,**{k:r[k] for k in ('winner','final_resistance','camps','force136','draws','ending')})
if __name__=='__main__':
 repo=Path(sys.argv[1]).resolve();label=sys.argv[2];sys.path.insert(0,str(repo/'force136_v1/code'))
 seeds=list(range(220000,220128))+list(range(230000,230128))
 jobs=[(s,p,'agent',False) for s in seeds for p in POLS]
 jobs += [(s,p,l,False) for s in seeds[:32]+seeds[128:160] for p in POLS for l in ('recruit','veteran','legend','mastermind')]
 if label=='v103':jobs += [(s,'lookc',l,True) for s in seeds[:32]+seeds[128:160] for l in ('agent','mastermind')]
 out=[];start=time.time()
 with Pool(2) as pool:
  for i,r in enumerate(pool.imap_unordered(one,jobs,chunksize=8),1):
   out.append(r)
   if i%256==0:print(label,i,'/',len(jobs),round(time.time()-start,1),flush=True)
 out.sort(key=lambda r:(r['wide'],r['level'],r['seed'],r['policy']))
 with gzip.open(ROOT/'evidence'/f'fresh_{label}.json.gz','wt') as f:json.dump(out,f)
 print('DONE',label,len(out),round(time.time()-start,1),flush=True)
