"""Check actual Raid steps independently; record witnesses rather than search end states.
Run: python raid_witness.py /path/to/repository
The observer only snapshots after cleanup and records the real dice. The verifier does
not call the bot's choice functions or the existing legality checker.
"""
import sys,json,gzip,collections
from pathlib import Path
from copy import deepcopy
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import engine as E, force136_v1 as F, legality_v1 as L
G=('red_u','red_a','blue_u','blue_a'); all_witness=[]
def count(v):return sum(v[k] for k in G)
def cubes(v):return v['troops']+v['police']
def snapshot(g):return {'board':deepcopy(g.board),'sab':dict(g.sabotage),'R':g.resistance}
def check_step(a,b,rolls,adj,rail_adj):
 A=a['board'];B=b['board'];delta={s:count(B[s])-count(A[s]) for s in A if count(B[s])!=count(A[s])}
 sources=[s for s,n in delta.items() if n<0];destinations=[s for s,n in delta.items() if n>0]
 assert len(sources)==len(destinations)==1,delta
 src=sources[0];d=destinations[0];n=delta[d]
 assert n in (1,2) and delta[src]==-n and A[src]['cache'] and src in adj[d]
 moved={k:A[src][k]-B[src][k] for k in G};assert all(x>=0 for x in moved.values()) and sum(moved.values())==n
 M=deepcopy(A);sab=dict(a['sab']);R=a['R']
 for k,q in moved.items():M[src][k]-=q;M[d][k]+=q
 activate=[]
 for c in ('red','blue'):
  du=B[d][c+'_u']-M[d][c+'_u'];da=B[d][c+'_a']-M[d][c+'_a']
  if du or da:
   assert (du,da)==(-1,1) and M[d][c+'_u']>0
   activate.append(c)
 assert len(activate)<=1
 changed_rails=[r for r in sab if sab[r]!=b['sab'][r]]
 kind='move'
 if activate:
  c=activate[0];M[d][c+'_u']-=1;M[d][c+'_a']+=1
  if changed_rails:
   kind='Sabotage';assert len(changed_rails)==1 and not rolls
   r=changed_rails[0];assert sab[r]==0 and b['sab'][r]==1 and d in rail_adj[r];sab[r]=1
  else:
   kind='Ambush';v=M[d];assert cubes(v) or v['kempeitai']
   if B[d]['police']==M[d]['police']-1:
    assert not rolls;M[d]['police']-=1
   else:
    assert len(rolls)==1 and rolls[0][0]==d
    die=rolls[0][1];assert 1<=die<=6
    bonus=sum(M[s]['cache'] for s in M if s==d or s in adj[d])
    success=die+bonus>cubes(v)
    if success and d!='Kuala Lumpur':
     fields=[f for f in ('troops','kempeitai') if B[d][f]==M[d][f]-1]
     assert len(fields)==1;f=fields[0];assert M[d][f]>0
     M[d][f]-=1;M['Kuala Lumpur'][f]+=1;R=min(20,R+1)
    elif success:
     # Moving a KL piece to KL gives no resistance benefit; the present bot removes Police there.
     assert v['troops'] or v['kempeitai']
 else:assert not changed_rails and not rolls
 for v in M.values():
  if v['new_village'] and (count(v) or v['cache']) and not cubes(v):v['new_village']=False
 assert M==B and sab==b['sab'] and R==b['R'],(src,d,kind)
 return {'source':src,'destination':d,'pieces':moved,'action':kind,'rolls':rolls}
class Witness(F.Force136):
 def raid(self):
  if self.preview:return F.Force136.raid(self)
  self._raid_steps=[];self._raid_before=snapshot(self);self._raid_last=self._raid_before;self._raid_rolls=[];self._raid_observe=True
  try:result=F.Force136.raid(self)
  finally:self._raid_observe=False
  assert snapshot(self)==self._raid_last
  assert len(self._raid_steps)<=(3 if self.zipper==20 else 2)
  used=set();a=self._raid_before;steps=[]
  for b,rolls in self._raid_steps:
   step=check_step(a,b,rolls,E.ADJ,{r:set(self.rail_adj(r)) for r in E.EDGES})
   assert step['destination'] not in used;used.add(step['destination']);steps.append(dict(step=step,after=b));a=b
  assert list(result)==[s['step']['destination'] for s in steps]
  all_witness.append(dict(seed=self.seed,level=self.level,policy=self.policy,draw=self.draw,event=self.event,zipper=self.zipper,before=self._raid_before,steps=steps))
  return result
 def cleanup(self):
  F.Force136.cleanup(self)
  if not self.preview and getattr(self,'_raid_observe',False):
   now=snapshot(self)
   if now!=self._raid_last:
    self._raid_steps.append((now,list(self._raid_rolls)));self._raid_last=now;self._raid_rolls=[]
 def die(self,tag,space=''):
  r=super().die(tag,space)
  if not self.preview and getattr(self,'_raid_observe',False) and tag=='Ambush':self._raid_rolls.append((space,r))
  return r
class AllActions(Witness,L.Checked):
 """Keep the shipped operation checks and replace only the expensive Raid search."""
 pass
rows=[];checked=collections.Counter()
for level in ('recruit','agent','veteran','legend','mastermind'):
 for seed in range(800000,800008):
  for pol in ('extraction','hunting','repair','adaptive','counter','mixed'):
   g=AllActions(seed,level=level);g.policy=pol;r=g.run()
   assert not g.viol.items,g.viol.items
   checked.update(g.viol.n)
   control=F.Force136(seed,level=level);control.policy=pol;rr=control.run()
   assert r==rr and snapshot(g)==snapshot(control),('observer changed the game',seed,level,pol,{k:(r[k],rr[k]) for k in r if r[k]!=rr[k]},snapshot(g)==snapshot(control),{s:(g.board[s],control.board[s]) for s in g.board if g.board[s]!=control.board[s]})
   rows.append(dict(seed=seed,level=level,policy=pol,winner=r['winner']))
# Negative control: add a point of Resistance to a real nonempty Raid step; reject it.
neg=next(w for w in all_witness if w['steps'] and w['steps'][0]['after']['R']<20)
wrong=deepcopy(neg['steps'][0]['after']);wrong['R']+=1
try:check_step(neg['before'],wrong,neg['steps'][0]['step']['rolls'],E.ADJ,E.RA)
except AssertionError:negative_control=True
else:raise AssertionError('negative control escaped')
summary=dict(games=len(rows),raids=len(all_witness),steps=sum(len(w['steps']) for w in all_witness),by_length=dict(collections.Counter(len(w['steps']) for w in all_witness)),negative_control_rejected=negative_control,observer_matches_control=True,other_action_checks=dict(checked),violations=0)
with gzip.open(ROOT/'evidence/raid_witnesses.json.gz','wt') as f:json.dump(all_witness,f)
(ROOT/'evidence/raid_witness_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
