"""Rerun both bots comparing every imported state field, plus ending flags.
This is an audit overlay; no repository files are modified.
"""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import fuzz_v1 as Z

def freeze(v):
 if isinstance(v,dict):return tuple(sorted((k,freeze(x)) for k,x in v.items()))
 if isinstance(v,(list,tuple)):return tuple(freeze(x) for x in v)
 if isinstance(v,set):return tuple(sorted(v))
 return v
FIELDS=Z.STATE+('ended','winner','deck_pos')
Z.public=lambda g:tuple((k,freeze(getattr(g,k))) for k in FIELDS)
Z.describe=lambda a,b:[(k,getattr(a,k),getattr(b,k)) for k in FIELDS if freeze(getattr(a,k))!=freeze(getattr(b,k))]
counts,kinds,found=Z.run(12000,240000)
out=dict(fields=FIELDS,first_seed=240000,counts=dict(counts),kinds=[(str(k),v) for k,v in kinds.items()],examples=found)
(ROOT/'evidence/fuzz_complete_state.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
print(json.dumps(out,indent=2,default=str))
assert not counts['differences'] and not counts['exception']
