"""Confirm the stale flowchart footer in both source and delivered PDFs."""
from pathlib import Path
import sys,json
from copy import deepcopy
import fitz
ROOT=Path(__file__).resolve().parent;REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_595f409'
CODE=REPO/'force136_v1/code';PR=REPO/'force136_v1/print';sys.path.insert(0,str(CODE))
import force136_v1 as F
fx=json.loads((CODE/'fixtures/audit_33745a6/F5_event_box_pass.json').read_text());g=F.Force136(fx['seed'],level=fx['level'])
for k,v in fx.items():setattr(g,k,{int(a):b for a,b in v.items()} if k=='cap' else set(v) if k=='removed_intel' else deepcopy(v))
g.event=1;g.directive=F.DECK[0];plan=g.choose(['Event','Op & SA'])
assert plan['op']=='PASS' and plan['box']=='Event'
source=(PR/'turn_flow.svg').read_text();assert 'Never the Event box.' in source
pages=[]
for stem in ('Rules','Print_and_Play'):
 d=fitz.open(PR/f'Force_136_v1_{stem}.pdf');t=d[1].get_text()
 assert 'Never the Event box.' in t and 'even if that is the Event box' in t
 pages.append(dict(pdf=f'Force_136_v1_{stem}.pdf',page=2,stale_footer=True,correct_prose_also_present=True))
rules=(PR/'Force_136_v1_Rules.md').read_text();assert 'before every move' in rules
look=(CODE/'lookahead.py').read_text();assert "if 'B' in self.chosen:" in look
out=dict(flowchart=dict(seed=fx['seed'],event=1,free=['Event','Op & SA'],plan=plan,source='force136_v1/print/turn_flow.svg:41',observed='Never the Event box.',expected='Never execute the Event.',pdfs=pages),lookahead_wording=dict(source='force136_v1/print/Force_136_v1_Rules.md:161',observed='before every move',expected='when Japan acts first on a card',implementation='force136_v1/code/lookahead.py:13'))
(ROOT/'evidence/paper_probes.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
