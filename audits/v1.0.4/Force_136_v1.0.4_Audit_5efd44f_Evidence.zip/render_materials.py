from pathlib import Path
import fitz,json
from PIL import Image,ImageOps,ImageDraw
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'force136_review_5efd44f/force136_v1/print'
for name in ('Rules','Reference','Cards','Record_Sheet','Sample_Game','Sim_Report'):
 doc=fitz.open(SRC/f'Force_136_v1_{name}.pdf'); thumbs=[]
 (ROOT/f'{name}_text.txt').write_text('\n\n'.join(f'PAGE {i+1}\n'+p.get_text(sort=True) for i,p in enumerate(doc)))
 for i,p in enumerate(doc):
  pix=p.get_pixmap(matrix=fitz.Matrix(1.6,1.6)); fn=ROOT/f'rendered/{name}_{i+1}.png';pix.save(fn)
  im=Image.open(fn).convert('RGB');im.thumbnail((430,590));box=Image.new('RGB',(450,620),'white');box.paste(im,((450-im.width)//2,20));ImageDraw.Draw(box).text((10,600),f'{name} {i+1}',fill='black');thumbs.append(box)
 sheet=Image.new('RGB',(450*min(3,len(thumbs)),620*((len(thumbs)+2)//3)), '#aaa')
 for i,im in enumerate(thumbs):sheet.paste(im,((i%3)*450,(i//3)*620))
 sheet.save(ROOT/f'rendered/{name}_contact.png')
print('Rendered all shipped pages')
