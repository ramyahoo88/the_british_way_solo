"""Independent regressions and nearby controls for the v1.0.4 response.
Run with Python 3 and a repository path. No production file is edited.
"""
from pathlib import Path
from copy import deepcopy
from contextlib import contextmanager
import sys,json,random,gzip
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_5efd44f'
sys.path.insert(0,str(REPO/'force136_v1/code'))
import engine as E,force136_v1 as F,legality_v1 as L,fuzz_v1 as Z,lookahead as A
rows=[]
def record(name,**kw):
    rows.append(dict(name=name,**kw));print(name,{k:v for k,v in kw.items() if k!='before'},flush=True)
@contextmanager
def die(value):
    original=E.Game.die
    E.Game.die=lambda self,tag,space='':value if tag=='Supply' and not self.preview else original(self,tag,space)
    try:yield
    finally:E.Game.die=original
def empty(cls=L.Checked,seed=5954001):
    g=cls(seed);g.board=E.new_board();g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
    g.board['Perak'].update(force136=1,camp=True,red_u=1);return g
class FailedConversion(L.Checked):
    def supply(self):
        def wrong(g):
            n=F.Force136.supply(g);assert n==0
            g.board['Perak'].update(camp=False,cache=True);return 1
        return self._run('SUPPLY',wrong,self)
class KeepOpp(L.Checked):
    def supply(self):
        def wrong(g):
            n=F.Force136.supply(g);g.board['Perak']['opposition']=True;return n
        return self._run('SUPPLY',wrong,self)
for value in (1,2,3,6):
    g=empty();g.cap[8]='S';g.invariants()
    with die(value):n=g.supply()
    assert n==int(value>=3) and g.board['Perak']['cache']==(value>=3) and not g.viol.items
    record(f'J8 legal die {value}',cache=g.board['Perak']['cache'],violations=0)
with die(1):
    g=empty(FailedConversion);g.cap[8]='S';before=L.snap(g);g.supply()
assert len(g.viol.items)==1 and 'rolled 1' in g.viol.items[0]['problem']
record('V1 failed-J8 conversion rejected',seed=g.seed,die=1,problem=g.viol.items[0]['problem'],before=before)
for j8,value in ((False,3),(True,1),(True,3)):
    for cls,want in ((L.Checked,False),(KeepOpp,True)):
        g=empty(cls,5954002);g.cap[27]='S';g.board['Perak']['opposition']=True
        if j8:g.cap[8]='S'
        with die(value):g.supply()
        assert bool(g.viol.items)==want
        assert g.board['Perak']['opposition']==want
        record('J27 selected-space removal',with_J8=j8,die=value,mutant=want,rejected=bool(g.viol.items))
g=empty();g.cap[27]='S';g.board['Kedah']['opposition']=True
g.supply();assert not g.viol.items and g.board['Kedah']['opposition']
record('J27 leaves unselected Opposition alone',violations=0)

fx=json.loads((REPO/'force136_v1/code/fixtures/audit_33745a6/F5_event_box_pass.json').read_text())
def pass_position(event):
    g=L.Checked(fx['seed'],level=fx['level'])
    for k,v in fx.items():setattr(g,k,{int(a):b for a,b in v.items()} if k=='cap' else set(v) if k=='removed_intel' else deepcopy(v))
    g.event=event;g.dqueue=[F.DECK[0]];g.invariants();return g
for event in (1,6,9):
    g=pass_position(event);g.bot_turn(['Event','Op & SA'])
    assert g.last_plan['op']=='PASS' and g.last_plan['box']=='Event'
    assert bool(g.viol.items)==(event in (6,9))
    ctl=pass_position(event);ctl.bot_turn(Z.offer({'event':event},['Event','Op & SA']))
    assert not ctl.viol.items and ctl.last_plan['box']==('Event' if event==1 else 'Op & SA')
    record(f'Event-box Pass J{event}',seed=fx['seed'],invalid_offer_rejected=bool(g.viol.items),normal_offer_box=ctl.last_plan['box'])

# Each field the fuzzer promises to compare is perturbed in isolation.
st=Z.random_state(random.Random(5954003));a=Z.make(F.Force136,5954003,'agent',st)
for key in Z.COMPARE:
    b=Z.make(F.Force136,5954003,'agent',st)
    old=deepcopy(getattr(b,key))
    if key=='board':b.board['Perak']['red_u']+=1
    elif isinstance(old,dict):
        value=deepcopy(old)
        if key=='cap':value[22]='U' if value.get(22)!='U' else 'S'
        elif key=='chosen':value['B']='Limited'
        else:value[next(iter(value))]+=1
        setattr(b,key,value)
    elif isinstance(old,set):setattr(b,key,old^{'Perak'})
    elif isinstance(old,bool):setattr(b,key,not old)
    elif isinstance(old,int):setattr(b,key,old+1)
    else:setattr(b,key,'test-difference')
    assert Z.public(a)!=Z.public(b),key
    assert Z.describe(a,b),key
record('V2 all declared state fields detect isolated mutations',fields=list(Z.COMPARE),count=len(Z.COMPARE))

# Simple Raid witnesses independent of bot choice code. Every source is Perak;
# the destination sequence itself is the test, and no optional action is used.
def raid_case(destinations,zipper=20):
    g=empty();g.board['Perak'].update(camp=False,cache=True,red_u=5);g.zipper=zipper
    if zipper>=18:g.track_cache=0
    g.invariants();a=L.snap(g);steps=[]
    for d in destinations:
        g.board['Perak']['red_u']-=1;g.board[d]['red_u']+=1
        steps.append((deepcopy(g.board),dict(g.sabotage),g.resistance))
    return a,L.snap(g),steps
def check_expected(name,a,b,steps,reject):
    try:L.check_raid(a,b,steps)
    except L.Bad as e:
        assert reject,(name,str(e));problem=str(e)
    else:assert not reject,name;problem=None
    record(name,rejected=reject,problem=problem)
check_expected('Raid two destinations below 20',*raid_case(['Kedah','Pahang'],18),False)
check_expected('Raid three destinations at 20',*raid_case(['Kedah','Pahang','Kelantan']),False)
check_expected('Raid third destination below 20',*raid_case(['Kedah','Pahang','Kelantan'],18),True)
check_expected('Raid repeated destination',*raid_case(['Kedah','Pahang','Kedah']),True)
a,b,steps=raid_case(['Kedah']);b['R']+=1;steps[-1]=(steps[-1][0],steps[-1][1],b['R'])
check_expected('Raid unearned Resistance',a,b,steps,True)
a,b,steps=raid_case(['Kedah']);a['board']['Perak']['cache']=False
check_expected('Raid source without Cache',a,b,steps,True)
a,b,steps=raid_case(['Johore'])
check_expected('Raid nonadjacent destination',a,b,steps,True)

# The lookahead must propagate a preview failure, restore its policy, and leave
# the real position untouched. When Britain has acted, there is no reply preview.
class BrokenPreview(A.LookGame):
    def bot_turn(self,free):raise RuntimeError('deliberate audit preview failure')
g=BrokenPreview(5954004);g.policy='lookc';g.event=1;before=Z.public(g)
try:g.japan_turn(list(E.BOXES))
except RuntimeError as e:assert str(e)=='deliberate audit preview failure'
else:raise AssertionError('preview error swallowed')
assert g.policy=='lookc' and Z.public(g)==before
record('Lookahead preview failure propagates',seed=g.seed,real_position_unchanged=True,policy_restored=True)
g.chosen={'B':'Limited'};g.japan_turn(['Event','Op & SA'])
assert g.policy=='lookc' and 'J' in g.chosen
record('Lookahead acts second without simulating another British turn',status='pass')

(ROOT/'evidence/regression_checks.json').write_text(json.dumps(rows,indent=2,default=lambda x:sorted(x) if isinstance(x,set) else str(x))+'\n')
print(len(rows),'regression/control groups passed')
