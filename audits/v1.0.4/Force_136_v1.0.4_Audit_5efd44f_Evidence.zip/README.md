# Force 136 v1.0.4 review evidence

Review date: 21 November 2026. Repository: `ramyahoo88/the_british_way_solo`.
Reviewed branch: `claude-force136`, commit `5efd44f34a64625f4b627c832d038a2d85566780`.
Comparison commit: `595f409ccae43f795f7fbdc38878f07f7967682a`.

Verdict: all four findings from the prior review are resolved; no new material defect confirmed. This evidence accompanies `Force_136_v1.0.4_Reaudit_5efd44f.md` and its PDF. The report distinguishes fresh tests from prior evidence carried forward because the bot/engine files are unchanged.

## Run the checks

Use Python 3.11 or later. The simulations and focused tests use only the standard library. PDF inspection needs PyMuPDF (`fitz`); contact sheets also need Pillow; rebuilding the audit PDF needs ReportLab and DejaVu fonts. These are audit dependencies, not requirements for playing the paper bot.

Unpack this evidence directory alongside two repository checkouts named `force136_review_5efd44f` and `force136_review_595f409`, at the respective commits above. Most scripts alternatively accept the reviewed repository path as their first argument. `lookahead_compare.py` uses both named sibling directories. `render_materials.py` uses the named current sibling directory. No production source file is modified by the audit scripts. The repository's own `check_exit_status.py` can leave untracked result JSON files in its code folder.

Run from the unpacked evidence directory:

```sh
python3 regression_checks.py /path/to/reviewed/repository
python3 boundary_checks.py /path/to/reviewed/repository
python3 run_suite.py /path/to/reviewed/repository
python3 lookahead_compare.py
```

`run_suite.py` runs ten commands with at most three concurrent jobs, saves command/exit/time receipts and stdout/stderr, and returns nonzero if any command fails. The legality runs use the author's published seeds. The two differential fuzz blocks use fresh seeds 360000–371999 and 380000–391999. A run compares six sampled bot-turn offers and five between-turn effects per random position, not all possible cards/offers on every position.

To regenerate and verify the delivered example, run the following from `evidence/sample/`, replacing the source paths with the pinned checkout:

```sh
python3 /path/to/reviewed/repository/force136_v1/code/sample_game.py 20005 adaptive
python3 /path/to/reviewed/repository/force136_v1/code/sample_md.py 20005 adaptive sample.md
```

Then run from the evidence directory:

```sh
python3 extended_checks.py /path/to/reviewed/repository
python3 check_package.py /path/to/reviewed/repository
python3 release_checks.py /path/to/reviewed/repository
```

`extended_checks.py` recomputes the example's scores independently, records real dice/full logs, checks hidden-information independence and preview purity, tests all railway masks, and performs an explicitly limited Event execution/conservation sweep. `release_checks.py` checks the sample Markdown byte for byte, the PDF corrections, and unchanged core-file hashes against the previous commit, so the checkout must contain both Git commit objects.

Optional presentation scripts:

```sh
python3 render_materials.py
python3 build_report.py
```

Create `rendered/` before rendering. Publisher artwork and the official rulebook are intentionally absent. Source identifiers and the rules PDF checksum are in `SOURCE_PIN.json`; all archive members except the checksum manifest itself are covered by `AUDIT_MANIFEST_SHA256.json`.

## Important receipts

- `evidence/regression_checks.json`: exact prior reproductions, legal neighboring cases, 20 isolated state-field mutations and the deliberate lookahead exception.
- `evidence/suite.json`: all ten commands, durations and exit codes.
- `evidence/legality_games/` and `evidence/legality_fuzz/`: full counters and empty violation lists.
- `evidence/legality_totals.json`: aggregation without counting TURN counters twice.
- `evidence/fuzz_fresh_a/` and `evidence/fuzz_fresh_b/`: fresh position comparisons.
- `evidence/lookahead_summary.json` and both per-game JSONs: 256 old/new wide-search pairs, all complete results identical.
- `evidence/sample/`, `evidence/sample_full_trace.json.gz` and `evidence/extended_checks.json`: rebuilt example, actual dice, scoring and limited additional checks.
- `evidence/package_checks.json` and `evidence/release_checks.json`: cards, combined PDF, footer/page numbers, version/source hashes and the 224-entry source manifest.

No physical table session, printer test or full browser PDF rebuild was performed. The release is a paper bot, not an interactive app with Save/Undo controls. The full 30,000-game balance study was not rerun; the unchanged core hashes and stored-table verification support carrying its numbers forward. The wide-lookahead comparison separately exercises the only changed opponent execution path.
