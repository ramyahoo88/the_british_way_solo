"""Compare old/new wide lookahead game-for-game on the published holdout.
Uses separate interpreters to avoid cross-loading engine versions.
"""
from pathlib import Path
import sys,subprocess,json,time,concurrent.futures
ROOT=Path(__file__).resolve().parent
if len(sys.argv)>1 and sys.argv[1]=='worker':
    repo=Path(sys.argv[2]);sys.path.insert(0,str(repo/'force136_v1/code'))
    import lookahead
    class Wide(lookahead.LookGame):K=16;SAMPLES=4
    rows=[]
    for level in ('agent','mastermind'):
        for seed in range(20000,20128):
            g=Wide(seed,level=level);g.policy='lookc';r=g.run()
            rows.append(dict(seed=seed,level=level,result=r))
    Path(sys.argv[3]).write_text(json.dumps(rows,indent=1)+'\n')
    print('completed',len(rows),flush=True)
else:
    def job(ver):
        out=ROOT/f'evidence/lookahead_{ver}.json';repo=ROOT.parent/f'force136_review_{ver}'
        t=time.time();p=subprocess.run([sys.executable,__file__,'worker',str(repo),str(out)],capture_output=True,text=True)
        (ROOT/f'evidence/lookahead_{ver}.log').write_text(p.stdout+p.stderr)
        assert p.returncode==0,(ver,p.stderr)
        return ver,round(time.time()-t,2)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:times=dict(pool.map(job,('595f409','5efd44f')))
    a=json.loads((ROOT/'evidence/lookahead_595f409.json').read_text());b=json.loads((ROOT/'evidence/lookahead_5efd44f.json').read_text())
    assert a==b
    summary={}
    for level in ('agent','mastermind'):
        rs=[r['result'] for r in b if r['level']==level]
        summary[level]=dict(games=len(rs),wins=sum(r['winner']=='Force 136' for r in rs),mean_R=sum(r['final_resistance'] for r in rs)/len(rs))
    out=dict(paired_games=len(a),executions=len(a)+len(b),identical_complete_results=True,exceptions=0,seconds=times,levels=summary)
    (ROOT/'evidence/lookahead_summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
