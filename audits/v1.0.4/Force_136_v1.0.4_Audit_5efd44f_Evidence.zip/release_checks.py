"""Check delivered print fixes and hash the unchanged simulation core."""
from pathlib import Path
import sys,json,hashlib,subprocess,re
import fitz
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_5efd44f'
old='595f409ccae43f795f7fbdc38878f07f7967682a';new='5efd44f34a64625f4b627c832d038a2d85566780'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==new
paths=['force136_v1/code/'+f for f in ('engine.py','expert.py','force136_v1.py','force136.py')]
paths+=subprocess.check_output(['git','ls-files','force136_v1/code/cleanroom/*.py'],cwd=REPO,text=True).splitlines()
paths+=['force136_v1/print/cards.json']
hashes={}
for p in paths:
    data=(REPO/p).read_bytes();prior=subprocess.check_output(['git','show',f'{old}:{p}'],cwd=REPO)
    assert data==prior,p;hashes[p]=hashlib.sha256(data).hexdigest()
pr=REPO/'force136_v1/print'
rules=fitz.open(pr/'Force_136_v1_Rules.pdf');flow=rules[1].get_text()
assert 'Never execute the Event.' in flow and 'Never the Event box.' not in flow
assert 'even if that is the Event box' in flow
for i,p in enumerate(rules):assert f'Force 136 rules · page {i+1}' in p.get_text()
allrules=' '.join(' '.join(p.get_text().split()) for p in rules)
assert 'whenever it acts first on a card' in allrules and 'before every move' not in allrules
assert 'Printing:' in allrules and '100%' in allrules and 'two-sided' in allrules
sample=fitz.open(pr/'Force_136_v1_Sample_Game.pdf');assert len(sample)==3
assert (ROOT/'evidence/sample/sample.md').read_bytes()==(pr/'Force_136_v1_Sample_Game.md').read_bytes()
st=' '.join(' '.join(p.get_text().split()) for p in sample)
for phrase in ('icon: Kill Traitors','Sweep + Eliminate','capability J22 now in play','Position after the Reset','Resistance 18 → 20','Resources 0→7'):
    assert phrase in st,phrase
for doc in pr.glob('*.pdf'):
    for page in fitz.open(doc):
        assert all(0<=b[0]<=b[2]<=page.rect.width and 0<=b[1]<=b[3]<=page.rect.height for b in page.get_text('blocks')),(doc.name,page.number)
for p in ('README.md','PLAYTEST.md','print/Force_136_v1_Rules.md','print/Force_136_v1_Sim_Report.md'):
    s=(REPO/'force136_v1'/p).read_text()
    assert 'whenever it acts first on a card' in s or 'whenever Japan acts first on a card' in s,p
out=dict(reviewed_commit=new,previous_commit=old,unchanged_core_sha256=hashes,core_files=len(hashes),
         corrected_flowchart_pdf_page=2,numbered_rules_pages=len(rules),sample_pages=len(sample),sample_new_content_present=True,sample_markdown_regenerates_exactly=True,
         all_pdf_text_blocks_within_page=True,lookahead_wording_corrected=True)
(ROOT/'evidence/release_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
