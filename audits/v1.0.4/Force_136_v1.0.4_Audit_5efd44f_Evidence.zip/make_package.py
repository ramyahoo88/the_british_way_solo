"""Build and validate the review evidence ZIP, excluding publisher materials."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
base='Force_136_v1.0.4_Reaudit_5efd44f'
files=[ROOT/'README.md',ROOT/'SOURCE_PIN.json',ROOT/(base+'.md'),ROOT/(base+'.pdf')]
files+=sorted(ROOT.glob('*.py'))
files+=sorted(p for p in (ROOT/'evidence').rglob('*') if p.is_file())
manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
mp=ROOT/'AUDIT_MANIFEST_SHA256.json';mp.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');files.append(mp)
out=ROOT/'Force_136_v1.0.4_Audit_5efd44f_Evidence.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,str(p.relative_to(ROOT)))
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(manifest)|{'AUDIT_MANIFEST_SHA256.json'}
    for name,sha in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha,name
print(json.dumps(dict(archive=out.name,files=len(files),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest()),indent=2))
