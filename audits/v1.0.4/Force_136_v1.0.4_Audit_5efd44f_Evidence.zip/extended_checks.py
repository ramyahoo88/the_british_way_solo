"""Public-information, trace, Event smoke, and independent railway checks.
The Event sweep proves execution/conservation only, not every targeting rule.
"""
from pathlib import Path
from copy import deepcopy
import sys,json,gzip,random,itertools
ROOT=Path(__file__).resolve().parent;REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_review_5efd44f';CODE=REPO/'force136_v1/code'
sys.path.insert(0,str(CODE))
import engine as E,force136_v1 as F

class Recorder(F.Force136):
    quiet=False
    def __init__(self,*a,**kw):
        super().__init__(*a,**kw);self.audit_rolls=[];self.before_turns=[]
    def bot_turn(self,free):
        if not self.preview:self.before_turns.append((state(self),list(free)))
        super().bot_turn(free)
        if not self.preview:self.record('British turn',deepcopy(self.last_plan))
    def die(self,tag,space=''):
        d=super().die(tag,space)
        if not self.preview:self.audit_rolls.append(dict(draw=self.draw,tag=tag,space=space,result=d))
        return d
def state(g):
    return {k:deepcopy(v) for k,v in g.__dict__.items() if k not in ('log','metrics','decisions','audit_rolls','before_turns')}
def from_state(st):
    g=F.Force136(st['seed'],level=st['level'])
    for k,v in st.items():setattr(g,k,deepcopy(v))
    return g

# Full independent trace of the actual delivered example: includes icon resolution,
# all between-round phases, actual dice, and the J9 early ending now included in the handout.
g=Recorder(20005);g.policy='adaptive';setup=deepcopy(g.board);result=g.run()
scores=[]
for r in g.log:
    if r['kind'] not in ('Final scoring','Nonfinal scoring'):continue
    b=r['detail']['score_board'];d=r['detail'];R0=d['resistance_before']
    positive=sum(v['intel'] or 0 for v in b.values())+sum(bool(v['cache']) for v in b.values())
    positive+=sum(v['red_u']+v['red_a']+v['blue_u']+v['blue_a']>v['troops']+v['police'] for v in b.values())
    negative=d['resources_used']//4+sum(v['population'] for v in b.values() if not v['opposition'])//5+sum(v['police']>0 for v in b.values())//3
    assert max(0,min(20,R0+positive-negative))==r['resistance']
    scores.append(dict(draw=r['draw'],event=r['event'],phase=r['kind'],before=R0,positive=positive,negative=negative,after=r['resistance']))
assert [(r['before'],r['after']) for r in scores]==[(2,10),(11,17),(18,20)]
assert result['ending']=='J9' and g.draw==16 and result['winner']=='Force 136'
with gzip.open(ROOT/'evidence/sample_full_trace.json.gz','wt') as f:json.dump(dict(setup=setup,result=result,rolls=g.audit_rolls,log=g.log,scores=scores),f)
stored=json.loads((CODE/'results/sample_20005_adaptive.json').read_text())
rerun=json.loads((ROOT/'evidence/sample/sample_20005_adaptive.json').read_text())
assert stored==rerun

# Eight extra seeded games supply early/middle/late visible states; no inference
# relies on samples being uniformly distributed over all legal positions.
states=list(g.before_turns)
for seed in range(5954600,5954608):
    q=Recorder(seed);q.policy='counter';q.run();states.extend(q.before_turns)
sample=[states[i*len(states)//32][0] for i in range(32)]
secret_checks=0;pure=0
for st in sample:
    for card in F.DECK:
        for free in (E.BOXES,['Event','Op & SA'],['Limited','Event'],['Limited','Op & SA']):
            a=from_state(st);a.directive=card;before=state(a)
            pa=a.choose(free);assert state(a)==before;pure+=1
            b=from_state(st);b.directive=card
            b.secret={s:2-a.secret.get(s,1) for s in E.ORDER[:9]}
            # Only future portions change; visible current Event, deck length,
            # current Directive, and played information are preserved.
            tail=list(reversed(b.deck[b.deck_pos:]));b.deck=b.deck[:b.deck_pos]+tail
            b.dqueue=list(reversed(b.dqueue));b.seed+=987654321
            pb=b.choose(free);assert pa==pb,(st['seed'],st['draw'],card['id'],free,pa,pb)
            secret_checks+=1

# Railway adjacency transcribed as a graph of touching rail markers from the
# printed map; independent of engine.EDGES and independent graph traversal.
keys=['Thailand-Kedah *','Thailand-Perak','Thailand-Kelantan *','Perak-Kelantan','Perak-Pahang-Selangor','Negri Sembilan-Pahang','Negri Sembilan-Johore *','Pahang-Johore *']
connections=[(0,1),(1,2),(1,3),(2,3),(3,4),(4,5),(5,6),(5,7),(6,7)]
ec_touch={'Northern EC':{3,4},'Southern EC':{5,6,7}};stars={0,2,6,7}
for mask in range(256):
    blocked={i for i in range(8) if mask&(1<<i)};want={}
    for ec,starts in ec_touch.items():
        seen=starts-blocked;todo=list(seen)
        while todo:
            i=todo.pop()
            for a,b in connections:
                j=b if a==i else a if b==i else None
                if j is not None and j not in blocked and j not in seen:seen.add(j);todo.append(j)
        want[ec]=len(seen&stars)
    _,got=E.live_and_yield({k:int(i in blocked) for i,k in enumerate(keys)})
    assert want==got,(mask,want,got)

# Every Event, both choices when present, across setup and two actual mid/late
# states; plus all 4 icons across these states. Checks operation invariants only.
event_runs=[]
starts=[state(F.Force136(5954700)),sample[len(sample)//2],sample[-1]]
for n,st in enumerate(starts):
    for j in range(1,33):
        for side in (('M',) if j in (6,9) else ('U',) if j==17 else ('U','S')):
            q=from_state(st)
            try:
                if side=='M':q.mandatory(j)
                else:q.execute_event(j,side)
                q.invariants();err=None
            except Exception as e:err=repr(e)
            event_runs.append(dict(position=n,event=j,side=side,error=err))
    for j in (1,5,7,13):
        q=from_state(st);q.icon(j);q.invariants()
assert not any(x['error'] for x in event_runs),[r for r in event_runs if r['error']]

out=dict(sample_seed=20005,sample_result=result,sample_scores=scores,sample_stored_json_matches=True,
         captured_games=9,captured_bot_positions=len(states),sampled_visible_positions=32,
         hidden_information_comparisons=secret_checks,pure_preview_checks=pure,
         independent_railway_masks=256,event_executions=len(event_runs),event_errors=0,
         event_scope='Execution/conservation smoke test; Event target choices are not independently certified.')
(ROOT/'evidence/extended_checks.json').write_text(json.dumps(out,indent=2)+'\n')
(ROOT/'evidence/event_smoke.json').write_text(json.dumps(event_runs,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='sample_result'},indent=2))
