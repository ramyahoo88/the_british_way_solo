"""Independent recount of Claude's compressed rows and printed per-policy results."""
from pathlib import Path
import gzip,csv,json,random,statistics,collections,re
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'claude_force136_v101_review/force136_v1'
POLS=['extraction','hunting','repair','adaptive','counter','mixed']
LEVELS=['recruit','agent','veteran','legend','mastermind']
def rows(name):
    with gzip.open(SRC/'code/results'/name,'rt') as f:rs=list(csv.DictReader(f))
    for r in rs:r['seed']=int(r['seed']);r['final_resistance']=int(r['final_resistance'])
    assert len(rs)==len({(r['seed'],r['policy'],r['level']) for r in rs})
    return rs
old=rows('results_fresh_v1.0.csv.gz');new=rows('results_fresh_v101.csv.gz')
def summary(rs):
    result={}
    for l in LEVELS:
        rr=[r for r in rs if r['level']==l]
        if not rr:continue
        result[l]=dict(n=len(rr),wins=sum(r['winner']=='Force 136' for r in rr),
            rate=statistics.mean(r['winner']=='Force 136' for r in rr),
            mpaja=sum(r['winner']=='MPAJA' for r in rr),mean_R=statistics.mean(r['final_resistance'] for r in rr),
            by_policy={p:statistics.mean(r['winner']=='Force 136' for r in rr if r['policy']==p) for p in POLS})
    return result
old0=[r for r in old if r['seed']<1000];new0=new
out=dict(old_total_rows=len(old),new_total_rows=len(new),old_all=summary(old),old_0_999=summary(old0),v101=summary(new))
stored=json.loads((SRC/'code/results/fresh_v101_summary.json').read_text())
for l,s in out['v101'].items():
    assert s['n']==stored[l]['n'] and round(s['rate'],4)==stored[l]['win']
    assert round(s['mean_R'],2)==stored[l]['R']
    assert s['by_policy']==stored[l]['per']
base={(r['seed'],r['policy'],r['level']):r for r in old0}
after={(r['seed'],r['policy'],r['level']):r for r in new}
assert base.keys()==after.keys()
paired={}
for l in LEVELS:
    diffs=[];turnarounds=collections.Counter()
    for s in range(1000):
        delta=[]
        for p in POLS:
            a=base[s,p,l]['winner']=='Force 136';b=after[s,p,l]['winner']=='Force 136'
            delta.append(int(b)-int(a));turnarounds[(a,b)]+=1
        diffs.append(statistics.mean(delta))
    rng=random.Random(101006);bs=sorted(statistics.mean(rng.choices(diffs,k=1000)) for _ in range(10000))
    paired[l]=dict(delta=statistics.mean(diffs),seed_cluster_95CI=[bs[250],bs[9750]],
        improved=turnarounds[False,True],worsened=turnarounds[True,False],
        policy_deltas={p:out['v101'][l]['by_policy'][p]-out['old_0_999'][l]['by_policy'][p] for p in POLS})
out['paired_refresh']=paired
agent=[r for r in old if r['level']=='agent']
out['old_agent_blocks']={a:summary([r for r in agent if a<=r['seed']<a+1000])['agent'] for a in [0,30000,50000,60000,90000]}
by=collections.defaultdict(list)
for r in agent:by[r['seed']].append(r['winner']=='Force 136')
assert len(by)==5000 and all(len(v)==6 for v in by.values())
rates=[sum(v)/6 for v in by.values()];rng=random.Random(101007)
bs=sorted(statistics.mean(rng.choices(rates,k=len(rates))) for _ in range(4000))
out['old_agent_seed_cluster_95CI']=[bs[100],bs[3900]]
threshold=618/1152
subsets=[statistics.mean(rng.sample(rates,192)) for _ in range(20000)]
out['empirical_low_window_frequency']=dict(replicates=20000,sampling='192 distinct seeds from observed 5,000-seed empirical population',
    threshold=threshold,probability=sum(x<=threshold for x in subsets)/len(subsets))
# Compare the report's explicitly labeled fresh-policy table with the v1.0.1 rows.
md=(SRC/'print/Force_136_v1_Sim_Report.md').read_text();report=[]
for p in POLS:
    line=next(x for x in md.splitlines() if x.startswith('| '+p+' |'))
    cells=[c.strip() for c in line.strip('|').split('|')]
    printed=[int(x.rstrip('%')) for x in cells[1:6]]
    expected=[round(out['v101'][l]['by_policy'][p]*100) for l in LEVELS]
    old_expected=[round(out['old_0_999'][l]['by_policy'][p]*100) for l in LEVELS]
    report.append(dict(policy=p,printed=printed,expected_v101=expected,expected_v10=old_expected))
assert any(r['printed']!=r['expected_v101'] for r in report)
out['per_policy_table_comparison']=report
# Confirm that the earlier GPT windows are present, correctly reproduced, and overlap the large baseline.
window=json.loads((ROOT/'evidence/previous_gpt_windows.json').read_text())
large={(r['seed'],r['policy']):r for r in agent}
assert len(window)==1152
for r in window:
    z=large[r['seed'],r['pol']]
    assert (z['winner'],z['final_resistance'])==(r['winner'],r['R'])
out['gpt_window_rows_reproduced_in_large_baseline']=len(window)
(ROOT/'evidence/recount.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['old_agent_blocks']},indent=2))
