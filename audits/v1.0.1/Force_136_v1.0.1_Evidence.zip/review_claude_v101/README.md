# Force 136 v1.0.1 re-audit evidence

Reviewed source: https://github.com/ramyahoo88/the_british_way_solo

Pin: `fe57c0faea60bc913e1f7c859963059d92d9aa7e`, branch `claude-force136`.

This is an incremental review of Claude's response to the v1.0 audit. The production source was not edited. The ZIP contains this report's Markdown, independent analysis and new experiment rows; the reviewed repository supplies Claude's original source/data/PDFs.

## Layout and focused checks

Extract the ZIP so that `review_claude_v101` and the source checkout are siblings:

```sh
git clone --branch claude-force136 https://github.com/ramyahoo88/the_british_way_solo.git claude_force136_v101_review
git -C claude_force136_v101_review checkout fe57c0faea60bc913e1f7c859963059d92d9aa7e
cd review_claude_v101
python3 recount.py
python3 baseline_control.py
python3 nearby_refresh_checks.py
python3 exit_status_probe.py
python3 zipper_oracle_probe.py
python3 check_package.py
```

Python 3.11+ standard library suffices except for `check_package.py` (PyMuPDF). The report PDF renderer also needs ReportLab and DejaVu system fonts.

`exit_status_probe.py` deliberately introduces a scoring error in a subprocess and asserts that the reviewed verifier still returns status 0 despite detecting it. A successful probe reproduces the command-status defect, not correct scoring. It runs in `evidence/exit_probe` so its deliberate failures do not replace the normal suite's results.

`zipper_oracle_probe.py` temporarily changes only in-memory shared engine behavior. It demonstrates a limit of the independent Resistance/winner oracle; that error is not in the production engine. Both probes leave reviewed files unchanged.

`nearby_refresh_checks.py` distinguishes the actual last-resort rule from refresh-first behavior. `baseline_control.py` checks 24 no-refresh outcomes against the stored v1.0 study.

## Larger reruns

Run the following from `review_claude_v101/evidence`, with the reviewed source at the sibling path above:

```sh
python3 ../../claude_force136_v101_review/force136_v1/code/review_fixtures.py
python3 ../../claude_force136_v101_review/force136_v1/code/verify_v1.py 32
python3 ../../claude_force136_v101_review/force136_v1/code/verify_v1.py --mutants 16
python3 ../../claude_force136_v101_review/force136_v1/code/equiv.py 32 recruit,agent,veteran,legend,mastermind
python3 ../../claude_force136_v101_review/force136_v1/code/look_deep.py 20000 128 agent,mastermind lookc 16 4
```

The verified results are supplied as `.txt` logs and `verify_results.json` / `verify_mutants.json`. They match Claude's stored JSON exactly. The old fixtures all pass. The full-state suite comprises 2,496 paired comparisons and the mutation suite 1,440; each comparison executes two implementations. These are not thousands of independent Event deals.

From `review_claude_v101`, run `python3 fresh_pair.py` to regenerate the independent strength experiment: Agent on seeds 120000-120255 and all six Japan policies, with/without the local refresh (3,072 game executions), plus 16 paired seeds at the other four levels (768 more). It writes complete per-game rows and a clustered paired analysis in `evidence/fresh_paired.json`. The baseline only disables the refresh, preserving every other part of the current executor and policy.

## Evidence map

- `Force_136_v1.0.1_Reaudit.md`: conclusions, precise source references and release verdict.
- `recount.json`: all independently aggregated rates, paired refresh gains, empirical window resampling and correct per-policy cells for the stale report table.
- `fresh_paired.json`: untouched-seed paired rows and intervals.
- `previous_gpt_windows.json`: the earlier 1,152 GPT rows, included to make `recount.py` self-contained; do not add them again to the overlapping 30,000-game v1.0 baseline.
- `baseline_control.json`, `nearby_refresh_checks.json`: control and nearby-case witnesses.
- `exit_status_probe.json`, `.txt`, `exit_probe/verify_results.json`: detected scoring failures with successful process status.
- `zipper_oracle_probe.json`: optional oracle-extension witness at seed 20000/counter.
- `package_checks.json`, `pdf_check.json`, `manifest_check.json`: print package and checksum validation.
- `verify_results.json`, `verify_mutants.json`, and rerun `.txt` files: exact suite results.

Files in this evidence map without another directory prefix are under `evidence/`. The bundle contains no publisher rulebook, card artwork or screenshots. Recounting stored results is distinguished from rerunning them throughout the report. All simulation-strength statements remain conditional on this research executor and its opponents.
