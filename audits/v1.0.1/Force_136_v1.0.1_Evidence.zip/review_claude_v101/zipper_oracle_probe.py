"""Optional verifier extension: current oracle does not independently check rule 6.2.5."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_v101_review/force136_v1/code'
sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import verify_v1 as T,engine,force136_v1 as F
original=engine.Game.move_zipper
def frozen_scoring_zipper(self,steps=None,target=None):
    # Deliberately wrong 6.2.5: place Zipper at Delay during Propaganda.
    # Event calls with a relative step still use the original rule.
    return original(self,steps=steps,target=0 if target is not None else None)
engine.Game.move_zipper=frozen_scoring_zipper
try:
    for seed in range(20000,20016):
        result=T.check(seed,'counter','agent')
        trace,final=T.play(F.Force136,seed,'counter','agent')
        witnesses=[]
        for entry in trace.items:
            if entry[0]=='reset':
                tracks=entry[3];R,zipper=tracks[0],tracks[2]
                expected=max(x for x in [0,6,12,18,20] if x<=R)
                if zipper!=expected:witnesses.append(dict(draw=entry[1],R=R,observed_zipper=zipper,expected_zipper=expected))
        if witnesses:
            assert result['cross'] is None and result['oracle']==0
            out=dict(seed=seed,policy='counter',level='agent',cross_failure=result['cross'],oracle_failure_games=result['oracle'],
                mutation='Shared engine always places Zipper at Delay during Propaganda',witnesses=witnesses,
                classification='Optional independent-oracle coverage extension; this mutation is not present in the shipped engine.')
            (ROOT/'evidence/zipper_oracle_probe.json').write_text(json.dumps(out,indent=2)+'\n')
            print(json.dumps(out,indent=2));break
    else:raise AssertionError('No Zipper witness in deterministic search')
finally:engine.Game.move_zipper=original
