"""Verify the new Train fallback's nearby cases, not just the original exhausted fixture."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_v101_review/force136_v1/code'
sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import force136_v1 as F,cleanroom as C
from engine import new_board
def setup(cls):
    g=cls(139031);g.board=new_board()
    g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
    g.board['Perak'].update(red_a=10,force136=1,camp=True,cache=True)
    g.board['Kedah'].update(blue_a=1,force136=1,camp=True)
    g.board['Negri Sembilan'].update(blue_a=1,force136=1,camp=True)
    g.board['Kelantan'].update(blue_a=1,blue_u=1)
    g.resistance=6;g.zipper=6;g.track_cache=1;g.invariants();return g
out=[]
for cls in [F.Force136,C.CleanForce136]:
    g=setup(cls);n=g.train();g.invariants()
    assert n==4
    assert g.board['Kedah']['blue_a']==1 and g.board['Kedah']['blue_u']==1
    assert g.board['Kelantan']['blue_a']==0 and g.board['Kelantan']['blue_u']==1
    assert g.board['Negri Sembilan']['blue_a']==0 and g.board['Negri Sembilan']['blue_u']==1
    assert g.board['Perak']['red_a']==8 and g.board['Perak']['red_u']==2
    out.append(dict(implementation=cls.__name__,train_effects=n,board=g.board))
# A local Underground guerrilla cannot be repeatedly "refreshed" as a useful placement.
g=F.Force136(139032);g.board=new_board()
g.board['Perak'].update(force136=1,camp=True,cache=True,red_u=10)
assert not g.place_one('Perak','red')
(ROOT/'evidence/nearby_refresh_checks.json').write_text(json.dumps(dict(remote_source_before_refresh=out,underground_not_counted_as_refresh=True),indent=2)+'\n')
print('Both implementations use a remote donor before local refresh, preserve its majority, respect the Cache quota, and skip an already Underground local piece.')
