"""Untouched-seed comparison: last-resort refresh against the same bot without it."""
from pathlib import Path
from multiprocessing import Pool
import sys,json,collections,random,statistics
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_v101_review/force136_v1/code'
sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import force136_v1 as F
from engine import cubes
POLS=['extraction','hunting','repair','adaptive','counter','mixed']
class WithoutRefresh(F.Force136):
    def place_one(self,s,c):
        v=self.board[s]
        if self.available(c):v[c+'_u']+=1;return True
        donors=[x for x in F.MAP_ORDER if x!=s and not self.board[x]['force136']
                and (self.board[x][c+'_a'] or self.board[x][c+'_u']) and self.donor_ok(x)]
        if not donors:return False
        x=min(donors,key=lambda x:(not self.board[x][c+'_a'],-cubes(self.board[x]),F.mo(x)))
        field=c+('_a' if self.board[x][c+'_a'] else '_u')
        self.board[x][field]-=1;v[c+'_u']+=1;return True
def one(args):
    seed,pol,level,version=args
    cls=F.Force136 if version=='refresh_last' else WithoutRefresh
    g=cls(seed,level=level);g.policy=pol;r=g.run()
    return dict(seed=seed,policy=pol,level=level,variant=version,
                winner=r['winner'],R=r['final_resistance'],goals={k[2:]:v for k,v in r['metrics'].items() if k.startswith('g_')})
def summarize(rows):
    bylevel={}
    for level in ['recruit','agent','veteran','legend','mastermind']:
        rr=[r for r in rows if r['level']==level]
        if not rr:continue
        table={(r['seed'],r['policy'],r['variant']):r for r in rr}
        seeds=sorted({r['seed'] for r in rr})
        diffs=[statistics.mean(int(table[s,p,'refresh_last']['winner']=='Force 136')-int(table[s,p,'without_refresh']['winner']=='Force 136') for p in POLS) for s in seeds]
        rng=random.Random(101136);boots=sorted(statistics.mean(rng.choices(diffs,k=len(diffs))) for _ in range(10000))
        bylevel[level]=dict(seeds=len(seeds),games_per_variant=len(seeds)*6,
            versions={v:dict(wins=sum(r['winner']=='Force 136' for r in rr if r['variant']==v),
                mean_R=statistics.mean(r['R'] for r in rr if r['variant']==v)) for v in ['without_refresh','refresh_last']},
            win_delta=statistics.mean(diffs),seed_cluster_95CI=[boots[250],boots[9750]],
            by_policy={p:{v:sum(r['winner']=='Force 136' for r in rr if r['policy']==p and r['variant']==v) for v in ['without_refresh','refresh_last']} for p in POLS})
    return bylevel
if __name__=='__main__':
    jobs=[(s,p,'agent',v) for s in range(120000,120256) for p in POLS for v in ['without_refresh','refresh_last']]
    # A small paired check at the other levels, sharing the first sixteen seeds.
    jobs += [(s,p,l,v) for l in ['recruit','veteran','legend','mastermind'] for s in range(120000,120016) for p in POLS for v in ['without_refresh','refresh_last']]
    with Pool(2) as pool:rows=pool.map(one,jobs,chunksize=8)
    out=dict(summary=summarize(rows),rows=rows)
    (ROOT/'evidence/fresh_paired.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out['summary'],indent=2))
