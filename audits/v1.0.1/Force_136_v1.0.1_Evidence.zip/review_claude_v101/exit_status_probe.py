"""A scoring regression is detected in output, but the verifier CLI still exits successfully."""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parent
CODE=ROOT.parent/'claude_force136_v101_review/force136_v1/code'
payload="""
import sys,runpy
sys.path[:0]=[sys.argv[1],sys.argv[1]+'/cleanroom']
import engine
original=engine.score_terms
def doubled_cache(board,resources):
    terms=original(board,resources);terms['caches']*=2;return terms
engine.score_terms=doubled_cache
script=sys.argv[1]+'/verify_v1.py'
sys.argv=[script,'1']
runpy.run_path(script,run_name='__main__')
"""
probe_dir=ROOT/'evidence/exit_probe';probe_dir.mkdir(exist_ok=True)
run=subprocess.run([sys.executable,'-c',payload,str(CODE)],cwd=probe_dir,capture_output=True,text=True)
(ROOT/'evidence/exit_status_probe.txt').write_text(run.stdout+run.stderr)
results=json.loads((probe_dir/'verify_results.json').read_text())
oracle=sum(r['oracle'] for r in results.values())
assert oracle>0 and run.returncode==0
out=dict(exit_code=run.returncode,oracle_failure_games=oracle,
         mutation='Shared engine counts Caches twice during scoring',seeds_per_block=1,
         observed='The verifier reports scoring failures and writes them to JSON but exits with status 0.')
(ROOT/'evidence/exit_status_probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
