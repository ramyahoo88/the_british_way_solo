"""Verify that the no-refresh ablation reproduces a sample of v1.0's stored normal games."""
from pathlib import Path
import gzip,csv,json
from fresh_pair import one,POLS
ROOT=Path(__file__).resolve().parent
source=ROOT.parent/'claude_force136_v101_review/force136_v1/code/results/results_fresh_v1.0.csv.gz'
with gzip.open(source,'rt') as f:old={(int(r['seed']),r['policy']):r for r in csv.DictReader(f) if r['level']=='agent'}
out=[]
for seed in [0,99,500,999]:
    for p in POLS:
        r=one((seed,p,'agent','without_refresh'));ref=old[seed,p]
        assert (r['winner'],r['R'])==(ref['winner'],int(ref['final_resistance']))
        out.append(dict(seed=seed,policy=p,winner=r['winner'],R=r['R']))
(ROOT/'evidence/baseline_control.json').write_text(json.dumps(dict(exact_v10_outcome_matches=len(out),rows=out),indent=2)+'\n')
print('No-refresh control matches all 24 sampled v1.0 outcomes and final Resistance values.')
