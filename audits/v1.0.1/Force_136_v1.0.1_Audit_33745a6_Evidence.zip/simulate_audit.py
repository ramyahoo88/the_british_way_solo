"""Fresh strategy probes and a corrected Event-hog diagnostic, without editing the bot.
Run: python simulate_audit.py [repo]
Two predeclared blocks: 170000-170127 and confirmation 180000-180127.
"""
from pathlib import Path
from copy import deepcopy
from collections import Counter,defaultdict
from multiprocessing import Pool
import sys,json,gzip,time,random,math
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6'
CODE=REPO/'force136_v1/code';sys.path.insert(0,str(CODE))
import engine as E,force136_v1 as F,lookahead

class Study(F.Force136):
    forced_event=False
    def __init__(self,*a,**k):
        super().__init__(*a,**k);self.audit=Counter();self.witness=None;self.phase_scores=[]
    def goal(self,name,full):
        if not self.preview:self.audit['goal_checks']+=1
        return super().goal(name,full)
    def first_sa(self,after,order):
        if not self.preview:self.audit['sa_lists']+=1
        return super().first_sa(after,order)
    def sa_does(self,p,x):
        if not self.preview:self.audit['sa_checks']+=1
        return super().sa_does(p,x)
    def jp_apply(self,p):
        if not self.preview:self.last_jp=deepcopy(p)
        return super().jp_apply(p)
    def japan_turn(self,free):
        offered='Event' in free and self.event not in (6,9)
        if not self.preview:
            self.audit['japan_turns']+=1;self.audit['Event_offered']+=offered
        if self.forced_event and self.policy=='eventhog' and offered:
            p=dict(op='EVENT',box='Event',sa=None);self.chosen['J']='Event';self.jp_apply(p)
        else:super().japan_turn(free)
        if not self.preview:
            self.audit['Event_taken']+=self.chosen['J']=='Event'
            if offered and self.chosen['J']!='Event' and self.witness is None:
                self.witness=dict(seed=self.seed,draw=self.draw,event=self.event,free=free,chosen=self.chosen['J'],plan=self.last_jp)
    def bot_turn(self,free):
        if self.preview:return super().bot_turn(free)
        before=(deepcopy(self.board),dict(self.sabotage),self.resistance,self.resources,self.zipper)
        a=self.audit['goal_checks'];b=self.audit['sa_checks']
        super().bot_turn(free)
        after=(self.board,self.sabotage,self.resistance,self.resources,self.zipper)
        self.audit['bot_turns']+=1;self.audit['no_state_change']+=before==after
        self.audit['max_goal_checks']=max(self.audit['max_goal_checks'],self.audit['goal_checks']-a)
        self.audit['max_sa_checks']=max(self.audit['max_sa_checks'],self.audit['sa_checks']-b)
        self.audit['stacked_F136_end_turns']+=any(v['force136']>1 for v in self.board.values())
    def score_only(self,final=False):
        r=super().score_only(final)
        if not self.preview:self.phase_scores.append(dict(campaign=self.campaign,draw=self.draw,final=final,R=self.resistance,cache=r['caches'],majorities=r['majorities'],zipper=self.zipper))
        return r

class ForcedEvent(Study):forced_event=True
class ForcedTempo(Study):
    def japan_turn(self,free):
        # The advertised policy: take Limited whenever that box is legal.
        return super().japan_turn(['Limited'] if self.policy=='tempo' and 'Limited' in free else free)
class Wide(lookahead.LookMixin,Study):K=16;SAMPLES=4

def one(job):
    seed,policy,level,variant=job
    cls={'baseline':Study,'forced_event':ForcedEvent,'forced_tempo':ForcedTempo,'corner':Study,'wide':Wide}[variant]
    g=cls(seed,level=level,corner=variant=='corner');g.policy=policy;r=g.run()
    return dict(seed=seed,policy=policy,level=level,variant=variant,winner=r['winner'],R=r['final_resistance'],draws=r['draws'],ending=r['ending'],audit=dict(g.audit),goals={k[2:]:v for k,v in g.metrics.items() if k.startswith('g_')},scores=g.phase_scores,witness=g.witness)

def ci(xs,seed=33745):
    rng=random.Random(seed);n=len(xs)
    vals=sorted(sum(xs[rng.randrange(n)] for _ in range(n))/n for _ in range(4000))
    return [vals[100],vals[3899]]

def summarize(rows):
    groups=defaultdict(list)
    for r in rows:groups[(r['variant'],r['level'],r['policy'])].append(r)
    out=[]
    for key,rs in groups.items():
        wins=sum(r['winner']=='Force 136' for r in rs);counts=Counter(r['winner'] for r in rs)
        ag=Counter();goals=Counter()
        for r in rs:ag.update(r['audit']);goals.update(r['goals'])
        for k in ('max_goal_checks','max_sa_checks'):ag[k]=max(r['audit'].get(k,0) for r in rs)
        out.append(dict(variant=key[0],level=key[1],policy=key[2],n=len(rs),winners=dict(counts),win_rate=wins/len(rs),mean_R=sum(r['R'] for r in rs)/len(rs),win_ci=ci([r['winner']=='Force 136' for r in rs]),audit=dict(ag),goals=dict(goals)))
    paired=[]
    base={r['seed']:r for r in rows if r['variant']=='baseline' and r['policy']=='eventhog'}
    mod={r['seed']:r for r in rows if r['variant']=='forced_event'}
    for label,ks in [('development',[s for s in base if 170000<=s<170128]),('confirmation',[s for s in base if 180000<=s<180128]),('combined',list(base))]:
        ds=[int(mod[s]['winner']=='Force 136')-int(base[s]['winner']=='Force 136') for s in ks]
        paired.append(dict(block=label,n=len(ds),delta=sum(ds)/len(ds),ci=ci(ds),base_wins=sum(base[s]['winner']=='Force 136' for s in ks),forced_wins=sum(mod[s]['winner']=='Force 136' for s in ks)))
    # Six regular policies share the seed: aggregate uncertainty by whole seeds.
    blocks=defaultdict(list)
    for r in rows:
        if r['variant']=='baseline' and r['policy'] in ('extraction','hunting','repair','adaptive','counter','mixed'):
            blocks[r['seed']].append(r['winner']=='Force 136')
    regular=dict(n=sum(map(len,blocks.values())),seeds=len(blocks),win_rate=sum(sum(v) for v in blocks.values())/sum(map(len,blocks.values())),seed_cluster_ci=ci([sum(v)/len(v) for v in blocks.values()]))
    return dict(groups=out,eventhog_paired=paired,regular=regular)

if __name__=='__main__':
    policies=('extraction','hunting','repair','adaptive','counter','mixed','brute','tempo','econ','eventhog')
    seeds=list(range(170000,170128))+list(range(180000,180128))
    jobs=[(s,p,'agent','baseline') for s in seeds for p in policies]
    jobs += [(s,'eventhog','agent','forced_event') for s in seeds]
    jobs += [(s,'lookc',l,'wide') for s in list(range(170000,170032))+list(range(180000,180032)) for l in ('agent','mastermind')]
    out=[];start=time.time()
    with Pool(4) as pool:
        for i,row in enumerate(pool.imap_unordered(one,jobs,chunksize=4),1):
            out.append(row)
            if i%256==0:print(i,'/',len(jobs),'games',round(time.time()-start,1),'seconds',flush=True)
    out.sort(key=lambda r:(r['variant'],r['seed'],r['policy'],r['level']))
    with gzip.open(ROOT/'evidence/fresh_games.json.gz','wt') as f:json.dump(out,f)
    summary=summarize(out);summary['executions']=len(out);summary['seconds']=time.time()-start
    (ROOT/'evidence/fresh_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary['regular']),flush=True)
    print('DONE',len(out),round(time.time()-start,1),flush=True)
