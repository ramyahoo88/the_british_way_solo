# Reproduction package — Force 136 v1.0.1 audit, 33745a6

This package accompanies `Force_136_v1.0.1_Comprehensive_Audit_33745a6.pdf` and its editable Markdown source. It audits `ramyahoo88/the_british_way_solo`, branch `claude-force136`, at exact commit `33745a6cad5d89f81b3118806b14eec291bec72a`.

No production fixes are included. The five findings are reproduced by observations at this commit. Some focused assertions deliberately assert the observed wrong result; a successful audit-script exit means the report reproduced, not that production is correct. After fixing production, change those assertions to the independently stated expected result. F2/F5 also require checking regenerated printed wording, which a behavioral test alone cannot establish.

## Get the exact source

Use a separate checkout so generated files cannot interfere with working changes:

```bash
git clone https://github.com/ramyahoo88/the_british_way_solo.git repo
git -C repo checkout --detach 33745a6cad5d89f81b3118806b14eec291bec72a
```

In the commands below, run from this extracted evidence folder and replace `/absolute/path/to/repo` with that checkout. Python 3.11 or later is recommended. Core tests and simulations use the standard library. `recount_tables.py` additionally needs NumPy; `check_package.py` needs PyMuPDF; `build_report.py` needs ReportLab and DejaVu fonts at the standard Linux path used in that script.

## Fast findings and information checks

```bash
python3 focused_checks.py /absolute/path/to/repo
python3 japan_information.py /absolute/path/to/repo
```

`focused_checks.py` writes 22 checks/observations and JSON positions. It reproduces all five findings, contains independent rule assertions, and tests adjacent controls. `japan_information.py` compares 352 Japanese decisions after changing only hidden Intel and future deck order. Each script writes into `evidence/`, replacing its own results.

Fixtures:

- F1: `evidence/F1_stacked_redeploy.json` — use `restore(path)`, then `propaganda()`.
- F2: `evidence/F2_J27_reference.json` — use `restore(path)`, then `supply()`; compare the printed target text separately.
- F3: `evidence/F3_eventhog_before_japan.json` and `F3_tempo_before_japan.json` — restore, set policy to `eventhog` or `tempo`, call `japan_turn(['Limited','Event'])`.
- F4: dataset count assertion; no board position needed.
- F5: `evidence/F5_event_box_pass.json` — restore, set `directive=F.DECK[0]`, call `choose(['Event','Op & SA'])`.

`restore()` is defined in `focused_checks.py`. This script runs its tests at module import; for a clean reproduction, run the entire script as above. Positions are diagnostic operation snapshots, not a shipped user-facing save format. They conserve inventories and store board, capabilities, score, supply, concealed Intel and eligibility fields needed for the action. Seeded deck state is reconstructed by the constructor; they are not promised to resume a complete arbitrary interrupted campaign.

## Recheck the existing suite

```bash
python3 run_existing.py /absolute/path/to/repo
```

This launches:

- `verify_v1.py 32` (2,496 paired cases)
- `verify_v1.py --mutants 16` (15 mutants, 1,632 paired cases)
- `equiv.py 32 recruit,agent,veteran,legend,mastermind` (960 cases)
- `review_fixtures.py` (8 tests)
- `report_check.py`
- `check_exit_status.py`

Logs are in the correspondingly named evidence directories. The exit-status checker intentionally runs failures in subprocesses and can write `verify_results.json` and `verify_mutants.json` into the checkout's code directory; these are generated files. The initial audit omitted the required levels argument for equiv.py; that audit invocation was corrected and its successful rerun is recorded. It is not a product defect.

## Expanded sample and shared-engine boundaries

The package already includes the rerun sample used in this audit. To regenerate it first, run the following from `evidence/`:

```bash
python3 /absolute/path/to/repo/force136_v1/code/sample_game.py 20005 adaptive > sample_rerun.txt
```

Then return to this package folder:

```bash
python3 extended_checks.py /absolute/path/to/repo
```

This records the full sample trace, recomputes all its scoring, compares 1,152 Force 136 hidden-information choices and 1,152 pure choice previews, checks all 256 railway masks, and executes 183 Event cases. The Event cases test execution/conservation, not all legal target choices. `sample_full_trace.json.gz` contains setup, every logged state, dice, scoring components and final outcome.

## Repeat fresh strategy experiments

```bash
python3 simulate_audit.py /absolute/path/to/repo
python3 supplemental.py /absolute/path/to/repo
python3 check_stacked_games.py /absolute/path/to/repo
python3 format_results.py
```

The first script runs 2,944 games; the second adds 1,792, for 4,736 total. Baseline Agent uses seeds 170000–170127 and 180000–180127 against extraction, hunting, repair, adaptive, counter, mixed, brute, tempo, econ and eventhog. Strict Event is paired on all 256 seeds. Wide lookahead uses the first 32 seeds of each block, Agent and Mastermind, 16 plans × 4 sampled replies. Supplemental runs pair strict Limited against tempo and alternative corner adjacency against all six ordinary policies. No bot priorities were tuned between blocks.

`check_stacked_games.py` finds 111 baseline games with stacked markers at turn end and reruns complete production/clean-room comparisons. Zero mismatches here do not contradict the targeted F1 fixture.

`fresh_games.json.gz` and `supplemental_games.json.gz` contain every new game outcome, policy, seed, level, variant, goal/administration counters and phase-score summaries. Summary intervals use whole-seed bootstrap (4,000 repetitions, RNG 33745). Individual Wilson intervals for the report are in `report_statistics.json`. Phase summaries are not full move logs; the full sample trace and targeted saves supply detailed reproductions. Diagnostic strict-policy subclasses are in the audit code only.

## Printed package and published result recount

```bash
python3 check_package.py /absolute/path/to/repo
python3 recount_tables.py /absolute/path/to/repo
```

The package check compares all nine Directive cards, card backs, rule reminders, combined-PDF page content and the complete repository manifest. The recount checks all 30,000 primary result rows, level denominators and exploit counts; its independent whole-seed uncertainty calculation uses NumPy RNG 33745 and 10,000 repetitions.

The report's baseline railway graph is explicitly transcribed in `extended_checks.py`; the alternative northern corner reading remains unresolved. Official source URLs, hashes and inspection scope are in `SOURCE_PIN.json`. Publisher PDFs and artwork are intentionally not redistributed.

## Integrity and rendering

`AUDIT_MANIFEST_SHA256.json` hashes the files in this package except itself. Verify before rerunning scripts, because they replace result files and runtimes/timings need not reproduce byte for byte. Gzip header times may differ even for identical decompressed data. Outcome comparisons should use parsed JSON, not compressed file hashes.

`build_report.py` rebuilds the PDF from the included Markdown. The report was rendered and visually inspected; `evidence/audit_pdf_checks.json` records page bounds. Audit tool-runtime logs may contain local workspace paths. They are not required input paths; every repository-dependent audit script accepts the repository path argument above.
