from pathlib import Path
from collections import Counter,defaultdict
import gzip,json,math
ROOT=Path(__file__).resolve().parent
rows=json.load(gzip.open(ROOT/'evidence/fresh_games.json.gz','rt'))
supp=json.load(gzip.open(ROOT/'evidence/supplemental_games.json.gz','rt'))
def wilson(w,n):
 z=1.959963984540054;p=w/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
 return [c-h,c+h]
by=defaultdict(list)
for r in rows:by[(r['variant'],r['level'],r['policy'])].append(r)
out=[]
for (variant,level,pol),rs in sorted(by.items()):
 c=Counter(r['winner'] for r in rs);n=len(rs);w=c['Force 136']
 out.append(dict(variant=variant,level=level,policy=pol,n=n,force136=w,Japan=c['Japan'],MPAJA=c['MPAJA'],mean_R=sum(r['R'] for r in rs)/n,wilson95=wilson(w,n)))
regular=[r for r in rows if r['variant']=='baseline' and r['policy'] in ('extraction','hunting','repair','adaptive','counter','mixed')]
a=Counter();goals=Counter()
for r in regular:a.update(r['audit']);goals.update(r['goals'])
for k in ('max_goal_checks','max_sa_checks'):a[k]=max(r['audit'].get(k,0) for r in regular)
result=dict(new_executions=len(rows)+len(supp),groups=out,regular_instrumentation=dict(a),regular_goals=dict(goals))
(ROOT/'evidence/report_statistics.json').write_text(json.dumps(result,indent=2)+'\n')
for x in out:print(x['variant'],x['level'],x['policy'],x['n'],x['force136'],x['Japan'],x['MPAJA'],round(x['mean_R'],2),[round(v*100,1) for v in x['wilson95']])
