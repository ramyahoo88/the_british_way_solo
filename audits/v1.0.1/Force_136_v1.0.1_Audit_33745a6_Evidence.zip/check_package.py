"""Check all nine printed cards, fixed rule reminders, combined PDF, and source hashes."""
from pathlib import Path
import sys,json,hashlib,re,subprocess
import fitz
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6';SRC=REPO/'force136_v1'
sys.path.insert(0,str(SRC/'code'))
import force136_v1 as F
cards=json.loads((SRC/'print/cards.json').read_text());assert cards==F.DECK
pdf=fitz.open(SRC/'print/Force_136_v1_Cards.pdf');backs=[]
for i,c in enumerate(cards):
    col,row=i%3,i//3;rect=fitz.Rect(36+180*col,18+252*row,216+180*col,270+252*row)
    t=pdf[0].get_text(clip=rect);assert f"DIRECTIVE {c['id']}/9" in t and c['name'] in t
    full,limited=t.split('LIMITED OPERATION')
    assert re.findall(r'PLACE|AMBUSH|INTEL|SUPPLY|TRAIN|CONTACT',full)==['PLACE']+c['goals']+['CONTACT']
    second='TRAIN' if c['limited_first']=='AMBUSH' else 'AMBUSH'
    assert re.findall(r'\b(?:PLACE|AMBUSH|TRAIN|CONTACT)\b',limited)==['PLACE',c['limited_first'],second,'CONTACT']
    backs.append(' '.join(pdf[1].get_text(clip=rect).split()))
assert len(set(backs))==1
texts=[];page_info=[]
for name in ['Rules','Reference','Cards','Record_Sheet']:
    doc=fitz.open(SRC/f'print/Force_136_v1_{name}.pdf')
    texts.extend(p.get_text() for p in doc)
    for i,p in enumerate(doc):
        assert all(0<=b[0]<=b[2]<=p.rect.width and 0<=b[1]<=b[3]<=p.rect.height for b in p.get_text('blocks'))
    page_info.append(dict(component=name,pages=len(doc)))
combined=fitz.open(SRC/'print/Force_136_v1_Print_and_Play.pdf')
assert len(combined)==11 and [p.get_text() for p in combined]==texts
ref=' '.join(' '.join(p.get_text().split()) for p in fitz.open(SRC/'print/Force_136_v1_Reference.pdf'))
assert 'no extra slot' in ref and 'Gather does not activate' in ref and 're-place an Active one' in ref
rules=' '.join(' '.join(p.get_text().split()) for p in fitz.open(SRC/'print/Force_136_v1_Rules.pdf'))
assert 'version 1.0.1' in rules.casefold() and 'The extra space never makes a goal qualify' in rules
m=json.loads((REPO/'FILE_MANIFEST_SHA256.json').read_text())
assert all(hashlib.sha256((REPO/p).read_bytes()).hexdigest()==h for p,h in m.items())
tracked=set(subprocess.check_output(['git','ls-files'],cwd=REPO,text=True).splitlines())-{'FILE_MANIFEST_SHA256.json'}
assert tracked==set(m)
out=dict(nine_card_goals_and_limited_preferences_match=True,identical_back_texts=True,
         components=page_info,combined_pages=len(combined),combined_text_matches=True,
         fixed_rule_reminders_present=True,manifest_entries=len(m),manifest_matches=True)
(ROOT/'evidence/package_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
