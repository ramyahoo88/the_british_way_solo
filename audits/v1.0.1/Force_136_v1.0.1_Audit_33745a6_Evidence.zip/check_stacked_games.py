from pathlib import Path
import json,gzip,sys,time
ROOT=Path(__file__).resolve().parent;REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6';CODE=REPO/'force136_v1/code'
sys.path.insert(0,str(CODE));import verify_v1 as V
rows=json.load(gzip.open(ROOT/'evidence/fresh_games.json.gz','rt'))
jobs=[r for r in rows if r['variant']=='baseline' and r['audit']['stacked_F136_end_turns']]
out=[]
for r in jobs:
 q=V.check(r['seed'],r['policy'],r['level']);out.append(dict(seed=r['seed'],policy=r['policy'],level=r['level'],**q))
 if q['cross'] or q['oracle']:print(out[-1],flush=True)
(ROOT/'evidence/stacked_games_comparison.json').write_text(json.dumps(out,indent=2)+'\n')
print('cases',len(out),'mismatches',sum(bool(r['cross']) for r in out),'oracle',sum(bool(r['oracle']) for r in out),flush=True)
