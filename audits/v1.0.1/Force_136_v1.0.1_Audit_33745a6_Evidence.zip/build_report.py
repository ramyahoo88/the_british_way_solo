"""Render the Markdown review as a readable ReportLab PDF."""
from pathlib import Path
import re,html
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Preformatted,KeepTogether,PageBreak
ROOT=Path(__file__).resolve().parent
FONT=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('Review','DejaVuSans.ttf'),('Review-Bold','DejaVuSans-Bold.ttf'),('Review-Italic','DejaVuSans-Oblique.ttf'),('ReviewMono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(FONT/file)))
pdfmetrics.registerFontFamily('Review',normal='Review',bold='Review-Bold',italic='Review-Italic',boldItalic='Review-Bold')
green=colors.HexColor('#2e493b');ink=colors.HexColor('#202b27');muted=colors.HexColor('#53615b')
styles={
 'body':ParagraphStyle('body',fontName='Review',fontSize=9.3,leading=13.1,textColor=ink,spaceAfter=5.4),
 'h1':ParagraphStyle('h1',fontName='Review-Bold',fontSize=24,leading=29,textColor=green,spaceAfter=16,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='Review-Bold',fontSize=15,leading=19,textColor=green,spaceBefore=15,spaceAfter=8,keepWithNext=True),
 'h3':ParagraphStyle('h3',fontName='Review-Bold',fontSize=11.8,leading=16,textColor=green,spaceBefore=12,spaceAfter=7,keepWithNext=True),
 'cell':ParagraphStyle('cell',fontName='Review',fontSize=8.1,leading=11.5,textColor=ink),
 'headcell':ParagraphStyle('headcell',fontName='Review-Bold',fontSize=8.1,leading=11.5,textColor=colors.white),
 'code':ParagraphStyle('code',fontName='ReviewMono',fontSize=7.8,leading=11,textColor=ink,spaceAfter=9,leftIndent=10),
 'bullet':ParagraphStyle('bullet',fontName='Review',fontSize=9.3,leading=13.1,textColor=ink,spaceAfter=4.8,leftIndent=11,firstLineIndent=-9),
}
def inline(s):
    s=html.escape(s)
    s=re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',lambda m:'<link href="'+m.group(2)+'" color="#2e493b"><u>'+m.group(1)+'</u></link>',s)
    s=re.sub(r'`([^`]+)`',lambda m:'<font name="ReviewMono" size="8.1">'+m.group(1)+'</font>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'\*([^*]+)\*',r'<i>\1</i>',s)
    return s
def footer(canvas,doc):
    canvas.saveState();w,h=letter
    canvas.setStrokeColor(colors.HexColor('#b8c6bc'));canvas.line(46,39,w-46,39)
    canvas.setFont('Review',7.2);canvas.setFillColor(muted)
    canvas.drawString(46,27,'Force 136 v1.0.1 | Comprehensive audit: 33745a6 | 21 November 2026')
    canvas.drawRightString(w-46,27,str(doc.page));canvas.restoreState()
lines=(ROOT/'Force_136_v1.0.1_Comprehensive_Audit_33745a6.md').read_text().splitlines();story=[];i=0
while i<len(lines):
    line=lines[i]
    if not line.strip():i+=1;continue
    if line.startswith('```'):
        code=[];i+=1
        while i<len(lines) and not lines[i].startswith('```'):code.append(lines[i]);i+=1
        story.append(Preformatted('\n'.join(code),styles['code']));i+=1;continue
    if line.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].startswith('|'):
            bits=[x.strip() for x in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[:\- ]+',x) for x in bits):rows.append(bits)
            i+=1
        n=len(rows[0]);widths={2:[167,353],3:[175,195,150],4:[80,108,180,152],5:[104,104,92,100,120]}[n]
        data=[[Paragraph(inline(c),styles['headcell' if ri==0 else 'cell']) for c in r] for ri,r in enumerate(rows)]
        t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),green),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.7,green),('LINEBELOW',(0,1),(-1,-1),.35,colors.HexColor('#c5d0c8')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f0f5f1'),colors.white])]))
        group=[t,Spacer(1,10)]
        if story and isinstance(story[-1],Paragraph) and story[-1].style.name in ('h2','h3'):
            group.insert(0,story.pop())
        story.append(KeepTogether(group));continue
    if line.startswith('#'):
        if line.startswith(('## 2.','## 4.','## 8.')):
            story.append(PageBreak())
        level=len(line)-len(line.lstrip('#'));story.append(Paragraph(inline(line[level:].strip()),styles[f'h{min(level,3)}']));i+=1;continue
    if line.startswith('- ') or re.match(r'^\d+\. ',line):
        story.append(Paragraph(inline(line),styles['bullet']));i+=1;continue
    p=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','```','- ')):
        p.append(lines[i]);i+=1
    story.append(Paragraph(inline(' '.join(p)),styles['body']))
out=ROOT/'Force_136_v1.0.1_Comprehensive_Audit_33745a6.pdf'
doc=SimpleDocTemplate(str(out),pagesize=letter,leftMargin=46,rightMargin=46,topMargin=43,bottomMargin=52,title='Force 136 v1.0.1 - comprehensive audit of 33745a6',author='Codex',pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(out)
