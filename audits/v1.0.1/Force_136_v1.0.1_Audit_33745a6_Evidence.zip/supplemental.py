from simulate_audit import *
if __name__=='__main__':
 seeds=list(range(170000,170128))+list(range(180000,180128))
 jobs=[(s,'tempo','agent','forced_tempo') for s in seeds]
 jobs += [(s,p,'agent','corner') for s in seeds for p in ('extraction','hunting','repair','adaptive','counter','mixed')]
 with Pool(4) as pool:out=list(pool.imap_unordered(one,jobs,chunksize=8))
 out.sort(key=lambda r:(r['variant'],r['seed'],r['policy']))
 with gzip.open(ROOT/'evidence/supplemental_games.json.gz','wt') as f:json.dump(out,f)
 base=json.load(gzip.open(ROOT/'evidence/fresh_games.json.gz','rt'))
 lookup={(r['seed'],r['policy']):r for r in base if r['variant']=='baseline'}
 summary=[]
 for variant in ('forced_tempo','corner'):
  for label,start in [('development',170000),('confirmation',180000),('combined',None)]:
   rs=[r for r in out if r['variant']==variant and (start is None or start<=r['seed']<start+128)]
   ds=defaultdict(list)
   for r in rs:ds[r['seed']].append(int(r['winner']=='Force 136')-int(lookup[(r['seed'],r['policy'])]['winner']=='Force 136'))
   vals=[sum(v)/len(v) for v in ds.values()]
   summary.append(dict(variant=variant,block=label,n=len(rs),seeds=len(ds),wins=sum(r['winner']=='Force 136' for r in rs),base_wins=sum(lookup[(r['seed'],r['policy'])]['winner']=='Force 136' for r in rs),delta=sum(vals)/len(vals),ci=ci(vals)))
 (ROOT/'evidence/supplemental_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary,indent=2))
