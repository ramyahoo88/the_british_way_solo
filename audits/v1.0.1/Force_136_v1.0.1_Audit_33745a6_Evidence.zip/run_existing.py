from pathlib import Path
import subprocess,sys,json,time,concurrent.futures
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6';CODE=REPO/'force136_v1/code'
JOBS={'verify':['verify_v1.py','32'],'mutants':['verify_v1.py','--mutants','16'],'fixtures':['review_fixtures.py'],'report':['report_check.py'],'exit_status':['check_exit_status.py'],'equiv':['equiv.py','32','recruit,agent,veteran,legend,mastermind']}
def job(item):
 name,args=item;d=ROOT/'evidence'/name;d.mkdir(exist_ok=True)
 t=time.time();p=subprocess.run([sys.executable,str(CODE/args[0])]+args[1:],cwd=d,capture_output=True,text=True)
 (d/'stdout.txt').write_text(p.stdout);(d/'stderr.txt').write_text(p.stderr)
 row={'name':name,'returncode':p.returncode,'seconds':round(time.time()-t,2),'command':args}
 print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: rows=list(pool.map(job,JOBS.items()))
(ROOT/'evidence/existing_suite.json').write_text(json.dumps(rows,indent=2))
