from pathlib import Path
import csv,gzip,json,collections,math,sys
import numpy as np
ROOT=Path(__file__).resolve().parent;REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6';CODE=REPO/'force136_v1/code'
rows=list(csv.DictReader(gzip.open(CODE/'results/results_fresh_v101.csv.gz','rt')))
assert len(rows)==30000 and len({(r['seed'],r['level'],r['policy']) for r in rows})==30000
rng=np.random.default_rng(33745);result={}
for level in ('recruit','agent','veteran','legend','mastermind'):
 rs=[r for r in rows if r['level']==level];by=collections.defaultdict(list)
 for r in rs:by[int(r['seed'])].append(r['winner']=='Force 136')
 assert len(rs)==6000 and len(by)==1000 and all(len(x)==6 for x in by.values())
 arr=np.array([np.mean(by[s]) for s in sorted(by)])
 boots=np.concatenate([arr[rng.integers(0,len(arr),(1000,len(arr)))].mean(1) for _ in range(10)])
 result[level]=dict(n=len(rs),wins=sum(r['winner']=='Force 136' for r in rs),mean_R=sum(float(r['final_resistance']) for r in rs)/len(rs),mpaja=sum(r['winner']=='MPAJA' for r in rs),ci=np.quantile(boots,[.025,.975]).tolist())
ex=json.loads((CODE/'results/results_exploits_v101.json').read_text());counts=collections.Counter(r['pol'] for r in ex)
assert len(ex)==256 and set(counts.values())=={64}
result['exploit_data']=dict(total=len(ex),counts=counts,seed_min=min(r['seed'] for r in ex),seed_max=max(r['seed'] for r in ex),wins={p:sum(r['winner']=='Force 136' for r in ex if r['pol']==p) for p in counts})
result['mutants_catalog']=dict(actual=len(json.loads((CODE/'results/v101_mutants.json').read_text())),README_claim='13 planted errors')
(ROOT/'evidence/recount_tables.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
