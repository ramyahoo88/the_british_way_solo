"""Independent fixtures for commit 33745a6. No production files are changed.

Run: python focused_checks.py /path/to/the_british_way_solo
Observed defects are asserted as observations, not represented as passing rules tests.
JSON positions can be loaded with restore() below.
"""
from pathlib import Path
from copy import deepcopy
import sys,json,random,hashlib
ROOT=Path(__file__).resolve().parent
REPO=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'force136_audit_33745a6'
CODE=REPO/'force136_v1/code';sys.path[:0]=[str(CODE),str(CODE/'cleanroom')]
import engine as E,force136_v1 as F,cleanroom as C,expert
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
rows=[]
def record(name,**kw):
    rows.append(dict(name=name,**kw));print(name, json.dumps(kw),flush=True)
def empty(cls=F.Force136,seed=3374501,**kw):
    g=cls(seed,**kw);g.board=E.new_board()
    g.board['Kuala Lumpur'].update(troops=15,police=6,kempeitai=3)
    return g
def snapshot(g):
    return {k:deepcopy(getattr(g,k)) for k in ('seed','level','board','sabotage','cap','resistance','resources','zipper','track_cache','lost_cache','lost_k','away_troops','away_f','removed_intel','secret','campaign','draw','event','first','chosen')}
def save(g,name):
    d=snapshot(g);d['removed_intel']=sorted(d['removed_intel'])
    (OUT/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n')
def restore(path,cls=F.Force136):
    d=json.loads(Path(path).read_text());g=cls(d['seed'],level=d['level'])
    for k,v in d.items():setattr(g,k,({int(a):b for a,b in v.items()} if k=='cap' else set(v) if k=='removed_intel' else v))
    g.invariants();return g

# Setup expectations transcribed independently from official p27, both columns.
g=F.Force136(3374500)
assert (g.count('troops'),g.count('police'),g.count('kempeitai'),g.count('force136'),g.count('camp'),g.count('cache'))==(15,3,3,2,3,1)
assert [g.available(k) for k in ('red','blue','cache','camp','force136','police')]==[4,2,2,1,1,3]
assert (g.resistance,g.resources,g.zipper,g.first)==(2,0,0,'B')
assert sorted(g.secret.values())==[0,0,0,1,1,1,2,2,2]
for seed in range(3374500,3374600):
    q=F.Force136(seed);assert len(q.deck)==21 and len(set(q.deck))==21
    for start in (0,7,14):
        pile=q.deck[start:start+7]
        assert sum(j>=33 for j in pile)==1 and all(j<33 for j in pile[:4])
record('setup_and_100_deck_deals',status='pass')

# F1: both markers at a stacked origin must redeploy, not just one per origin.
g=empty(seed=3374501);g.board['Kuala Lumpur']['kempeitai']=1
g.board['Perak'].update(force136=2,kempeitai=1,troops=1)
g.board['Kuala Lumpur']['troops']-=1
g.board['Johore'].update(force136=1,kempeitai=1)
for s in ('Kedah','Kelantan','Trengganu'):g.board[s]['camp']=True
g.invariants();save(g,'F1_stacked_redeploy')
c=restore(OUT/'F1_stacked_redeploy.json',C.CleanForce136)
g.propaganda();c.propaganda();g.invariants();c.invariants()
pos=lambda x:{s:v['force136'] for s,v in x.board.items() if v['force136']}
assert pos(g)=={'Kedah':1,'Perak':1,'Kelantan':1}
assert pos(c)=={'Kedah':1,'Kelantan':1,'Trengganu':1}
assert g.exposed('Perak')
record('F1_stacked_redeploy',status='confirmed discrepancy',expected=pos(c),observed=pos(g),left_exposed=True)
# Nearby case: one marker at each origin is handled correctly.
g=restore(OUT/'F1_stacked_redeploy.json');g.board['Perak']['force136']=1;g.board['Johore']['force136']=0
c=restore(OUT/'F1_stacked_redeploy.json',C.CleanForce136);c.board=deepcopy(g.board)
g.propaganda();c.propaganda();assert g.board==c.board
record('F1_single_marker_control',status='pass')
g=restore(OUT/'F1_stacked_redeploy.json');c=restore(OUT/'F1_stacked_redeploy.json',C.CleanForce136)
for x in (g,c):
    for v in x.board.values():v['camp']=False
    x.propaganda()
assert g.board==c.board and pos(g)=={'Perak':2,'Johore':1}
record('F1_no_destination_control',status='pass')

# F2: Reference p2 drops "with Opposition" from J27's eligible selections.
g=empty(seed=3374502);g.cap[27]='S'
g.board['Trengganu'].update(force136=1,camp=True,red_u=1)
g.board['Negri Sembilan'].update(force136=1,camp=True,red_u=1,opposition=True)
g.invariants();save(g,'F2_J27_reference')
selected=['Trengganu','Negri Sembilan'];literal=min(selected,key=lambda s:(E.POP[s],E.ix(s)))
assert literal=='Trengganu' and not g.board[literal]['opposition']
assert g.supply()==2 and not g.board['Negri Sembilan']['opposition']
record('F2_J27_reference',status='confirmed text omission',literal_reference_target=literal,required_and_code_target='Negri Sembilan')
for opposed,want in ((['Trengganu','Negri Sembilan'],'Trengganu'),([],None)):
    g=restore(OUT/'F2_J27_reference.json')
    for s in selected:g.board[s]['opposition']=s in opposed
    before={s:g.board[s]['opposition'] for s in selected};g.supply()
    removed=[s for s in selected if before[s] and not g.board[s]['opposition']]
    assert removed==([want] if want else [])
record('F2_both_opposed_and_none_opposed_controls',status='pass')

# F3: the Event-hog filter admits every generated legal candidate.
plans=[dict(op='EVENT',box='Event'),dict(op='DEPLOY',box='Limited'),dict(op='SWEEP',box='Op & SA',sa='ELIMINATE')]
assert all(expert.FastGame.EXPLOIT['eventhog'](p) for p in plans)
g=F.Force136(170000);g.policy='eventhog';g.event=g.deck[0];g.draw=1;g.deck_pos=1
g.icon(g.event);g.mandatory(g.event);g.bot_turn(E.BOXES)
free=[x for x in E.BOXES if x!=g.chosen['B']];save(g,'F3_eventhog_before_japan')
g.japan_turn(free)
assert g.event==10 and 'Event' in free and g.chosen['J']=='Limited'
record('F3_eventhog_filter',status='confirmed tautology',admits=plans,seed=g.seed,event=g.event,opening_choice=g.chosen['J'])
g=F.Force136(170001);g.policy='tempo';g.event=g.deck[0];g.draw=1;g.deck_pos=1
g.icon(g.event);g.mandatory(g.event);g.bot_turn(E.BOXES)
free=[x for x in E.BOXES if x!=g.chosen['B']];save(g,'F3_tempo_before_japan')
g.japan_turn(free)
assert g.event==27 and 'Limited' in free and g.chosen['J']=='Event'
record('F3_tempo_filter',status='confirmed strategy mismatch',seed=g.seed,event=g.event,free=free,chosen=g.chosen['J'])

# F4: the published four-policy experiment has 64, not 256, games per row.
from collections import Counter
ex=json.loads((CODE/'results/results_exploits_v101.json').read_text())
counts=Counter(r['pol'] for r in ex)
assert len(ex)==256 and counts==dict(brute=64,tempo=64,econ=64,eventhog=64)
record('F4_exploit_sample_size',status='confirmed report mismatch',claimed_per_policy=256,observed=dict(counts))

# F5: no-event-box sentence conflicts with leftmost-free Pass instruction.
g=empty(seed=3374504)
for s in ('Kedah','Perak','Negri Sembilan'):g.board[s].update(force136=1,red_u=1)
for s in E.ORDER[:9]:g.board[s]['intel']=g.secret[s]
g.chosen={'J':'Limited'};g.directive=F.DECK[0];g.invariants();save(g,'F5_event_box_pass')
p=g.choose(['Event','Op & SA']);assert p['op']=='PASS' and p['box']=='Event'
record('F5_pass_instruction_conflict',status='confirmed wording conflict',observed=p)

# Train last-resort fallback and donor boundary.
g=empty();g.board['Perak'].update(force136=1,cache=True,red_a=10)
assert g.train()==2 and g.board['Perak']['red_u']==2
g=empty();g.board['Perak'].update(force136=1,cache=True,red_a=8)
g.board['Pahang'].update(red_a=2,cache=True)
assert g.train()==2 and g.board['Pahang']['red_a']==1 and g.board['Perak']['red_u']==2
g=empty();g.board['Perak'].update(force136=1,cache=True,red_u=10)
assert g.train()==0
record('Train_remote_then_local_guard_and_underground_control',status='pass')

# Strict roll threshold; Police removal is automatic; adjacent Cache adds one.
for roll,want in ((2,False),(3,True)):
    g=empty();g.board['Perak'].update(force136=1,red_u=1,troops=3,cache=True)
    g.board['Kuala Lumpur']['troops']-=3;g.die=lambda *a:roll
    g.strike();assert g.resistance==(3 if want else 2)
g=empty();g.board['Perak'].update(force136=1,red_u=1,police=1)
g.board['Kuala Lumpur']['police']-=1;g.die=lambda *a:(_ for _ in ()).throw(AssertionError('Police must not roll'))
g.strike();assert not g.board['Perak']['police'] and g.resistance==2
record('Ambush_strict_threshold_cache_bonus_and_automatic_Police',status='pass')

# J8 failed conversions do not cause re-selection. J27 still removes Opposition
# from a selected opposed Province even if the conversion roll failed.
g=empty();g.cap={8:'S',27:'S'};g.track_cache=1;g.zipper=6
for s in ('Kedah','Perak','Kelantan'):g.board[s].update(force136=1,camp=True,red_u=1,opposition=True)
rolls=[]
def fail(*a):rolls.append(a);return 1
g.die=fail;assert g.supply()==0 and len(rolls)==2
assert g.count('camp')==3 and g.count('cache')==0 and not g.board['Kedah']['opposition']
record('J8_failures_no_reselection_and_J27_selected_space',status='pass',rolls=rolls)

# Sweep simultaneous movement and terrain.
for s,k,n in (('Kedah',0,1),('Kedah',1,3),('Perak',0,3)):
    g=empty();g.board[s].update(troops=3,red_u=4,kempeitai=k)
    g.board['Kuala Lumpur']['troops']-=3;g.board['Kuala Lumpur']['kempeitai']-=k
    g.sweep_plan(targets=[s],strength=3);assert g.board[s]['red_a']==n
g=empty();g.board['Perak']['troops']=5;g.board['Kuala Lumpur']['troops']-=5
g.sweep_plan(targets=['Kedah','Kelantan'],limit=2,strength=3)
assert g.board['Kedah']['troops']+g.board['Kelantan']['troops']==4 and g.count('troops')==15
record('Sweep_terrain_and_simultaneous_conservation',status='pass')

# Construct requires strictly more cubes. Assault protects a Cache with any UG.
g=empty();g.board['Perak'].update(troops=1,red_u=1);g.board['Kuala Lumpur']['troops']-=1
g.sabotage['Perak-Kelantan']=1;assert not g.construct() and g.sabotage['Perak-Kelantan']==1
for k,ug,n in ((0,1,1),(0,0,1),(1,0,2)):
    g=empty();g.board['Perak'].update(troops=3,red_a=1,red_u=ug,cache=True,kempeitai=k)
    g.board['Kuala Lumpur']['troops']-=3;g.board['Kuala Lumpur']['kempeitai']-=k
    assert g.assault()==n and bool(g.board['Perak']['cache'])==(n==1)
record('Construct_strict_superiority_and_Assault_Cache_protection',status='pass')

# Eliminate ordering and strict die test, then the capability exception.
for cap,roll,want in ((None,1,'none'),(None,2,'camp'),('S',2,'force136')):
    g=empty();g.board['Perak'].update(red_u=1,camp=True,force136=1,kempeitai=1)
    g.board['Kuala Lumpur']['kempeitai']-=1;g.cap={22:cap};g.die=lambda *a,r=roll:r
    g.eliminate(['Perak'],1)
    assert g.board['Perak']['camp']==(want!='camp')
    assert g.board['Perak']['force136']==(want!='force136')
    assert g.resistance==(1 if want=='force136' else 2)
record('Eliminate_order_threshold_and_J22_exception',status='pass')

# J6 targets forces, not markers; only Jungle, one shared die per Province.
g=empty();g.board['Kedah'].update(red_a=1,blue_u=1,troops=1,force136=1,camp=True,kempeitai=1)
g.board['Kuala Lumpur']['troops']-=1;g.board['Kuala Lumpur']['kempeitai']-=1
g.board['Perak'].update(red_a=1,troops=1);g.board['Kuala Lumpur']['troops']-=1
rolls=[]
def low(*a):rolls.append(a);return 1
g.die=low;g.mandatory(6)
assert len(rolls)==6 and g.board['Kedah']['red_a']==0 and g.board['Kedah']['blue_u']==1
assert g.board['Kedah']['troops']==0 and g.board['Kedah']['camp'] and g.board['Kedah']['force136']==1
assert g.board['Kedah']['kempeitai']==1 and g.board['Perak']['troops']==1 and g.board['Perak']['red_a']==1
record('J6_shared_die_forces_only_Jungle_only',status='pass')

# Every Zipper threshold, release and return; all map Caches have equal guerrillas.
for target,track in ((0,2),(6,1),(12,1),(18,0),(20,0)):
    g=empty();g.move_zipper(target=target);assert g.track_cache==track and g.available('cache')==5-track
g=empty();g.zipper=20;g.track_cache=0
for s in E.PROV[:5]:g.board[s]['cache']=True
g.move_zipper(target=0)
assert g.track_cache==2 and not g.board['Pahang']['cache'] and not g.board['Trengganu']['cache'] and g.available('cache')==0
record('Zipper_all_boxes_and_two_map_Cache_returns',status='pass')

# Victory ties and bonus timing. Zero net score fixtures: no guerrillas or
# Caches, all Population opposed; no red Available after placing all 10 on EC
# blocked by ten cubes (so Mobilize cannot change anything).
def zero_score(level='agent'):
    g=empty(level=level);g.board['Northern EC'].update(red_u=10,troops=10)
    g.board['Kuala Lumpur']['troops']-=10
    for s in E.ORDER[:9]:g.board[s]['opposition']=True
    return g
for r,camps,f,w in ((17,0,0,'Japan'),(18,2,2,'MPAJA'),(19,1,2,'Force 136'),(20,4,0,'Force 136')):
    g=zero_score();g.resistance=r
    for s in E.PROV[:camps]:g.board[s]['camp']=True
    g.board['Perak']['force136']=f;g.score_only(True)
    assert g.resistance==r and g.winner==w
for level,bonus in (('agent',0),('legend',1),('mastermind',2)):
    g=zero_score(level);g.resistance=17;g.score_only(False)
    assert g.resistance==17+bonus and g.zipper==12
    g=zero_score(level);g.resistance=17;g.score_only(True);assert g.resistance==17 and g.winner=='Japan'
record('Victory_ties_final_bonus_omission_and_Zipper_before_bonus',status='pass')

# J9 resolves Seize Supplies before final score and never takes a player turn.
for campaign in (1,2):
    g=F.Force136(3374509);g.campaign=campaign;g.mandatory(9);assert not g.ended
g=empty();g.campaign=3;g.deck=[9];g.board['Perak']['cache']=True
g.bot_turn=lambda *_:(_ for _ in ()).throw(AssertionError('turn after J9'))
g.japan_turn=g.bot_turn;r=g.run()
assert r['ending']=='J9' and g.ended and g.board['Perak']['camp'] and not g.board['Perak']['cache'] and g.campaign==3
record('J9_icon_before_final_no_player_turns_no_nonfinal_phases',status='pass')

# J15 shaded: Mobilize and scoring treat New Villages as Neutral, without
# deleting their Opposition marker; J12 unshaded can put Opposition despite Terror.
g=empty();g.cap[15]='S';g.board['Kedah'].update(opposition=True,new_village=True,troops=1)
g.board['Kuala Lumpur']['troops']-=1;r=g.score_only()
assert g.board['Kedah']['red_u']==0 and g.board['Kedah']['opposition'] and r['neutral_population']==16
g=empty();g.cap[12]='U';g.board['Perak'].update(troops=1,terror=1)
g.board['Kuala Lumpur']['troops']-=1;g.sabotage['Thailand-Perak']=1;g.repair('Thailand-Perak',True)
assert g.board['Perak']['opposition']
record('J15_propaganda_neutral_and_J12_Event_terror_override',status='pass')

# New Village removal by British forces with no Japanese forces (markers do not count).
g=empty();g.board['Perak'].update(new_village=True,red_u=1,kempeitai=1)
g.board['Kuala Lumpur']['kempeitai']-=1;g.cleanup();assert not g.board['Perak']['new_village']
record('New_Village_cleanup_markers_not_forces',status='pass')

# Full report stores test names and explicit outcomes; source inputs stay separate.
(OUT/'focused_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Completed',len(rows),'checks/observations')
